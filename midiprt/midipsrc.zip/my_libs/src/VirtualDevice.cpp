// VirtualDevice.cpp: Implementierung der Klasse VirtualDevice.
//
//////////////////////////////////////////////////////////////////////

#include <assert.h>
#include <ui_dsp.hpp>
#include "my_vdi.h"
#include "VirtualDevice.hpp"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

VirtualDevice::VirtualDevice(UI_DISPLAY *_dsp, ZIL_SCREENID _scrID) :
	rgbFillColor(RGB_BLACK), fillInterior(FIS_SOLID), 
	                         fillStyle(IP_1PATT), 
					         fillPerimeter(1/*true*/),
	rgbLineColor(RGB_BLACK), lineWidth(1), 
	                         lineType(SOLID),
	rgbTextColor(RGB_BLACK), textAlignHor(TA_LEFT), 
	                         textAlignVer(TA_BASELINE)
{
	dsp   = _dsp   ; 
	assert(dsp) ;
	scrID = _scrID ; 
	dsp->Font(FNT_PROPORTIONAL_OUTLINEFONT) ;
	dsp->CharStyle(STLF_NO_FLAGS) ;
}

VirtualDevice::~VirtualDevice()
{ }

//-------------- attribute functions -------------------------

int     vswr_mode( int handle, int mode )
{ 
	((VirtualDevice *)handle)->writeMode = mode ; 
	return mode ;
}

int     vsl_type( int handle, int style )
{ 
	((VirtualDevice *)handle)->lineType = style ; 
	return style ;
}

int     vsl_width( int handle, int width )
{ 
	((VirtualDevice *)handle)->lineWidth = width ; 
	return width ;
}

// In contrast to original VDI, here a RGB color value
// and no color index is expected.
int     vsl_color( int handle, int color )
{ 
	((VirtualDevice *)handle)->rgbLineColor = color ; 
	return color ;
}

int     vst_color( int handle, int color )
{ 
	((VirtualDevice *)handle)->rgbTextColor = color ; 
	return color ;
}

void    vst_height( int handle, int height, int *char_width,
                    int *char_height, int *cell_width,
                    int *cell_height )
{
	UI_DISPLAY *dsp = ((VirtualDevice *)handle)->dsp ;
	UI_2VECTOR box = dsp->CharBox() ;
	box._0 = (box._0 * height)/box._1 ;
	box._1 = (float)height ;
	dsp->CharBox(box) ; // pixels
	*char_width  = *cell_width  = (int)box._0 ;
	*char_height = *cell_height = (int)box._1 ;
}

int     vst_point( int handle, int point, int *char_width,
                    int *char_height, int *cell_width,
                    int *cell_height )
{
	UI_DISPLAY *dsp = ((VirtualDevice *)handle)->dsp ;
	int height = (int)( (float)point * 0.000353 * dsp->resolutionX ) ; 
	vst_height(handle, height, char_width, char_height, 
		                       cell_width, cell_height ) ;
	return point ;
}

// In contrast to original VDI, here a ZIL_LOGICAL_FONT
// is expected.
int     vst_font( int handle, int font )
{
	UI_DISPLAY *dsp = ((VirtualDevice *)handle)->dsp ;
	return dsp->Font(font) ;
}

int     vst_effects( int handle, int effects )
{
#define NORMAL      0x00
#define BOLD        0x01
#define LIGHT       0x02
#define ITALIC      0x04
#define UNDERLINED  0x08
#define HOLLOW      0x10
#define SHADOWED    0x20

	UI_DISPLAY *dsp = ((VirtualDevice *)handle)->dsp ;
	STLF_FLAGS flags = STLF_NO_FLAGS ;
	if (effects & BOLD  )     flags |= STLF_BOLD ;
	if (effects & ITALIC)     flags |= STLF_ITALIC ;
	if (effects & UNDERLINED) flags |= STLF_UNDERLINED ;
	// the other effects we do not emulate
	dsp->CharStyle(flags) ;
	return effects ;
}

void    vst_alignment( int handle, int hor_in , int ver_in,
                                  int *hor_out, int *ver_out ) 
{
	((VirtualDevice *)handle)->textAlignHor = hor_in ; 
	((VirtualDevice *)handle)->textAlignVer = ver_in ; 
	*hor_out = hor_in ;
	*ver_out = ver_in ;
}

int     vsf_interior( int handle, int interior )
{
	((VirtualDevice *)handle)->fillInterior = interior ; 
	return interior ;
}

// In contrast to original VDI, the style index
// will lead to a brightening of the color.
int     vsf_style( int handle, int style_index )
{
	((VirtualDevice *)handle)->fillStyle = style_index ; 
	return style_index ; 
}

// In contrast to original VDI, here a RGB color value
// and no color index is expected.
int     vsf_color( int handle, int color )
{
	((VirtualDevice *)handle)->rgbFillColor = color ; 
	return color ;
}

int     vsf_perimeter( int handle, int per_vis )
{
	((VirtualDevice *)handle)->fillPerimeter = per_vis ; 
	return per_vis ;
}

//-------------- output functions -------------------------

// Get a fill UI_PALETTE from a rgb color.
UI_PALETTE *VirtualDevice::GetPalette(int rgb)
{
  static UI_PALETTE pal ;

  pal.colorForeground = 
  pal.colorBackground = rgb ; 
  pal.fillPattern = PTN_RGB_COLOR ;

  return &pal ;
}

UI_PALETTE *VirtualDevice::GetFillPalette()
{
	ZIL_COLOR rgb = rgbFillColor ;
	int fill_style ;

	switch (fillInterior)
	{
	case FIS_SOLID:   fill_style = IP_SOLID  ;
	case FIS_HOLLOW:  fill_style = IP_HOLLOW ;
	case FIS_PATTERN: fill_style = fillStyle ;
	}
	int red   = GetRValue(rgb) ;
	int green = GetGValue(rgb) ;
	int blue  = GetBValue(rgb) ;
	int full  = 0xFF ;
	// 8 is IP_SOLID (solid fill pattern)
	red   = red   + (8 - fillStyle) * (full - red  ) / 8 ; 
	green = green + (8 - fillStyle) * (full - green) / 8 ; 
	blue  = blue  + (8 - fillStyle) * (full - blue ) / 8 ; 
	rgb = RGB(red,green,blue) ;
	return GetPalette(rgb) ;
}


UI_PALETTE *VirtualDevice::GetLinePalette()
{
	ZIL_COLOR rgb = rgbLineColor ;
	int degree = 8 ; // normal solid line

	switch (lineType)
	{
	case DOT: degree = 3 ; break ;
	}
	int red   = GetRValue(rgb) ;
	int green = GetGValue(rgb) ;
	int blue  = GetBValue(rgb) ;
	int full  = 0xFF ;

	red   = red   + (8 - degree) * (full - red  ) / 8 ; 
	green = green + (8 - degree) * (full - green) / 8 ; 
	blue  = blue  + (8 - degree) * (full - blue ) / 8 ; 
	rgb = RGB(red,green,blue) ;
	return GetPalette(rgb) ;
}


void v_pline( int handle, int count, int *pxyarray )
{
	VirtualDevice *vd = (VirtualDevice *)handle ;
	for (int i = 0 ; i < count - 1 ; i++)
	{
		int j = i * 2 ;
		vd->dsp->Line( vd->scrID, 
			pxyarray[j  ], pxyarray[j+1], 
			pxyarray[j+2], pxyarray[j+3],
			vd->GetLinePalette(),
			vd->lineWidth, /* xor */ FALSE) ;
	}
}

void    v_fillarea( int handle, int count, int *pxyarray )
{
	// The polygon must be closed.
	// => Copy first point to the end of the array.
	int *buff = new int[(count+1)*2] ;
	assert (buff != NULL) ;
	memcpy(buff, pxyarray, count * 2 * sizeof(int)) ;
	buff[count*2  ] = buff[0] ;
	buff[count*2+1] = buff[1] ;

	VirtualDevice *vd = (VirtualDevice *)handle ;
	// inner area
	vd->dsp->Polygon( vd->scrID, count+1, buff, 
		vd->GetFillPalette(), TRUE, 
		/*_xor*/FALSE ) ;
	// frame line
	if (vd->fillPerimeter)  
		vd->dsp->Polygon( vd->scrID, count+1, buff, 
			vd->GetPalette(vd->rgbLineColor), FALSE, 
			/*_xor*/FALSE ) ;
	delete[] buff ;
}


void    v_gtext( int handle, int x, int y, char *string )
{
	VirtualDevice *vd = (VirtualDevice *)handle ;

	int left, top ;
	int w = vd->dsp->TextWidth (string, vd->scrID) ;
	int h = vd->dsp->TextHeight("Wq"  , vd->scrID) ;

	// Warning: both Visual C++ and Pure C #define TA_... 
	switch (vd->textAlignHor)
	{
	case /*TA_LEFT*/  0: left = x       ; break ;
	case /*TA_CENTER*/1: left = x - w/2 ; break ;
	case /*TA_RIGHT*/ 2: left = x - w   ; break ;
	}
	switch (vd->textAlignVer)
	{
	case /*TA_BASELINE*/0: top = y - h*3/4 ; break ; // estimated
	case /*TA_HALF*/    1: top = y - h/2   ; break ;
	case /*TA_ASCENT*/  2: top = y - h/5   ; break ; // estimated
	case /*TA_BOTTOM*/  3: top = y - h     ; break ;
	case /*TA_DESCENT*/ 4: top = y - h*4/5 ; break ; // estimated
	case /*TA_TOP*/     5: top = y         ; break ; 
	}

    vd->dsp->Text( vd->scrID, left, top,
      string, vd->GetPalette(vd->rgbTextColor), 
	  /*length*/-1, /*vd->fill*/FALSE,
	  /*_xor*/FALSE) ;    
}


void    v_bar( int handle, int *pxyarray )
{
	VirtualDevice *vd = (VirtualDevice *)handle ;
	// inner area
	vd->dsp->Rectangle( vd->scrID, 
		pxyarray[0], pxyarray[1], 
	    pxyarray[2], pxyarray[3], 
	    vd->GetFillPalette(), vd->lineWidth,
        TRUE,
        /*_xor*/FALSE ) ;
	// frame
	if (vd->fillPerimeter) 
		vd->dsp->Rectangle( vd->scrID, 
			pxyarray[0], pxyarray[1], 
		    pxyarray[2], pxyarray[3], 
			vd->GetPalette(vd->rgbLineColor), vd->lineWidth,
			FALSE, 
		    /*_xor*/FALSE ) ;
}


void	vr_recfl(int handle, int *pxyarray) 
{
	VirtualDevice *vd = (VirtualDevice *)handle ;
	vd->dsp->Rectangle( vd->scrID, 
		pxyarray[0], pxyarray[1], 
	    pxyarray[2], pxyarray[3], 
	    vd->GetFillPalette(), vd->lineWidth,
        /*fill*/TRUE, 
        /*_xor*/FALSE ) ;
}


void    v_circle( int handle, int x, int y, int radius )
{
	v_ellpie( handle, x,y, radius,radius, 0,0 ) ;
}

void    v_ellpie( int handle, int x, int y, int xradius,
                  int yradius, int begang, int endang )
{
  // note: VDI expects 1/10 degrees angles [0..3600].
  VirtualDevice *vd = (VirtualDevice *)handle ;
  // inner area
  vd->dsp->Ellipse( vd->scrID, x,y,
      (begang+5)/10, (endang+5)/10, xradius, yradius,
      vd->GetFillPalette(), TRUE, 
      /*_xor*/ FALSE) ;
  // frame
  if (vd->fillPerimeter) 
      vd->dsp->Ellipse( vd->scrID, x,y,
        (begang+5)/10, (endang+5)/10, xradius, yradius,
        vd->GetPalette(vd->rgbLineColor), FALSE, 
        /*_xor*/ FALSE) ;
}

void    v_ellipse( int handle, int x, int y, int xradius,
                   int yradius  )
{
	v_ellpie( handle, x,y, xradius,yradius, 0,0 ) ;
}

void    v_rfbox ( int handle, int *pxyarray )
{
	// ???? How to emulate this ???
	v_bar(handle, pxyarray) ;
} 

