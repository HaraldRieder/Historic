MIDI_PRT.U is the source for the plain text and HTML documentation.
You need the shareware tool UDO version 6 from Dirk Hagedorn to 
produce the documentation. It is a tool of the pre-XML and pre-XSLT
era which allows to generate various output formats from the same 
documentation source: rich text, man pages, Windows help, ...