Requires Microsoft Visual Studio 6.0, wxWindows 2.4.2 
and by own library from the my_libs dir.

The WXWIN environment variable must be set to the installation
dir. of wxWindows (newer versions are called wxWidgets).