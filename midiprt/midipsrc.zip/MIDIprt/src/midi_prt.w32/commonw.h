///////////////////////////////////////////////////////////////////////////////
// Purpose:     Common definitions for the MIDI File Printer windows.
// Author:      Harald Rieder
// RCS-ID:      $Id: commonw.h,v 1.7 2005/04/19 18:40:16 Harald Exp $
// Copyright:   (c) 2004 Harald Rieder, Stuttgart, Deutschland
// Licence:     free for private use
///////////////////////////////////////////////////////////////////////////////

#ifndef MFPCOMMONWINDOW_H
#define MFPCOMMONWINDOW_H

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif
#include "wx/msw/font.h"   // wxNativeFontInfo
#include "wx/fontutil.h"
#include "wx/msw/tglbtn.h" // wxToggleButton
#include "wx/tglbtn.h"

#pragma warning( disable : 4786 ) // otherwise too many warnings because of <set> compiliation

#define MFP_TITLE "Mad Harry's MIDI File Printer"
#define MFP_DEFAULT_PROFILE "MIDI_PRT.MI$"

#define MIDI_CHANNELS 16	/**< MIDI files support 16 channels per track */

/** distance between control and frame(s) in pels */
static const int MFP_SPACING = 10 ; 

/** path of the application with terminating slash */
extern wxString apppath ;

/** pointer to application object */
extern wxApp * app ; 

#endif // include blocker