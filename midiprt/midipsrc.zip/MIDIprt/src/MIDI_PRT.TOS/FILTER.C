/**************************************************************
*
*                FILTER.C
*
**************************************************************/

#include <string.h>   /* because of memcmp(), ... */
#include <stdlib.h>   /* because of atol(), ... */

#if defined (__PUREC__)
#	include <acs.h>
#	include <acsplus.h>
#	include "messages.h"
#	include "filter.h"
#	include "filter.ah"
#endif
#include <acs_plus.h>

#include "filter.hpp"


#if defined (__PUREC__)

/* GEM-object numbers for channel buttons 0..F */
static int channel_buttons[16] = 
	{ _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _A, _B, _C, _D, _E, _F } ;


static INT16 keys(Awindow *wi, INT16 kstate, INT16 key)
{
	INT16 alt = NKF_CTRL | NKF_SHIFT ;

	/* If slider is disabled keys shall not move it. */
	if ( !(wi->work[TRACK_SLIDER].ob_state & DISABLED) ) 
		switch (ACSblk->ev_mkreturn & 0xFF)
	{
	case NK_RIGHT:
		if (ACSblk->ev_mkreturn & alt)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_NEXTPAGE, NULL); 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_NEXT, NULL); 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	case NK_LEFT:
		if (ACSblk->ev_mkreturn & alt)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_PREVPAGE, NULL); 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_PREV, NULL); 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	case NK_CLRHOME:
		if (ACSblk->ev_mkreturn & alt)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_END, NULL) ; 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_BEGIN, NULL) ;
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	}
	/* forward event to ACS for further treatment (e.g. by the desktop) */
	return Awi_keys(wi, kstate, key) ;
}


static void update_channel_buttons(Awindow *wi)
{
	int i ;
	FILTER_DB *db = wi->user ;
	
	for (i = 0 ; i < 16 ; i++)
	{
		OBJECT *o = wi->work + channel_buttons[i] ;
		INT16 orig_state = o->ob_state ;
		if ( !db ||
		     db->track[db->current_track].filter & DISABLED ||
		     !(db->track[db->current_track].channels & (0x1 << i)) )
		{
			Aob_puttext(wi->work, channel_buttons[i], "-") ;
			o->ob_state |= DISABLED ;
			o->ob_state &= ~SELECTED ;
		}
		else 
		{
			Aob_printf(wi->work, channel_buttons[i], "%X", i) ;
			o->ob_state &= ~DISABLED ;
			if ( db->track[db->current_track].ch_filter & (1<<i) )
			     o->ob_state |= SELECTED ;
			else o->ob_state &= ~SELECTED ;
		}
		if (orig_state != o->ob_state)
			Awi_obchange(wi, channel_buttons[i], -1) ;
	}
}


static void update_on_off_buttons(Awindow *wi)
{
	FILTER_DB *db = wi->user ;
	INT16 orig_on_state  = wi->work[ON].ob_state ;

	wi->work[ON ].ob_state |= DISABLED ;
	wi->work[OFF].ob_state |= DISABLED ;
	
	if (db) switch ( db->track[db->current_track].filter )
	{
	case TRUE:
		wi->work[ON ].ob_state |= SELECTED ;
		wi->work[OFF].ob_state &= ~SELECTED ;
		wi->work[ON ].ob_state &= ~DISABLED ;
		wi->work[OFF].ob_state &= ~DISABLED ;
		break ;
	case FALSE:
		wi->work[OFF].ob_state |= SELECTED ;
		wi->work[ON ].ob_state &= ~SELECTED ;
		wi->work[ON ].ob_state &= ~DISABLED ;
		wi->work[OFF].ob_state &= ~DISABLED ;
		break ;
	}
	if (orig_on_state != wi->work[ON].ob_state)
	{
		Awi_obredraw(wi, ON ) ;
		Awi_obredraw(wi, OFF) ;
	}
}

static void update_string_buttons(Awindow *wi)
{
	FILTER_DB *db = wi->user ;
	
	/* for redraw optimization: */
	INT16 orig_name_state   = wi->work[TRACK_NAME_BUTTON].ob_state ;
	INT16 orig_device_state = wi->work[DEVICE_BUTTON    ].ob_state ;
	INT16 orig_instr_state  = wi->work[INSTRUMENT_BUTTON].ob_state ;
	INT16 orig_text_state   = wi->work[TEXT_BUTTON      ].ob_state ;

	if (!db || db->track[db->current_track].filter != TRUE) 
	{
		wi->work[TRACK_NAME_BUTTON].ob_state |= DISABLED ;
		wi->work[DEVICE_BUTTON    ].ob_state |= DISABLED ;
		wi->work[INSTRUMENT_BUTTON].ob_state |= DISABLED ;
		wi->work[TEXT_BUTTON      ].ob_state |= DISABLED ;
	}
	else
	{
		wi->work[TRACK_NAME_BUTTON].ob_state &= ~DISABLED ;
		wi->work[DEVICE_BUTTON    ].ob_state &= ~DISABLED ;
		wi->work[INSTRUMENT_BUTTON].ob_state &= ~DISABLED ;
		wi->work[TEXT_BUTTON      ].ob_state &= ~DISABLED ;
	}
	wi->work[TRACK_NAME_BUTTON].ob_state &= ~SELECTED ;
	wi->work[DEVICE_BUTTON    ].ob_state &= ~SELECTED ;
	wi->work[INSTRUMENT_BUTTON].ob_state &= ~SELECTED ;
	wi->work[TEXT_BUTTON      ].ob_state &= ~SELECTED ;
	
	if (db) switch ( db->track[db->current_track].select )
	{
	case TR_NAME  : wi->work[TRACK_NAME_BUTTON].ob_state |= SELECTED ; break ;
	case TR_DEVICE: wi->work[DEVICE_BUTTON    ].ob_state |= SELECTED ; break ;
	case TR_INSTR : wi->work[INSTRUMENT_BUTTON].ob_state |= SELECTED ; break ;
	case TR_TEXT  : wi->work[TEXT_BUTTON      ].ob_state |= SELECTED ; break ;
	}
	if (orig_name_state != wi->work[TRACK_NAME_BUTTON].ob_state)
		Awi_obredraw(wi, TRACK_NAME_BUTTON) ;
	if (orig_device_state != wi->work[DEVICE_BUTTON].ob_state)
		Awi_obredraw(wi, DEVICE_BUTTON) ;
	if (orig_instr_state != wi->work[INSTRUMENT_BUTTON].ob_state)
		Awi_obredraw(wi, INSTRUMENT_BUTTON) ;
	if (orig_text_state != wi->work[TEXT_BUTTON].ob_state)
		Awi_obredraw(wi, TEXT_BUTTON) ;
}


static void string_to_object(Awindow *wi, INT16 obnr, const char *str)
{
	char *txt = wi->work[obnr].ob_spec.tedinfo->te_ptext ;
	char *s = str ? (char *)str : "" ;
	if ( strcmp(s, txt) )
	{
		/* new string is different from old one */
		/* according to ACS documentation, it is allowed to write strings
		   longer than 19 to G_BOXTEXT of length 19 */
		Aob_puttext(wi->work, obnr, s) ;
		Awi_obchange(wi, obnr, -1) ;
	}
}


static char * track_slider_live(void *wi_, long pos)
{
	char *text ;
	Awindow *wi = wi_ ;
	FILTER_DB *db = wi?wi->user:NULL ;
	
	if (!db) return "?" ;
	
	text = A_int_live(&(db->current_track), pos) ;
	{
		/* string might be longer than object text,
		   but according to ACS documentation this is allowed for
		   G_BOXTEXT objects */
		string_to_object(wi, TRACK_NAME, db->track[db->current_track].name      ) ;
		string_to_object(wi, DEVICE    , db->track[db->current_track].device    ) ;
		string_to_object(wi, INSTRUMENT, db->track[db->current_track].instrument) ;
		string_to_object(wi, TEXT      , db->track[db->current_track].text      ) ;
	}
	update_channel_buttons(wi) ;
	update_on_off_buttons (wi) ;
	update_string_buttons (wi) ;
	
	return text ;
}


static void redisplay(Awindow *wi)
{
	FILTER_DB *db = wi->user ;
	SLLIVE sllive ; 

	/* fast exit */
	if (ACSblk->appexit) return ;
	
	Awi_setinfo(wi, db?db->filename:"?") ;

	if (!db)
	{
		/* set live procedures */
		sllive.call = A_slider_dead ;
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLCALL, &sllive) ; 
		string_to_object(wi, TRACK_NAME, NULL) ;
		string_to_object(wi, DEVICE    , NULL) ;
		string_to_object(wi, INSTRUMENT, NULL) ;
		string_to_object(wi, TEXT      , NULL) ;
		update_channel_buttons(wi) ;
		update_on_off_buttons (wi) ;
		update_string_buttons (wi) ;
	}
	else
	{
		/* set live procedures and positions */
		sllive.call = track_slider_live ; 
		sllive.obj  = wi ; 
		A_slider_init(wi->work + TRACK_SLIDER, db->number_tracks - 1, 3, db->current_track, &sllive) ;
	}
    /* refresh text */
	Auo_slider(wi->work + TRACK_SLIDER , AUO_SLLIVE, NULL) ; 

	/* redisplay */
	Auo_slider(wi->work + TRACK_SLIDER , AUO_FULLUPDATE, NULL) ; 
}

static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	switch (task)
	{	
		case AS_TERM: 
			if (ACSblk->appexit)
				Awi_delete(wi) ; 
			break ; 
		case AS_INFO: 
/*			A_dialog(&FILTER_INFO) ;
			Awi_dialog(&INFO_INFO_WINDOW) ; */
			break ;
		case SET_DATABASE:
			if (wi->user != in_out)
				/* redisplay with new database */
				service(wi, DATA_CHANGED, in_out) ;
			break ;
		case INVALIDATE_DATABASE:
			if (wi->user == in_out)
				/* this is my database, it shall become invalid */
				service(wi, SET_DATABASE, NULL) ;
			break ;
		case DATA_CHANGED:
			wi->user = in_out ;
			redisplay(wi) ;
			break ;
		default: return Awi_service(wi, task, in_out) ;
	}
	return TRUE ;	/* task has been treated */
}


static Awindow *create (void *parent)
{
	Awindow *wi = Awi_create(parent) ;
	if (wi)
		redisplay(wi) ;
	return wi ;
}


static void button(void) 
	/* click procedure for the FILTER object's buttons. */
{
	Awindow *wi = ACSblk->ev_window ;
	FILTER_DB *db = wi->user ;
	int i ;
	
	if (!db) return ;
	
	for (i = 0 ; i < 16 ; i++)
		if ( ACSblk->ev_obnr == channel_buttons[i] )
			db->track[db->current_track].ch_filter ^= 1<<i ; 

	switch (ACSblk->ev_obnr)
	{				
	case ALL_CHANNELS_ON : 
		db->track[db->current_track].ch_filter = 0xFFFF ;
		update_channel_buttons(wi) ; 
		break ;
	case ALL_CHANNELS_OFF: 
		db->track[db->current_track].ch_filter = 0x0000 ; 
		update_channel_buttons(wi) ; 
		break ;
	
	case ON:  
		db->track[db->current_track].filter = TRUE  ; 
		update_channel_buttons(wi) ;
		update_string_buttons(wi) ;
		break ;
	case OFF: 
		db->track[db->current_track].filter = FALSE ; 
		update_channel_buttons(wi) ;
		update_string_buttons(wi) ;
		break ;
	
	case ALL_TRACKS_ON : 
		for (i = 0 ; i < db->number_tracks ; i++)
			if ( !(db->track[i].filter & DISABLED) )
				db->track[i].filter = TRUE ;
		update_on_off_buttons(wi) ;
		break ;

	case ALL_TRACKS_OFF:
		for (i = 0 ; i < db->number_tracks ; i++)
			if ( !(db->track[i].filter & DISABLED) )
				db->track[i].filter = FALSE ;
		update_on_off_buttons(wi) ;
		break ;
		
	case TRACK_NAME_BUTTON: db->track[db->current_track].select = TR_NAME   ; break ;
	case DEVICE_BUTTON:     db->track[db->current_track].select = TR_DEVICE ; break ;
	case INSTRUMENT_BUTTON: db->track[db->current_track].select = TR_INSTR  ; break ;
	case TEXT_BUTTON:       db->track[db->current_track].select = TR_TEXT   ; break ;
	}
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}

#endif /* PURE C */