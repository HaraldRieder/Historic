/**************************************************************
*
*                MAIN.C
*
**************************************************************/

#define _STRING_(x) #x /* 1234 => "1234" */

#include <string.h>     /* because of strrchr(), ... */
#include <errno.h>
#include <stdio.h>      /* because of fopen(), ... */
#include <stdlib.h>     /* atoi(), ... */

#include <acs.h>
#include <acsplus.h>
#include <acs_plus.h>   
#include <diskfile.h>
#include <diskfile.ah>	/* alert strings */
#include <notimtab.h>   
#include <graphic.h>

#include "common.h"
#include "messages.h"

/* channel filter values */
#define all_channels_on   0xffff  
#define all_channels_off  0x0000 

#include "version.h"
#include "trcktabl.h"
#include "draw.h"

extern Awindow PUR_MODULE ; /* prototype of module window of ACS Pure Desk */

Awindow *create(void *not_used) ;
void     destroy (Awindow *wi) ;
static int cdecl draw(PARMBLK *parmblk) ;

#include "main.h"
#include "main.ah"
#include "params.h"
#include "params.hpp"
#include "filter.h"
#include "filter.hpp"
#include "info.h"
#include "info.hpp"
#include "profile.h"
#include "print.hpp"
#include "stack.h"

/*************** GLOBAL VARIABLES **************************/

/* parameters queried from ACS screen workstation */
static int screen_out[57] ;

/* extended ACSblk VDI handle with RGB info (direct color) */
static INT32 xhandle ;

/* extension for file selector (e.g. MI*) */
/*static char file_extension[] = "1,2,3,4,5,MID,MIDI,SMF,mid,midi,smf\0" ;*/
/* <= ACS 3� vom 2002-4-1 f�hrt unter Single TOS bei Af_fileselect() leider zu "*.1,*.2,*.3," */
/* <= bei Af_select() unter Single TOS zu "*.1,2,3" */
static char file_extension[8] = "\0\0\0\0\0\0\0\0" ;


/* common path for file selector */
static char path[PATHNAME_LENGTH] ;

/* default profile path */
static char default_profile[PATHNAME_LENGTH] ;

/* currently keeps list of open files only */
static FILE *config_file  = NULL ;
static char config_filepath[PATHNAME_LENGTH] ;

/* counter for number of constructor calls */
static int incarnation_counter = 0 ;

/* makes sliders quiet when live procedure 
   is called by program (and not by the user), if set to FALSE */
static int messages = TRUE ;

static PROFILED_OPTIONS options ;

static Awindow *params_wi, *filter_wi, *info_wi ;

/* The current main window: */
/* only this will react on messages from the slave windows listed above. */
static Awindow *current_wi ;

/* common text buffer */
static char buff[256] ;


/************* DESKTOP MENU CLICK PROCEDURES *********************/

static void update_profile_items(void) ;

static void validate_from_to(DOCUMENT *db)
	/* we need this function since "to" must be always less or equal
	   to the number of pages of the generated layout, which may change */
{
	/* note: from > to is allowed */
	db->print.stngs.first_page = max(1, min(db->layout.npgs, db->print.stngs.first_page)) ;
	db->print.stngs.last_page  = max(1, min(db->layout.npgs, db->print.stngs.last_page )) ;
}

static void update_print_items(void) 
{
	Awindow *wi = Awi_root() ;

	if (current_wi)
	{	
		DOCUMENT *db = current_wi->user ;
		validate_from_to(db) ;	
		if (vq_gdos() && db->layout.npgs > 0)
		{
			wi->menu[PRINT].ob_state &= ~DISABLED ;
			wi->menu[_COPY].ob_state &= ~DISABLED ;
			return ;
		}
	}
	wi->menu[PRINT].ob_state |= DISABLED ;
	wi->menu[_COPY].ob_state |= DISABLED ;
}

static void update_file_items(Awindow *new_current_wi)
{
	Awindow *wi = Awi_root() ;

	current_wi = new_current_wi ;
	if ( current_wi )
	{
		wi->menu[CLOSE_MIDI_FILE     ].ob_state &= ~DISABLED ;
		wi->menu[SAVE_AS             ].ob_state &= ~DISABLED ;
		wi->menu[PROFILE_LOAD_DEFAULT].ob_state &= ~DISABLED ;
		wi->menu[PROFILE_SAVE_DEFAULT].ob_state &= ~DISABLED ;
		update_profile_items() ;
	}
	else
	{
		wi->menu[CLOSE_MIDI_FILE     ].ob_state |= DISABLED ;
		wi->menu[SAVE_AS             ].ob_state |= DISABLED ;
		wi->menu[PROFILE_LOAD_DEFAULT].ob_state |= DISABLED ;
		wi->menu[PROFILE_SAVE_DEFAULT].ob_state |= DISABLED ;
		wi->menu[PROFILE_REMOVE      ].ob_state |= DISABLED ;
		wi->menu[PROFILE_RELOAD      ].ob_state |= DISABLED ;
		wi->menu[PROFILE_ATTACH      ].ob_state |= DISABLED ;
	}
	update_print_items() ;
}

static void open_midi_file (void) { create(NULL) ; }
static void close_midi_file(void) {	destroy(current_wi) ; }

static void save_as(void)
{
	static char save_as_path[256] = "" ;
	DOCUMENT *m = current_wi->user ;
	
	sprintf(buff, "Save %s as:", m->filename) ;
	if (Af_select(buff, save_as_path, file_extension))
	{
		if ( Fcopy(save_as_path, m->pathname) != 0 )
		{
			my_alert_str(COPY_ERROR, m->pathname) ;
			return ;
		}
		if (m->has_profile)
		{
			profile_path(buff, save_as_path) ;
			if ( Fcopy(buff, m->profile) != 0 )
				my_alert_str(COPY_ERROR, m->profile) ;
		}
	}
}


/*** profile ***/

static void update_profile_items(void)
{
	DOCUMENT *db = current_wi->user ;
	Awindow *wi = Awi_root() ;

	if (db->has_profile)
	{
		wi->menu[PROFILE_REMOVE].ob_state &= ~DISABLED ;
		wi->menu[PROFILE_RELOAD].ob_state &= ~DISABLED ;
		wi->menu[PROFILE_ATTACH].ob_state |= DISABLED ;
	}
	else
	{
		wi->menu[PROFILE_REMOVE].ob_state |= DISABLED ;
		wi->menu[PROFILE_RELOAD].ob_state |= DISABLED ;
		wi->menu[PROFILE_ATTACH].ob_state &= ~DISABLED ;
	}
}

static void do_write_profile(Awindow *wi)
{
	DOCUMENT *db = wi->user ;

	if ( write_profile(db->profile, ACSblk->apppath, 
			&(db->params), &(db->filter), &(db->opts), FALSE) != 0 )
	{
		my_alert_str(ACSblk->description->mess[AD_WRITE_STR], db->profile) ;
		return ;
	}
	db->has_profile = TRUE ;
}

static void profile_attach(void)
{
	do_write_profile(current_wi) ;
	update_profile_items() ;
}

static void profile_remove(void)
{
	DOCUMENT *db = current_wi->user ;

	if ( unlink(db->profile) != 0 ) switch (errno)
	{
	case ENOENT: my_alert_str(FILE_NOT_FOUND, db->profile) ; return ;
	case EACCES: my_alert_str(ACCESS_DENIED , db->profile) ; return ;
	}
	db->has_profile = FALSE ;
	update_profile_items() ;
}

static void do_load_default_profile(Awindow *wi) 
	/* 1. tries to load default profile */
	/* 2. if not OK uses fix coded defaults */
{
	DOCUMENT *db = wi->user ;
	static already_warned = FALSE ;

	if ( read_profile(default_profile, ACSblk->apppath,
			&(db->params), &(db->filter), &(db->opts), TRUE) != 0 )
	{
		if ( !already_warned )
		{
			my_alert_str(NO_DEFAULT_PROFILE, NULL) ;
			already_warned = TRUE ;
		}
	}
}

static void do_load_profile(Awindow *wi)
	/* 1. tries to load specific profile */
	/* 2. if not OK tries to load default profile */
	/* 3. if not OK uses fix coded defaults */
{
	DOCUMENT *db = wi -> user ;
	
	/* init defaults from code */
	default_doc_params(&(db->opts)) ;
	init_info_from_tracks  (&(db->info  ), db->track_table, db->filter.number_tracks) ;
	init_params_from_tracks(&(db->params), db->track_table, db->filter.number_tracks) ;
	init_filter_from_tracks(&(db->filter), db->track_table) ;
	
	if ( read_profile(db->profile, ACSblk->apppath,
			&(db->params), &(db->filter), &(db->opts), FALSE) != 0 )
	{
		/* no specific profile */
		db->has_profile = FALSE ;
		/* try to load default profile */
		do_load_default_profile(wi) ;
	}
	else db->has_profile = TRUE ;
	
	do_load_scheme(&(db->params), db->params.scheme_path) ;
}

static void profile_reload(void)
{
	DOCUMENT *db = current_wi->user ;

	if ( my_alert_str(RELOAD_PROFILE, db->pathname) != 1 )
		do_load_profile(current_wi) ;

	params_wi ->service(params_wi , DATA_CHANGED, &(db->params)) ;
	filter_wi ->service(filter_wi , DATA_CHANGED, &(db->filter)) ;
	current_wi->service(current_wi, DO_REDRAW, current_wi) ;
}


static void profile_save_default(void)
{
	DOCUMENT *db = current_wi->user ;
		
	if ( write_profile(
			default_profile, ACSblk->apppath,
			&(db->params), 
			&(db->filter),
			&(db->opts), TRUE) != 0)
		my_alert_str(ACSblk->description->mess[AD_WRITE_STR], buff) ;
}


static void update_menu(void) ;

static void profile_load_default(void)
{
	DOCUMENT *db = current_wi->user ;
	
	do_load_default_profile(current_wi) ;		
	params_wi ->service(params_wi , DATA_CHANGED, &(db->params)) ;
	filter_wi ->service(filter_wi , DATA_CHANGED, &(db->filter)) ;
	current_wi->service(current_wi, DO_REDRAW, current_wi) ;
	update_menu() ;
}


/*** print ***/

/* my own print dialog only: */

#define PRINT_TITLE_LEN 37
#define PRINTER_NAME_LEN 34

static char print_popup[500] ;

static void set_printer(Awindow *wi, char *printer_name)
{
  DOCUMENT *db = current_wi->user ;
  int driver_id = atoi(printer_name) ;
  if (driver_id < 21 || driver_id > 30)
  {
    /* is not a printer */
	wi->work[OUTPUT_PRINTER].ob_state &= ~SELECTED ;
    *buff = 0 ; /* clear string */
  }
  else
  {
	wi->work[OUTPUT_PRINTER].ob_state |= SELECTED ;
    wi->work[PRINT_OK].ob_state &= ~DISABLED ;
  	Awi_obchange(wi, PRINT_OK, -1) ;
    db->print.stngs.driver_id = driver_id ;
    strncpy(db->print.stngs.device, printer_name, sizeof(db->print.stngs.device) - 1) ;
    strcpy(buff, printer_name) ;
  }
  buff[PRINTER_NAME_LEN] = 0 ; /* avoid string overflow */
/*  Aob_puttext(wi->work, PRINTER_NAME, printer_name) ; crashes! */
  strcpy(wi->work[PRINTER_NAME].ob_spec.free_string, buff) ;
  Awi_obredraw(wi, PRINTER_NAME) ;
}

static INT16 print_open(Awindow *wi)
{
  static INT16 print_in[11] ;
  static INT16 print_out[57] ;
  static int has_printer, has_meta, has_image ;
  int i ;
  DOCUMENT *db = current_wi->user ;
  
  print_in[0] = db->print.stngs.driver_id ;
  for ( i = 1 ; i <= 8 ; i++ ) 
    print_in[i] = 1 ; 
  print_in[9] = 0 ; 
  print_in[10] = 2 /* RC */ ; 

  /* copy data to GEM objects */
  set_printer(wi, db->print.stngs.device) ;
  strcpy(buff, db->filename) ;
  buff[PRINT_TITLE_LEN] = 0 ; /* avoid string overflow */
  Aob_puttext(wi->work, PRINT_TITLE , buff) ;
  Aob_printf (wi->work, PRINT_FROM  , "%d", (int)db->print.stngs.first_page) ;
  Aob_printf (wi->work, PRINT_TO    , "%d", (int)db->print.stngs.last_page ) ;
  /*Aob_printf (wi->work, PRINT_SCALE, "%d", (int)(db->print.stngs.scale * 100 / 0x10000L)) ;*/
  Aob_printf (wi->work, PRINT_COPIES, "%d", (int)db->print.stngs.no_copies  ) ;
  if (db->print.stngs.page_flags & PG_ODD_PAGES)
    wi->work[PRINT_ODD].ob_state |= SELECTED ;
  else
    wi->work[PRINT_ODD].ob_state &= ~SELECTED ;
  if (db->print.stngs.page_flags & PG_EVEN_PAGES)
    wi->work[PRINT_EVEN].ob_state |= SELECTED ;
  else
    wi->work[PRINT_EVEN].ob_state &= ~SELECTED ;
  switch (db->print.stngs.driver_id)
  {
  case 0:
    break ; /* not yet initialized */
  case 31:
    Aob_puttext(wi->work, METAFILE_NAME, db->print.stngs.device) ;
	wi->work[OUTPUT_METAFILE].ob_state |= SELECTED ;
    wi->work[PRINT_OK].ob_state &= ~DISABLED ;
	break ;
  case 91:
    Aob_puttext(wi->work, IMAGEFILE_NAME, db->print.stngs.device) ;
	wi->work[OUTPUT_IMAGEFILE].ob_state |= SELECTED ;
    wi->work[PRINT_OK].ob_state &= ~DISABLED ;
	break ;
  }  
  /* nothing known about printer drivers yet ? */
  if (print_popup[0] == 0)
  {
    for (i = 21 ; i <= 91 ; i++)
    {
      INT16 handle ;
      print_in[0] = i ;
      v_opnwk(print_in, &handle, print_out) ;
      if (handle)
      {
        int x = print_out[3] ; /* pixel width in micrometers */
        int y = print_out[4] ; /* pixel height in micrometers */
        x = (int)(1.0f/x * 25200.0 + 0.5) ; /* dpi */ 
        y = (int)(1.0f/y * 25200.0 + 0.5) ; /* dpi */ 
        if (i < 31)
        {
          /* is a printer */
          if (print_popup[0] != 0)
            strcat(print_popup, "|") ;
          vq_extnd(handle, 1 /* extended info */, print_out) ;
          if (print_out[4] >= 24)
            sprintf(buff, "%d (true color, %dx%d dpi)", i,x,y) ;
          else if (print_out[4] >= 15)
            sprintf(buff, "%d (high color, %dx%d dpi)", i,x,y) ;
          else
            sprintf(buff, "%d (%d colors, %dx%d dpi)", i, 1 << print_out[4], x,y) ;
          if (print_popup[0] == 0)
          {
            /* first found is default printer */
            set_printer(wi, buff) ;
          }
          strcat(print_popup, buff) ;

          /* user may trigger printing */
          has_printer = TRUE ;
        }
        else if (i == 31)
        {
          has_meta = TRUE ;
          i = 90 ; /* continue with image file driver */
        }
        else if (i == 91)
          has_image = TRUE ;
      }
    }
  }
  if (has_printer)
    wi->work[OUTPUT_PRINTER].ob_state &= ~DISABLED ;
  if (has_meta)
    /* user may generate metafiles */
    wi->work[OUTPUT_METAFILE].ob_state &= ~DISABLED ;
  if (has_image)
    /* user may generate image files */
    wi->work[OUTPUT_IMAGEFILE].ob_state &= ~DISABLED ;

  return Awi_open(wi) ;
}

static void print_from_to(void)
{
	OBJECT *print_dialog = ACSblk->ev_object ;
	
	print_dialog[PRINT_FROM_TO].ob_state |= SELECTED ;
	print_dialog[PRINT_CURRENT].ob_state &= ~SELECTED ;
	print_dialog[PRINT_ALL    ].ob_state &= ~SELECTED ;
	Awi_obchange(ACSblk->ev_window, PRINT_FROM_TO, -1) ;
	Awi_obchange(ACSblk->ev_window, PRINT_CURRENT, -1) ;
	Awi_obchange(ACSblk->ev_window, PRINT_ALL    , -1) ;
}

static void output_printer(void)
{
	ACSblk->ev_object[OUTPUT_PRINTER  ].ob_state |= SELECTED ;
  	ACSblk->ev_object[OUTPUT_METAFILE ].ob_state &= ~SELECTED ;
   	ACSblk->ev_object[OUTPUT_IMAGEFILE].ob_state &= ~SELECTED ;
    Awi_obchange(ACSblk->ev_window, OUTPUT_METAFILE , -1) ;
    Awi_obchange(ACSblk->ev_window, OUTPUT_PRINTER  , -1) ;
    Awi_obchange(ACSblk->ev_window, OUTPUT_IMAGEFILE, -1) ;
}


static void select_printer(void)
{
  DOCUMENT *db = current_wi->user ;
  char *selected = strstr(print_popup, db->print.stngs.device) ;
  selected = Ame_strpopup(ACSblk->ev_window, print_popup, selected, 265,-1,-1) ;
  if (selected)
  {
    /* cut away "|" before giving to set_printer() */
    char *separator = strchr(selected, '|') ;
    if (separator)
      *separator = 0 ;
    set_printer(ACSblk->ev_window, selected) ;
    if (separator)
      *separator = '|' ; /* restore */
  }
}


static void select_metafile(void)
{
  Awindow *wi = ACSblk->ev_window ;
  OBJECT *print_dialog = ACSblk->ev_object ;
  char *ext = options.file_selector == LOWER_CASE_MASKS ? ".gem" : ".GEM" ;
  DOCUMENT *db = current_wi->user ;
  char dirtext[] =  "Select meta file directory" ;
  char filetext[] = "Select meta file" ;
  int dir = (options.meta_print_mode == ONE_PER_PAGE) ;
  char *title = dir ? dirtext : filetext ;
	
  char *mid ;

  Aob_gettext(ACSblk->ev_object, METAFILE_NAME, buff) ;
  if (*buff == 0)
  {
	/* init meta file name / dir */
    strcpy(buff, db->pathname) ;
    mid = strrchr(buff, '.') ;
    if (mid == 0 || strnicmp(mid, ".mid", 4))
      /* no MIDI file extension up to now */
      mid = buff + strlen(buff) ;

    /* replace/append extension */
    strcpy(mid, ext) ;
  }

  if ( Af_select(title, buff, ext + 1) )
  {
	db->print.stngs.driver_id = 31 ;

  	/* append file extension if necessary */
  	if (!dir)
  	{
      if ( strstr(buff, ext) - buff != strlen(buff) - strlen(ext) )
        strcat(buff, ext) ;
  	}
  	
  	/* update file name edit field */
  	Aob_puttext(print_dialog, METAFILE_NAME, buff) ;
  	Awi_obchange(wi, METAFILE_NAME, -1) ;

    wi->work[PRINT_OK].ob_state &= ~DISABLED ;
  	Awi_obchange(wi, PRINT_OK, -1) ;
  }
  else
  {
	/* select printer radio button */
	output_printer() ;
  }
}

static void select_imagefile(void)
{
  Awindow *wi = ACSblk->ev_window ;
  OBJECT *print_dialog = ACSblk->ev_object ;
  char *ext = options.file_selector == LOWER_CASE_MASKS ? ".img" : ".IMG" ;
  DOCUMENT *db = current_wi->user ;

  char *mid ;

  Aob_gettext(ACSblk->ev_object, IMAGEFILE_NAME, buff) ;
  if (*buff == 0)
  {
	/* init image file name / dir */
    strcpy(buff, db->pathname) ;
    mid = strrchr(buff, '.') ;
    if (mid == 0 || strnicmp(mid, ".mid", 4))
      /* no MIDI file extension up to now */
      mid = buff + strlen(buff) ;

    /* replace/append extension */
    strcpy(mid, ext) ;
  }

  if ( Af_select("Select image file", buff, ext + 1) )
  {
	db->print.stngs.driver_id = 61 ;

    /* append file extension if necessary */
    if ( strstr(buff, ext) - buff != strlen(buff) - strlen(ext) )
      strcat(buff, ext) ;
   		
   	/* update file name edit field */
   	Aob_puttext(print_dialog, IMAGEFILE_NAME, buff) ;
   	Awi_obchange(wi, IMAGEFILE_NAME, -1) ;

    wi->work[PRINT_OK].ob_state &= ~DISABLED ;
  	Awi_obchange(wi, PRINT_OK, -1) ;
  }
  else
  {
	/* select printer radio button */
	output_printer() ;
  }
}


/* print general: */

static void print(void)
{
	static A_PrintSel ps ;

	DOCUMENT *db = current_wi->user ;
	INT16 zoom = db->opts.zoom ;
	INT16 poptions = 
		PDLG_ALWAYS_COPIES + PDLG_EVENODD + 
		PDLG_ALWAYS_ORIENT + PDLG_PRINT;

	if (options.use_WDIALOG)
	{
		if (db->print.stngs.magic <= 1L)
		{
			/* not yet initialized */
			PRN_DIALOG *pdlg = pdlg_create(0/*open flags don't matter here*/) ;
			if (pdlg)
			{
				pdlg_dflt_settings( pdlg, &(db->print.stngs) ) ;
				pdlg_delete(pdlg) ;
			}
			else 
			{
				my_alert_str(NO_WDIALOG, NULL) ;
				return ;
			}
		}
	}
	else
	{
		/* init self */
		if (db->print.stngs.magic != 1L)
		{
			/*strncpy((char *)&(db->print.stngs.magic), "pset", 4) ;*/
			db->print.stngs.magic      = 1L ;
			db->print.stngs.length     = sizeof(db->print.stngs) ;
			db->print.stngs.scale      = 0x10000L ;
			db->print.stngs.contrast   = 0x10000L ;
			db->print.stngs.brightness = 0x1000L ;
			db->print.stngs.no_copies  = 1 ;
			db->print.stngs.page_flags |= (PG_EVEN_PAGES + PG_ODD_PAGES) ;
			db->print.stngs.first_page = 1 ;
			db->print.stngs.last_page = db->layout.npgs ;
			/* rest was initialized with 0 together with db */
		}
	}
	
	/* for image output */
	db->print.width  = (int)((long)current_wi->work->ob_width  * zoom / MAX_ZOOM) ;
	db->print.height = (int)((long)current_wi->work->ob_height * zoom / MAX_ZOOM) ;
	
	switch (ACSblk->ev_obnr)
	{
	case PRINT:
		/* show print dialog which might send AS_PRINT */
		db->print.copy_page = 0 ;	/* no clipboard copy */
		sprintf(buff, "Print '%s'", db->filename) ;	
		
		if (!options.use_WDIALOG)
		{
			/* use my own print dialog */
			Awindow	*print_wi = Awi_create(&PRINT_WINDOW) ;
			if (print_wi)
			{
				OBJECT *print_dialog = print_wi->work ;
				
				if (Awi_dialog(print_wi) == PRINT_OK)
				{
					/* read texts edited manually from GEM objects */
					if (print_dialog[OUTPUT_IMAGEFILE].ob_state & SELECTED)
						Aob_gettext(print_dialog, IMAGEFILE_NAME, db->print.stngs.device) ;
					else if (print_dialog[OUTPUT_METAFILE].ob_state & SELECTED)
						Aob_gettext(print_dialog, METAFILE_NAME, db->print.stngs.device) ;
					
					if (print_dialog[PRINT_EVEN].ob_state & SELECTED) 
						db->print.stngs.page_flags |= PG_EVEN_PAGES ;
					else 
						db->print.stngs.page_flags &= ~PG_EVEN_PAGES ;
					if (print_dialog[PRINT_ODD].ob_state & SELECTED) 
						db->print.stngs.page_flags |= PG_ODD_PAGES ;
					else 
						db->print.stngs.page_flags &= ~PG_ODD_PAGES ;
						
					Aob_scanf(print_dialog, PRINT_FROM  , "%d", &(db->print.stngs.first_page)) ;
					Aob_scanf(print_dialog, PRINT_TO    , "%d", &(db->print.stngs.last_page )) ;
					Aob_scanf(print_dialog, PRINT_COPIES, "%d", &(db->print.stngs.no_copies )) ;
					db->print.stngs.orientation = 0 ;
					/*int scale = 100 ; /* 100% default */
					Aob_scanf(print_dialog, PRINT_SCALE , "%d", &scale) ;*/
					db->print.stngs.scale = 0x10000L /* * scale / 100 */ ; 
					ps.button = PDLG_OK ;
					ps.settings = &(db->print.stngs) ;
					service(current_wi, AS_PRINT, &ps) ; 
				}
				Awi_delete(print_wi) ;
			}
			return ;
		}
		
/*
#define ASH_PRINT 
#define ASH_PRINT_MODAL
*/
#ifdef ASH_PRINT
		switch ( Ash_print(&(db->print.stngs), -1,-1, options, buff, 
#  ifdef ASH_PRINT_MODAL
				NULL) )
#  else
				current_wi) )
#  endif
		{
		case 0: break ;	/* Cancel pressed */
		case 1: /* OK pressed */
			ps.button = PDLG_OK ;
			ps.settings = &(db->print.stngs) ;
			service(current_wi, AS_PRINT, &ps) ; 
			break ; 
		case 2: break ;	/* non-modal */
		default:
			my_alert_str(NO_WDIALOG, NULL);
		}
#else /* direct call of pdlg_... functions */
		Amo_unbusy() ;
		{
			INT16 flag_3d = ((ACSblk->description->flags & AB_NO3D) != AB_NO3D) ;
			PRN_DIALOG pdlg = pdlg_create( flag_3d );
			if (pdlg)
			{
				ps.button = pdlg_do( pdlg, &(db->print.stngs), buff, poptions );
				ps.settings = &(db->print.stngs) ;
				pdlg_delete( pdlg );	
				service(current_wi, AS_PRINT, &ps) ;
			}
		}
		Amo_busy() ;
#endif
		break ;
	
	case _COPY:
	default:
		/* copy current page to clipboard, send AS_PRINT */
		ps.button = PDLG_OK ;
		ps.settings = &(db->print.stngs) ;
		db->print.copy_page = db->opts.page ; /* copy this page number */
		service(current_wi, AS_PRINT, &ps) ;
	}
}


/*** top windows ***/

static void top_info      (void) { Awi_show(info_wi)   ; }
static void top_parameters(void) { Awi_show(params_wi) ; }
static void top_filter    (void) { Awi_show(filter_wi) ; }


/*** use WDIALOG or own dialogs ***/

static void update_wdialog_items(void)
{
	Awindow *wi = Awi_root() ;
	
	if (options.use_WDIALOG)
	{
		wi->menu[USE_OS_DIALOGS ].ob_state |= CHECKED ;
		wi->menu[USE_OWN_DIALOGS].ob_state &= ~CHECKED ;
		use_WDIALOG(TRUE, screen_out[4]) ; /* to params window */
	}
	else
	{
		wi->menu[USE_OWN_DIALOGS].ob_state |= CHECKED ;
		wi->menu[USE_OS_DIALOGS ].ob_state &= ~CHECKED ;
		use_WDIALOG(FALSE, screen_out[4]) ; /* to params window */
	}
}

static void use_os_dialogs(void)
{
	options.use_WDIALOG = TRUE ;
	update_wdialog_items() ;
}

static void use_own_dialogs(void)
{
	options.use_WDIALOG = FALSE ;
	update_wdialog_items() ;
}


/*** document format ***/

static void update_format_items(void)
{
	Awindow *wi = Awi_root() ;
	
	if (options.format == FORMAT_DIN_A4)
	{
		wi->menu[DIN_A4]   .ob_state |= CHECKED ;
		wi->menu[US_LETTER].ob_state &= ~CHECKED ;
	}
	else
	{
		wi->menu[US_LETTER].ob_state |= CHECKED ;
		wi->menu[DIN_A4   ].ob_state &= ~CHECKED ;
	}
}

static void din_a4(void)
{
	options.format = FORMAT_DIN_A4 ;
	update_format_items() ;
	Awi_sendall(FORMAT_CHANGED, NULL) ;
}

static void us_letter(void)
{
	options.format = FORMAT_US_LETTER ;
	update_format_items() ;
	Awi_sendall(FORMAT_CHANGED, NULL) ;
}


/*** document window update modes ***/

static void update_immediate_items(void)
{
	Awindow *wi = Awi_root() ;

	if (options.immediate_update & IMMEDIATE_SLID)
	     wi->menu[IMMEDIATE_SLIDERS].ob_state |= CHECKED ;
	else wi->menu[IMMEDIATE_SLIDERS].ob_state &= ~CHECKED ;

	if (options.immediate_update & IMMEDIATE_BTN)
	     wi->menu[IMMEDIATE_BUTTONS].ob_state |= CHECKED ;
	else wi->menu[IMMEDIATE_BUTTONS].ob_state &= ~CHECKED ;

	if (options.immediate_update & IMMEDIATE_KEYB)
	     wi->menu[IMMEDIATE_KEYBOARD].ob_state |= CHECKED ;
	else wi->menu[IMMEDIATE_KEYBOARD].ob_state &= ~CHECKED ;
}

static void immediate_buttons(void)
{
	options.immediate_update ^= IMMEDIATE_BTN ;
	update_immediate_items() ;
}

static void immediate_sliders(void)
{
	options.immediate_update ^= IMMEDIATE_SLID ;
	update_immediate_items() ;
}

static void immediate_keyboard(void)
{
	options.immediate_update ^= IMMEDIATE_KEYB ;
	update_immediate_items() ;
}


/*** appearance of controls ***/

static void controls_config(void)
{
	sprintf(buff, "%s%s", ACSblk->apppath, "CONFIG.AM") ;
	Ash_module(buff) ;
}

static void controls_dither(void)
{
	sprintf(buff, "%s%s", ACSblk->apppath, "DITHER.AM") ;
	Ash_module(buff) ;
}


/*** metafile printing ***/

static void update_metafile_items(void)
{
	Awindow *wi = Awi_root() ;
	
	if (options.meta_print_mode == ONE_PER_PAGE)
	{
		wi->menu[ONE_FILE_PER_PAGE ].ob_state |= CHECKED ;
		wi->menu[ALL_PAGES_INTO_ONE].ob_state &= ~CHECKED ;
	}
	else
	{
		wi->menu[ALL_PAGES_INTO_ONE].ob_state |= CHECKED ;
		wi->menu[ONE_FILE_PER_PAGE ].ob_state &= ~CHECKED ;
	}
}

static void one_file_per_page(void)
{
	options.meta_print_mode = ONE_PER_PAGE ;
	update_metafile_items() ;
}

static void all_pages_into_one(void)
{
	options.meta_print_mode = ALL_INTO_ONE ;
	update_metafile_items() ;
}


/*** file selector items ***/

static void update_file_selector_items(void)
{
	Awindow *wi = Awi_root() ;

	if (options.file_selector == UPPER_CASE_MASKS)
	{
		wi->menu[UPPER_CASE].ob_state |= CHECKED ;
		wi->menu[LOWER_CASE].ob_state &= ~CHECKED ;
		set_scheme_file_extension("PAR") ;
		strcpy(file_extension, "MI*") ;
	}
	else
	{
		wi->menu[LOWER_CASE].ob_state |= CHECKED ;
		wi->menu[UPPER_CASE].ob_state &= ~CHECKED ;
		set_scheme_file_extension("par") ;
		strcpy(file_extension, "mi*") ;
	}
}

static void upper_case(void)
{
	options.file_selector = UPPER_CASE_MASKS ;
	update_file_selector_items() ;
}

static void lower_case(void)
{
	options.file_selector = LOWER_CASE_MASKS ;
	update_file_selector_items() ;
}


/*** icon arrangement ***/

static void update_icon_items(void)
{
	Awindow *wi = Awi_root() ;

	if (options.icon_arrangement == ICONS_VER)
	{
		wi->menu[VERTICAL  ].ob_state |= CHECKED ;
		wi->menu[HORIZONTAL].ob_state &= ~CHECKED ;
	}
	else
	{
		wi->menu[HORIZONTAL].ob_state |= CHECKED ;
		wi->menu[VERTICAL  ].ob_state &= ~CHECKED ;
	}
}

static void vertical(void) 
{ 
	options.icon_arrangement = ICONS_VER ; 
	update_icon_items() ;
	Awd_ver(); 
}

static void horizontal(void) 
{ 
	options.icon_arrangement = ICONS_HOR ; 
	update_icon_items() ;
	Awd_hor(); 
}

/*** the whole menu ***/

static void update_menu()
{
	update_format_items       () ;
	update_metafile_items     () ;
	update_wdialog_items      () ;
	update_immediate_items    () ;
	update_file_selector_items() ;
	update_icon_items         () ;
}


/*** toolbar ***/

static void do_hide_toolbar(Awindow *wi)
{
	DOCUMENT *db = wi->user ;
	Axywh xywh = wi->wi_act ;

	db->opts.has_toolbar = FALSE ;

	wi->toolbar = NULL ;
	Awi_moved(wi, &xywh) ;
	Awi_obredraw(wi, 0) ;
}

static void hide_toolbar(void)
{
	do_hide_toolbar( ACSblk->ev_window ) ;
}

static void show_toolbar(void)
{
	Awindow *wi = ACSblk->ev_window ;
	DOCUMENT *db = wi->user ;
	Axywh xywh = wi->wi_act ;

	db->opts.has_toolbar = TRUE ;

	/* Without this the window gets smaller on 
	   ST Emu amd Magic, not on TOS 4 with Winx: */
	xywh.h += db->toolbar->ob_height ; 

	wi->toolbar = db->toolbar ;
	Awi_moved(wi, &xywh) ;
	Awi_obredraw(wi, 0) ;
	Awi_obchange(wi, A_TOOLBAR | 0, -1);
}


static char * zoom_slider_live(void *value, long pos)
{
	pos += MIN_ZOOM ;
	if (messages)  
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return A_int_live(value, (int)pos) ;
}

static char * page_slider_live(void *value, long pos)
{
	if (messages)  
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return A_plus_1_int_live(value, (int)pos) ;
}


static void redisplay(Awindow *wi)
{
	DOCUMENT *db = wi->user ;
	SLLIVE sllive ; 
	
	/* fast exit */
	if (ACSblk->appexit) return ;
	
	/* This is an action for the document window and not more. 
	   Avoid DATA_CHANGED_SLIDER messages because of updated
	   slider positions (AUO_SLLIVE). */
	messages = FALSE ;

	if (wi == current_wi)
		update_print_items() ;	/* depends on: number of layouted pages > 0 */

	if ( db->layout.npgs == 0 )
	{
		sllive.call = A_slider_dead ;
		Auo_slider(db->toolbar + PAGE_SLIDER, AUO_SLCALL, &sllive) ; 
		Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_SLCALL, &sllive) ; 
	}
	else
	{
		db->opts.page = min(db->opts.page, db->layout.npgs) ;
		db->opts.page = max(db->opts.page, 1) ;
		sllive.call = page_slider_live ;
		sllive.obj  = &(db->opts.page) ; 
		A_slider_init(db->toolbar + PAGE_SLIDER, 
			(long)(db->layout.npgs) - 1, 4, 
			(long)(db->opts.page) - 1, &sllive) ;
		db->opts.zoom = min(db->opts.zoom, MAX_ZOOM) ;
		db->opts.zoom = max(db->opts.zoom, MIN_ZOOM) ;
		sllive.call = zoom_slider_live ;
		sllive.obj  = &(db->opts.zoom) ; 
		A_slider_init(db->toolbar + ZOOM_SLIDER, 
			MAX_ZOOM - MIN_ZOOM, 4, 
			(long)db->opts.zoom - MIN_ZOOM, &sllive) ;
	}		
	
    /* refresh text and redisplay */
	Auo_slider(db->toolbar + PAGE_SLIDER, AUO_SLLIVE, NULL) ; 
	Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_SLLIVE, NULL) ; 

	/* redisplay */
	Auo_slider(db->toolbar + PAGE_SLIDER, AUO_FULLUPDATE, NULL) ; 
	Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_FULLUPDATE, NULL) ; 

	messages = TRUE ;
}


static void new_layout(Awindow *wi)
{
	DOCUMENT *db = wi->user ;

	switch ( page_layouter(
		&(db->layout),
		(float)(db->params.left_border ) / 100,
		(float)(db->params.right_border) / 100,
		(float)(db->params.upper_border) / 100,
		(float)(db->params.lower_border) / 100,
		(float)(db->params.system_distance) / 100,
		(float)(db->params.track_distance ) / 100,
		(float)(db->params.note_distance  ) / 100,
		(char) (db->params.horizontal_lines),
		db->filter.number_tracks,
		db->filter.track,
		db->track_table,
		get_max_time(db->filter.number_tracks, db->track_table, db->filter.track),
		time_per_system(db->info.midi_header.ticks_per_beat,db->params.bar_length,db->params.bars_per_line) )
	)
	{
	case LAYOUT_ERR_TOO_MANY_PAGES:   my_alert_str(LAYOUT_ERR, "pages")        ; break ;   
	case LAYOUT_ERR_TOO_MANY_SYSTEMS: my_alert_str(LAYOUT_ERR, "note systems") ; break ;
	case LAYOUT_ERR_TOO_MANY_LINES:   my_alert_str(LAYOUT_ERR, "track lines")  ; break ;
	case LAYOUT_ERR_TRACK_TOO_HIGH:   my_alert_str(TRACK_TOO_HIGH , NULL) ; break ;
	case LAYOUT_ERR_INVALID_BORDERS:  my_alert_str(INVALID_BORDERS, NULL) ; break ;
	}
	redisplay(wi) ;
}

static void set_databases(Awindow *wi)
	/* set databases of all slave windows */
{
	DOCUMENT *m = wi->user ;
	update_file_items(wi) ;		/* wi becomes new current_wi */
	
	info_wi   ->service(info_wi   , SET_DATABASE, &(m->info   ));
	filter_wi ->service(filter_wi , SET_DATABASE, &(m->filter ));
	params_wi ->service(params_wi , SET_DATABASE, &(m->params ));
}

static void topped(Awindow *wi)
{
	Awi_topped(wi) ; /* yes, we want it on top */
	push_on_stack(wi) ;
	
	/* and all slave windows shall display the database
	   of the top window */
	set_databases(wi) ;
}


void closed(Awindow *wi)
{
	DOCUMENT *db = wi->user ;
	Awi_closed(wi) ;
	remove_from_stack(wi) ;

	/* make the next possible window current */
	wi = (Awindow *)get_top_pointer() ;
	if (wi != NULL)
		set_databases(wi) ;
		
	db->opts.is_open = FALSE ;	 
}

static void update_pos(Awindow *wi) 
	/* prepare structure for persisting window geometry */
{
	DOCUMENT *db = wi->user ;
	db->opts.is_open = TRUE ;
	db->opts.left  = (int)((float)wi->wi_act.x * 1000 / ACSblk->desk.w + 0.5) ;
	db->opts.top   = (int)((float)wi->wi_act.y * 1000 / ACSblk->desk.h + 0.5) ;
	db->opts.right = (int)((float)(wi->wi_act.x + wi->wi_act.w - 1) * 1000 / ACSblk->desk.w + 0.5) ;
	db->opts.bottom= (int)((float)(wi->wi_act.y + wi->wi_act.h - 1) * 1000 / ACSblk->desk.h + 0.5) ;
}

static INT16 opened(Awindow *wi)
{
	INT16 rc ;
	
	/* this may automatically correct some data shown in the opened 
	   window (e.g. title), therefore it must be called before Awi_open(): */
	set_databases(wi) ;
	new_layout(wi) ;  

	rc = Awi_open(wi) ;
	if ( rc == OK )
		update_pos(wi) ; 
	return rc ;
}

static void moved(Awindow *wi, Axywh *new)
{
	Awi_moved(wi, new) ;
	update_pos(wi) ;
}

static void sized(Awindow *wi, Axywh *new)
{
	Awi_sized(wi, new) ;
	update_pos(wi) ;
}

static void fulled(Awindow *wi) 
{
	Awi_fulled(wi) ;
	update_pos(wi) ;
}



static INT16 keys(Awindow *wi, int kstate, int key)
{
	INT16 alt = NKF_CTRL | NKF_SHIFT ;
	DOCUMENT *db = wi->user ;
	long ymax1000 = (1000l + wi->wi_slider.h) * db->opts.zoom / MAX_ZOOM ;
	
	messages = FALSE ;
	
	switch (ACSblk->ev_mkreturn & 0xFF)
	{
	case '+': 
		if (ACSblk->ev_mkreturn & alt)
		     Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_NEXTPAGE, NULL); 
		else Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_NEXT, NULL); 
		Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_FULLUPDATE, NULL); 
		break ;
	case '-': 
		if (ACSblk->ev_mkreturn & alt)
		     Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_PREVPAGE, NULL); 
		else Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_PREV, NULL); 
		Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(db->toolbar + ZOOM_SLIDER, AUO_FULLUPDATE, NULL); 
		break ;
	case NK_UP:
		if (wi->wi_slider.y <= 0)
		{
			/* to bottom of previous page */
			if (db->opts.page > 1 )
			{
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_PREV, NULL); 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_SLLIVE, NULL) ; 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_FULLUPDATE, NULL); 
				Awi_vslid(wi, (INT16)max(0, ymax1000 - wi->wi_slider.h)) ;
				break ;
			}
		}
		messages = TRUE ;
		if (ACSblk->ev_mkreturn & alt)
	    	 Awi_arrowed(wi, WA_UPPAGE, 1) ;
		else Awi_vslid(wi, max(0, wi->wi_slider.y - UP_DOWN_SCROLL_PIXELS)) ;
		return 0 ;	/* these need no full redraw */
	case NK_DOWN:
		if (wi->wi_slider.y + wi->wi_slider.h >= ymax1000)
		{
			/* to top of next page */
			if (db->opts.page < db->layout.npgs)
			{
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_NEXT, NULL); 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_SLLIVE, NULL) ; 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_FULLUPDATE, NULL); 
				Awi_vslid(wi, 0) ;
				break ;
			}
		}
		messages = TRUE ;
		if (ACSblk->ev_mkreturn & alt)
		     Awi_arrowed(wi, WA_DNPAGE, 1) ;
		else Awi_vslid(wi, min(1000, wi->wi_slider.y + UP_DOWN_SCROLL_PIXELS));
		return 0 ;	/* these need no full redraw */
	case NK_RIGHT:
		messages = TRUE ;
		if (ACSblk->ev_mkreturn & alt)
		     Awi_arrowed(wi, WA_RTPAGE, 1) ;
		else Awi_hslid(wi, min(1000, wi->wi_slider.x + UP_DOWN_SCROLL_PIXELS));
		return 0 ;	/* these need no full redraw */
	case NK_LEFT:
		messages = TRUE ;
		if (ACSblk->ev_mkreturn & alt)
		     Awi_arrowed(wi, WA_LFPAGE, 1) ;
		else Awi_hslid(wi, max(0, wi->wi_slider.x - UP_DOWN_SCROLL_PIXELS)) ;
		return 0 ;	/* these need no full redraw */
	case NK_CLRHOME:
		if (ACSblk->ev_mkreturn & alt)
		{
			if (db->layout.npgs > 1) 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_END, NULL) ;
			Awi_vslid(wi, (INT16)max(0, ymax1000 - wi->wi_slider.h)) ;
		}
		else 
		{
			if (db->layout.npgs > 1) 
				Auo_slider(db->toolbar + PAGE_SLIDER, AUO_BEGIN, NULL) ; 
			Awi_vslid(wi, 0) ;
		}
		Auo_slider(db->toolbar + PAGE_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(db->toolbar + PAGE_SLIDER, AUO_FULLUPDATE, NULL); 
		break ;
	default:
		/* forward event to ACS for further treatment (e.g. by the desktop) */
		messages = TRUE ;
		return Awi_keys(wi, kstate, key) ;
	}

	messages = TRUE ;
	Awi_obchange(wi, WORK_OBJ, -1) ;	/* always immediate update */
	return 0 /* consumed */ ;
}


static void update_format(Awindow *wi)
{
	/* drawing area for draw_page in pixels (100% zoom) */
	float normal_width, normal_height ;

	switch (options.format)
	{
	case FORMAT_US_LETTER:
		normal_width  = US_LETTER_WIDTH  ; 
		normal_height = US_LETTER_HEIGHT ; 
		break ;
	case FORMAT_DIN_A4:
	default:
		normal_width  = DIN_A4_WIDTH  ;
		normal_height = DIN_A4_HEIGHT ; 
	}
	normal_width  /= screen_out[3] ;
	normal_height /= screen_out[4] ;

	/* the following calculation is performed with floats, because
	   ob_height/ob_width are only 16 bit */
	wi->work->ob_width  = normal_width  * MAX_ZOOM / MEAN_ZOOM ;
	wi->work->ob_height = normal_height * MAX_ZOOM / MEAN_ZOOM ;

	/* this window has grid 64 in ACS editor => round up */
	/* stimmt das noch ??? */
	wi->work->ob_width  |= 0x3F ; wi->work->ob_width ++ ;
	wi->work->ob_height |= 0x3F ; wi->work->ob_height++ ;
	
	(wi->work + WORK_OBJ)->ob_width  = wi->work->ob_width  ;
	(wi->work + WORK_OBJ)->ob_height = wi->work->ob_height ;
	Awi_sized( wi, &(wi->wi_act) ) ;
	if (wi->wi_id >= 0)
		Awi_obchange(wi, WORK_OBJ, -1) ;
}

static void help()
{
	sprintf(buff, "%s%s", ACSblk->apppath, "MIDI_PRT.TXT") ;
	A_help(buff, &HELP_ICON) ;
}


static int service(Awindow *wi, int task, void *in_out)
{
	int immediate_update ;

	switch (task)
	{
	/* ACS generated messages */
	case AS_INFO: 
		set_databases(wi) ; 
		Awi_show(info_wi) ;
		break ;
	case AS_TERM: 
		destroy(wi) ; 
		break ;
	case AS_PRINT:
		{
			DOCUMENT *db = wi->user ;
			A_PrintSel *ps = in_out ;	
			if ( ps->button == PDLG_OK ) 
			{
				validate_from_to(db) ;
				Ash_thermometer(
					THERMO_TEXT+THERMO_CANCEL+THERMO_PERCENT+THERMO_NONMODAL,
					db->filename, GREEN, &(db->print),
					print_init, print_start, print_cont, 
					print_do  , print_stop , print_quit) ;
			}
		}
		break ;
	/* own messages */
	case FORMAT_CHANGED:
		update_format(wi) ;
		break ;
	case DATA_CHANGED_BUTTON:
	case DATA_CHANGED_SLIDER:
	case DATA_CHANGED_KEY:
		if (wi != current_wi) return FALSE ;
		switch (task)
		{
		case DATA_CHANGED_BUTTON:
			immediate_update = options.immediate_update & IMMEDIATE_BTN  ; break ;
		case DATA_CHANGED_SLIDER:
			immediate_update = options.immediate_update & IMMEDIATE_SLID ; break ;
		case DATA_CHANGED_KEY:
			immediate_update = options.immediate_update & IMMEDIATE_KEYB ; break ;
		}
		if (immediate_update)
			return service(wi, DO_REDRAW, wi) ;
		set_timer(wi, DO_REDRAW);
		break ;
	case DO_REDRAW:
		if ( wi != in_out )
			return FALSE ; /* this message not meant for this window */
		stop_timer() ; /* stop delayed redraw timer job */
		new_layout(wi) ;
		Awi_obchange(wi, WORK_OBJ, -1) ;
		break ;
	default: return Awi_service(wi, task, in_out) ; /* treats iconify etc. */
	}
	return TRUE ;
}


static int cdecl draw(PARMBLK *parmblk) 
{
	DOCUMENT *db = (DOCUMENT *)parmblk->pb_parm ;
	INT16 points[4] ;
	INT16 width, height, dummy, pts, foot_pts ;
	INT16 zoom = db->opts.zoom ;
	INT16 handle = (int)xhandle ;
	
	/* fast exit: no superflous drawings */
	if (ACSblk->appexit) return(parmblk->pb_prevstate) ;          

	if (!db->layout.npgs)
		zoom = MAX_ZOOM ;
		
	/* drawing area for draw_page(): */
	width  = (int)((long)parmblk->pb_w * zoom / MAX_ZOOM) ;
	height = (int)((long)parmblk->pb_h * zoom / MAX_ZOOM) ;
	
	/* font height in points is valid for 100% zoom */
	pts = (int)((long)db->params.points * zoom / MEAN_ZOOM) ;
	foot_pts = FOOTLINE_HEIGHT * zoom / MEAN_ZOOM ;

	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	/* draw background */
	vswr_mode   (handle, MD_REPLACE) ;
	vsf_interior(handle, FIS_HOLLOW) ;
	vsf_color   (handle, WHITE) ;
	points[0] = parmblk->pb_x ;
	points[1] = parmblk->pb_y ;
	points[2] = parmblk->pb_x + (int)(width ) ;
	points[3] = parmblk->pb_y + (int)(height) ;
	vsl_color    (handle, LRED) ;
	vsl_type     (handle, SOLID) ;
	if (db->layout.npgs)
	     vsf_perimeter(handle, 1) ;
	else vsf_perimeter(handle, 0) ; /* no red line */
	v_bar        (handle, points) ;
	vsf_color    (handle, LBLACK) ;
	points[0] += (parmblk->pb_w - 1) ;
	points[2]++ ;
	vsf_interior(handle, FIS_SOLID) ;
	vr_recfl    (handle, points) ;
	points[1] += (parmblk->pb_h - 1) ;
	points[2] = parmblk->pb_x ;
	points[3]++ ;
	vr_recfl    (handle, points) ;

	/* use points for clipping */
	points[0] = parmblk->pb_xc ;
	points[1] = parmblk->pb_yc ;
	points[2] = points[0] + parmblk->pb_wc - 1 ;
	points[3] = points[1] + parmblk->pb_hc - 1 ;
	
	/* draw note systems */
	if (db->layout.npgs && messages /* avoid redraw for garbage */) 
	{
		/* line widths in pixels */
		int line_width         = mm_to_pixel(db->params.line_width        , screen_out[4]) * zoom/MAX_ZOOM ;
		int line_width_bars    = mm_to_pixel(db->params.bar_line_width    , screen_out[3]) * zoom/MAX_ZOOM ; 
		int line_width_sub_bars= mm_to_pixel(db->params.sub_bar_line_width, screen_out[3]) * zoom/MAX_ZOOM ;
		int line_width_notes   = mm_to_pixel(db->params.note_line_width   , screen_out[4]) * zoom/MAX_ZOOM ;

		draw_page(xhandle, 
			parmblk->pb_x, parmblk->pb_y, width, height,
			points,				/* clipping */ 
			screen_out[4],		/* pixel height in micrometers */
			db->track_table,	/* the data to draw... */
			db->filter.track,
			&(db->layout),		/* with this layout... */
			db->opts.page - 1,	/* index of page to draw */
			db->params.font, pts,	/* font for all texts */
			db->params.effects,		/* text effects for title only */
			foot_pts,
			db->params.title,
			db->filename,	/* for footline ... */
			db->filesize,
			CAPTION, VERSION, PLATFORM,
			db->params.note_height,	
			MAX_DYNSCALE, db->params.note_dynscale,        
			db->params.mode,			/* Rieder, Beyreuther, Mix */
			db->params.note_type,	/* e.g. with tail, etc. */
			&(db->params.scheme),
			db->params.transpose,
			db->params.bars_per_line,
			db->params.sub_bars,
			line_width, 
			line_width_bars, 
			line_width_sub_bars, 
			line_width_notes
			) ;
	}
	else
	{
		vst_font (handle, 1) ;		/* system font */
		vst_color(handle, BLACK) ;	/* RGB not necessary, on screen there is always a palette */
		vst_point(handle, 10, &dummy, &dummy, &dummy, &dummy) ; /* out params are dummies */
		vst_alignment(handle, 0, 5, &dummy, &dummy) ;
		v_gtext(handle, parmblk->pb_x + 2, parmblk->pb_y + 2, /* + 2 because of red border line */
			"Nothing to draw. (Did you switch all tracks off ?)") ;
	}
	/* reset clipping */
	vs_clip(handle, 0, NULL) ;

	/* return object state unchanged */
	return(parmblk->pb_prevstate) ;          
}


static void destroy(Awindow *wi)
{
	DOCUMENT *db ;

	/* incarnation counter: here a work-around. ACS sends messages
	     to windows already deleted ?! */
	if (wi && incarnation_counter) 
	{
		db = wi->user ;
		if (db) 
		{
			if (db->has_profile)
				do_write_profile(wi) ;
				
			/* inform slave windows that data is no longer valid */
			if (wi == current_wi)
			{
				Awi_sendall(INVALIDATE_DATABASE, &(db->info)) ;
				Awi_sendall(INVALIDATE_DATABASE, &(db->filter)) ;
				Awi_sendall(INVALIDATE_DATABASE, &(db->params)) ;
			}
			/* save file path in common config file */
			/* if started with command line filenames: save NOT! */
			if ( ACSblk->argc <= 1 && ACSblk->appexit )
			{
				if ( !config_file )
					config_file = fopen(config_filepath, "w") ;
				if ( config_file )
					fprintf(config_file, "%s\n", db->pathname) ;
			}
			/* own object instance */
			if (db->RAM_file) 
			{
				unload_file(db->RAM_file) ;
				db->RAM_file = NULL ;
			}
			free_track_table(db->track_table) ;
			set_number_tracks(&(db->filter), 0) ;

			/* restore toolbar, ACS shall destroy it */ 
			wi->toolbar = db->toolbar ;
			
			free(db) ; db = NULL ;
		}
		/* own window */
		Awi_delete(wi) ;
		incarnation_counter-- ;
		wi = get_top_pointer() ;
		update_file_items(wi) ;
	}
}


static Awindow *create(void *MIDIfile) ;

static void open_file(void *unused, void *elem)
{
	if (elem)
		create(elem) ;
}

static Awindow *create(void *MIDIfile)
	/* Constructor of the DOCUMENT window */
{
	Awindow *wi ;
	DOCUMENT *db ;
	char *buffer ;
	char *midifile = MIDIfile ;
	
	if ( !midifile )
	{
		/* have the program user selected a MIDI file */
		/* AS_FILESELECT only on Magic, and return list only otherwise ! */ 
		/* For simplicity we do not use file selector in window and 
		   to not set Awi_root() as last parameter => always a list is returned */
		ULinList *list 
		  = Af_fileselect("Open MIDI file", path, file_extension, 0/*sort*/,TRUE /*multi*/, NULL) ;
		if( list )
		{
			(list->doFor)(list, NULL, NO_FOR, (A_ListWork)open_file);
			Alu_delete(list);
		}
		return NULL ;
	}
	
	/*sprintf(buff, "[1][create(\"%s\")][OK]", midifile) ;
	form_alert( 1, buff );*/

	/* call param is a filename */
	/* allocate and init main structure */
	db = calloc(1, sizeof *db) ;
	if (!db) return NULL ;
	
	if (midifile[0] == '\'')
	{
		/* file name is between single quotes, strip quotes */
		midifile++ ;
		if ( buffer = strchr(midifile, '\'') )
			*buffer = 0 ;
	}
	if (midifile[1] == ':')
		/* full path with drive */
		strcpy(db->pathname, midifile) ;
	else
	{
		/* no drive => take current drive */
		db->pathname[0] = 'A' + (char)Dgetdrv() ;
		db->pathname[1] = ':' ;
		if (midifile[0] == '\\')
			/* full path, but without drive */
			strcpy(db->pathname + 2, midifile) ;
		else
		{
			/* partial path => prefix with current dir */
			Dgetpath(db->pathname + 2, 0) ; /* 0 = current drive */
			strcat(db->pathname, "\\") ;
			strcat(db->pathname, midifile) ;
		}
	}
	buffer = strrchr(db->pathname, '\\') ;
	if (!buffer)
	{
		/* no "\" ==> no valid path */
		my_alert_str(CALL_INVALID, db->pathname) ;
		free(db) ; return NULL ;
	}
	{		
		/* accept also .MI$ files for opening (replace extension with .MID) */
		char *s ;
		if (s = strstr(db->pathname, ".MI$")) 
			strcpy(s, ".MID") ;
		else if (s = strstr(db->pathname, ".MID$"))
			strcpy(s, ".MIDI") ;
		else if (s = strstr(db->pathname, ".mi$"))
			strcpy(s, ".mid") ;
		else if (s = strstr(db->pathname, ".mid$"))
			strcpy(s, ".midi") ;
	}
	strcpy(db->filename, buffer + 1) ;
	
	profile_path(db->profile, db->pathname) ;
	
	/* load the selected file into RAM */
	db->RAM_file = load_file(db->pathname, &db->filesize) ;
	if ( !db->RAM_file )
	{ 
		free(db) ; return NULL ; 
	}
	
	/* enter filename into icon text and pathname into window info line */
	MAIN_WINDOW.iconblk->monoblk.ib_ptext = db->filename ;
	MAIN_WINDOW.name = db->pathname ;

	/* enter filename into DBs of slave windows */
	db->info.filename  = db->filter.filename  = 
	db->params.filename = db->print.filename = db->filename ;
	db->print.pathname = db->pathname ;
	
	/* create the DOCUMENT window */
	wi = Awi_create(&MAIN_WINDOW) ;
	if (!wi) 
	{ 
		unload_file(db->RAM_file) ; 
		db->RAM_file = NULL ;
		free(db) ; 
		return NULL ; 
	}
	incarnation_counter ++ ;
	wi->user = db ;

	/* for restoring hidden toolbar */
	db->toolbar = wi->toolbar ; 

	/* fit window format to paper format */
	update_format(wi) ;
	
	db->info.midi_header = read_midi_file_header(db->RAM_file) ;
	if (db->info.midi_header.midi_file_type < 0 || db->info.midi_header.number_tracks <= 0 )
	{
		my_alert_str(INVALID_FILE_FORMAT, db->pathname) ; 
		destroy(wi) ; 
		return NULL ; 
	}
	if (db->info.midi_header.smpte) 
		my_alert_str(NO_SMPTE, NULL) ; /* but continue */
	db->print.filesize = db->info.filesize = db->filesize ;

	switch ( make_track_table(
		db->RAM_file,
	    db->filesize, 
	    db->info.midi_header.number_tracks,
	    &(db->track_table),
	    &(db->info.transformed_size)) )
	{
		case TRANSFORM_INVALID_FILE_FORMAT:
			my_alert_str(INVALID_FILE_FORMAT, db->pathname) ;
		case TRANSFORM_OUT_OF_MEMORY:
			/* out of memory reported by ACS already */
			destroy(wi) ; 
			return NULL ; 
	}
	
	/* init pointers of print DB */
	db->print.options  = &options  ;
	db->print.layout = &(db->layout) ;
	db->print.params = &(db->params) ;
	db->print.filter = &(db->filter) ;
	db->print.track_table = db->track_table ;
	
	if (!set_number_tracks(&(db->filter), db->info.midi_header.number_tracks ))
	{
		destroy(wi) ;
		return NULL ;
	}
	/* in any case file is no longer needed in RAM */
	unload_file(db->RAM_file) ; 
	db->RAM_file = NULL ;

	/* userdef drawing routines called by AES need access to DOCUMENT */ 
	wi->work[WORK_OBJ].ob_spec.userblk->ub_parm = (long)db ;

    do_load_profile(wi) ;	
	if (!db->opts.has_toolbar)
		do_hide_toolbar(wi) ;
	
	wi->wi_act.x = (int)((float)(db->opts.left  ) / 1000 * ACSblk->desk.w + 0.5) ;
	wi->wi_act.y = (int)((float)(db->opts.top   ) / 1000 * ACSblk->desk.h + 0.5) ;
	wi->wi_act.w = (int)((float)(db->opts.right ) / 1000 * ACSblk->desk.w + 0.5) 
		- wi->wi_act.x + 1 ;
	wi->wi_act.h = (int)((float)(db->opts.bottom) / 1000 * ACSblk->desk.h + 0.5) 
		- wi->wi_act.y + 1 ;
		
	/* correct possible inplausible values from file */
	wi->wi_act.x = min(ACSblk->desk.w - 32, max(-32, wi->wi_act.x)) ;
	wi->wi_act.y = min(ACSblk->desk.h - 32, max(  0, wi->wi_act.y)) ;
	wi->wi_act.h = max(200, wi->wi_act.h) ;
	wi->wi_act.w = max(200, wi->wi_act.w) ;

	if (db->opts.is_open)
		wi->open(wi) ;

	/* return success message */
	return wi ;
}



/********************************************************************
*
*         ACS routines
*
********************************************************************/

/*static INT16 open_dragged_files(INT16 check_only) 
{
	Awindow *ori = ACSblk->Aselect.window ;
	INT16 rc = FALSE ;
	INT16 obnr ;
	OBJECT  *obj  ;
	AOBJECT *aobj ;

	if (ACSblk->Aselect.actlen < 1)
		return FALSE ;
		
	Adr_start() ;
	for (obnr = Adr_next() ; obnr != -1 ; obnr = Adr_next())
	{
		obj = (obnr & A_TOOLBAR ? &ori->toolbar[obnr & A_MASK] : &ori->work[obnr]) ;
		aobj = (!(obj[0].ob_flags & LASTOB) && obj[1].ob_flags & AEO ? (AOBJECT *)&obj[1] : NULL) ;
		
		if (aobj && aobj->type == AT_FILE)
		{
			char *file = aobj->userp1 ;
			char *dot = strrchr(file, '.') ;
			if (dot && !strnicmp(dot, ".mi", 2))
			{
				if (check_only)
					return TRUE ;
					
				if ( create(file) )
				{
					rc = TRUE ;
					Adr_del(ori, obnr) ;
				}
			}
		}
	}
	return rc ;
}*/


static INT16 (*orig_root_service)(Awindow *window, INT16 task, void *in_out) ;

static INT16 my_root_service(Awindow *window, INT16 task, void *in_out)
{
	if (task == 4)
		/* this event disturbs when debugging */
		return orig_root_service(window, task, in_out) ;

	/* evtl. noch flag von wi->work mit ACCEPT verodern ? */
	
/***	switch (task)
	{
/*	case AS_CHECKDRAG:
		*((INT16 *)in_out) = open_dragged_files(TRUE /* check only */) ;
		return TRUE ;
		
	case AS_DRAGGED:
		return open_dragged_files(FALSE) ;*/
	
/*	case AS_FILESELECT:
		create(in_out) ;
		return TRUE ;*/

/*	case AS_GEM_MESS: not needed here, already performed by AS_NEWCALL mechanism
		if ( *(INT16 *)in_out == VA_START )
		{
			INT16 *msg = in_out ;
			char *name = *(char **)&msg[3] ;
			form_alert( 1, "[0][VA_START received.][Yes]" );
			if ( Af_length(name) > 0 )
				create(name) ;
		}
		break ;*/
	}***/
	return orig_root_service(window, task, in_out) ;
}

static void my_aboutme(void) { A_dialog(&ABOUT_ME) ; }
	/* replaces the ACS default info with my own info message. */

static void fwrite_window_pos(FILE *file, Awindow *wi, const char *name)
	/* write left and top of wi in relative units 0..1000
	   to file, 1000 corresponds to desktop width/height */
{
	float left   = (float)wi->wi_act.x * 1000 / ACSblk->desk.w + 0.5 ;
	float top    = (float)wi->wi_act.y * 1000 / ACSblk->desk.h + 0.5 ;
	fprintf(file, "left%s = %i\n", name, (int)left) ;
	fprintf(file, "top%s  = %i\n", name, (int)top ) ;
	fprintf(file, "open%s = %s\n", name, (wi->wi_id >= 0) ? "yes" : "no") ;
}


static void my_close(void)
	/* is called when the program user has selected the "quit"
       entry in the menu of the desktop. */
{
/*	Awindow *module = Awi_root()->user ;*/
	
	/*if (my_alert_str(QUIT_ALL, NULL) == 1) */
	{
		/* only for debugging: */
		/*print_operations() ;*/
		
		/* workaround toolbar height bug in ACS < 3.0 */
		/* close module window, otherwise automatically opened before ACSinit by ACS,
		   where we repair the toolbar height, i.e. would be shown with bug: */
/*		if ( ACSblk->multitask && ACSblk->application )
			module->closed(module) ;
*/		   
		if ( !config_file )
			config_file = fopen(config_filepath, "w") ;
		if ( config_file )
		{
			/* save options */
			fprintf(config_file, "Format          = %s\n", (options.format          == FORMAT_DIN_A4)?"DIN A4":"US letter") ;
			fprintf(config_file, "MetaPrintMode   = %s\n", (options.meta_print_mode == ONE_PER_PAGE)?"one per page":"all into one") ;
			fprintf(config_file, "FileSelectMasks = %s\n", (options.file_selector   == UPPER_CASE_MASKS)?"upper case":"lower case") ;
			fprintf(config_file, "FontPrintDialog = %s\n", (options.use_WDIALOG)?"OS":"own") ;
			fprintf(config_file, "Icons           = %s\n", (options.icon_arrangement== ICONS_VER)?"vertical":"horizontal") ;
			fprintf(config_file, "ImmediateUpdate = ") ;
			if (options.immediate_update & IMMEDIATE_SLID) fprintf(config_file, "sliders ") ;
			if (options.immediate_update & IMMEDIATE_BTN ) fprintf(config_file, "buttons ") ;
			if (options.immediate_update & IMMEDIATE_KEYB) fprintf(config_file, "keyboard ") ;
			fprintf(config_file, "\n") ;
			fwrite_window_pos(config_file, info_wi  , "Info") ;
			fwrite_window_pos(config_file, params_wi, "Params") ;
			fwrite_window_pos(config_file, filter_wi, "Filter") ;
		}
		/* ACS termination procedure */
		Aev_quit() ;
	}
}


static void my_term(void)
	/* subtitutes the ACSterm procedure and is called during ACS shutdown. */
{
	if ( config_file )
		fclose(config_file) ;
}


static void parse_update(char *s, int *update)
{
	*update = 0 ;
	if (strpbrk(s, "uU")) *update |= IMMEDIATE_BTN  ;
	if (strpbrk(s, "yY")) *update |= IMMEDIATE_KEYB ;
	if (strpbrk(s, "lL")) *update |= IMMEDIATE_SLID ;
}

static void open_window_on_pos(Awindow *wi, Axywh *xywh) 
	/* opens window top = x, left = y */
	/* relative units 0..1000 are transformed back to pixels */
	/* if w is 0, the window is not opened */
{
	int deskw = ACSblk->desk.w ;
	int deskh = ACSblk->desk.h ;
	wi->wi_act.x = (int)((float)(xywh->x) / 1000 * deskw + 0.5) ;
	wi->wi_act.y = (int)((float)(xywh->y) / 1000 * deskh + 0.5) ;
	wi->wi_act.x = min(deskw - 32, max(-32, wi->wi_act.x)) ;
	wi->wi_act.y = min(deskh - 32, max(  0, wi->wi_act.y)) ;
	if (xywh->w)
		(wi->open)(wi) ;
}


#define VAR_LEN  20  /* length of a variable name incl. " = " */
#define VAL_LEN  230 /* lenght of a variable value (longest case is a path) */

int my_init(void)
	/* is called once in the start-up of ACS. See also ACS manual. */
{
	Awindow *wi /*, *module*/ ;
	unsigned i ;
	char buffer[PATHNAME_LENGTH] ; 

	/* memory watcher */	
	/*ACSblk->DEBUG_MEM = debug_mem ;*/

	/* double click to "new" will result in a jump to "create()" */
	wi = Awi_root() ;
	if (!wi) return FAIL ;
	wi->service(wi, AS_NEWCALL, &MAIN_WINDOW.create) ;
/*	wi->service(wi, AS_NEWCALL, create) ; crashes ??? */

	/* replace root window service procedure */
	orig_root_service = wi->service ;
	wi->service = my_root_service ;

	/* inform slave modules that they can use this handle */
	xhandle = ACSblk->vdi_handle ;
	if (direct_color)
		xhandle = mark_handle_rgb(xhandle) ;
	params_set_handle(xhandle) ;

	/* create slave windows */ 
	info_wi    = INFO_WINDOW.create   (&INFO_WINDOW   ) ; /* F1 */
	params_wi  = PARAMS_WINDOW.create (&PARAMS_WINDOW ) ; /* F2 */
	filter_wi  = FILTER_WINDOW.create (&FILTER_WINDOW ) ; /* F3 */
	if ( !info_wi  || !filter_wi || !params_wi ) 
		return FAIL ;

	/* query parameters from screen workstation used by ACS */
	vq_extnd(ACSblk->vdi_handle, 0 /* same info as from v_opnwk */, screen_out) ;

	/* init my RGB color map */
	init_rgb_table(ACSblk->vdi_handle) ;

	/* init file selector path */
	strcpy (path, ACSblk->apppath) ; 

	/* default profile path (might be in user's $HOME) */
	sprintf(default_profile, "%s%s", ACSblk->cfg_path, DEFAULT_PROFILE_NAME) ;
		
	/* init timer management */
	init_time() ;
	
	/* construct config file path (might be in user's $HOME) */
	strcpy(config_filepath, ACSblk->cfg_path) ;
	*( strrchr(config_filepath, '\\') + 1 ) = 0 ;
	strcat(config_filepath, "MIDI_PRT.CFG") ;

	/* parse config file */
	config_file = fopen(config_filepath, "r") ;
	if (config_file)
	{
		char var [VAR_LEN ] ;
		char val [PATHNAME_LENGTH] ;
		Axywh info_pos, filter_pos, params_pos ;
		
		while( fgets(buffer, (int)(sizeof(buffer)-1), config_file) ) 
		{
			char *c ;
			/* Not terminated with \n, because sscanf() would read over it 
			   into foreign memory because it is a white space char. */
			if (c = strchr(buffer, '\n'))
				*c = '#' ;
			if ( sscanf(buffer, "%"_STRING_(VAR_LEN)"s = %"_STRING_(VAL_LEN)"[^\#]", var, val) == 2 )
			{
				if      (strstr(var, "Format"         )) options.format          = (strchr (val, '4' ) == NULL) ;
				else if (strstr(var, "MetaPrintMode"  )) options.meta_print_mode = (strpbrk(val, "pP") == NULL) ;
				else if (strstr(var, "FileSelectMasks")) options.file_selector   = (strpbrk(val, "lL") == NULL) ;
				else if (strstr(var, "FontPrintDialog")) options.use_WDIALOG     = (strpbrk(val, "nN") == NULL) ;
				else if (strstr(var, "Icons"          )) options.icon_arrangement= (strpbrk(val, "vV") == NULL) ;
				else if (strstr(var, "ImmediateUpdate")) parse_update(val, &(options.immediate_update)) ;
				else if (strstr(var, "leftInfo"  )) info_pos.x   = atoi(val) ;
				else if (strstr(var, "topInfo"   )) info_pos.y   = atoi(val) ;
				else if (strstr(var, "openInfo"  )) info_pos.w   = (strpbrk(val, "yY") != NULL) ;
				else if (strstr(var, "leftFilter")) filter_pos.x = atoi(val) ;
				else if (strstr(var, "topFilter" )) filter_pos.y = atoi(val) ;
				else if (strstr(var, "openFilter")) filter_pos.w = (strpbrk(val, "yY") != NULL) ;
				else if (strstr(var, "leftParams")) params_pos.x = atoi(val) ;
				else if (strstr(var, "topParams" )) params_pos.y = atoi(val) ;
				else if (strstr(var, "openParams")) params_pos.w = (strpbrk(val, "yY") != NULL) ;
			}
			else if (ACSblk->argc <= 1)
			{
				/* interpret as filename ***/
				if (c = strchr(buffer, '#'))
					*c = 0 ; /* normal string */
				create(buffer) ; 
			}
		}
		fclose(config_file) ;
		config_file = NULL ;
		
		if (options.icon_arrangement == ICONS_HOR)
			/* not the ACS default, tell it to ACS: */
			Awd_hor() ;

		open_window_on_pos(info_wi  , &info_pos  ) ;
		open_window_on_pos(filter_wi, &filter_pos) ;
		open_window_on_pos(params_wi, &params_pos) ;
	}
	
	i = wi->menu[QUIT].ob_height ;	/* height of 1 menu item in pixels */
	if ( ACSblk->multitask && ACSblk->application )
	{
		/* Loading modules offered by module window already. */
		/* Awd_hor() and Awd_ver() may crash ACS with PUR_DESK. */
		wi->menu[ICON_ARRANGEMENT_SEPARATOR].ob_flags |= HIDETREE ;
		wi->menu[VERTICAL]                  .ob_flags |= HIDETREE ;
		wi->menu[HORIZONTAL]                .ob_flags |= HIDETREE ;
		wi->menu[LOAD_MODULE_SEPARATOR]     .ob_flags |= HIDETREE ;
		wi->menu[LOAD_MODULE]               .ob_flags |= HIDETREE ;
		wi->menu[OPTIONS_MENU].ob_height -= i * 5 ;
		
		/* "Information" already offered by module window. */
		wi->menu[WINDOW_INFO].ob_flags |= HIDETREE ;
		wi->menu[WINDOW_MENU].ob_height -= i ;
	}
	else 
	{
		/* module window only available with PUR_DESK */
		wi->menu[WINDOW_LIST].ob_flags |= HIDETREE ;
		wi->menu[WINDOW_LIST].ob_y      += i ;
		wi->menu[WINDOW_INFO].ob_y      -= i ;
		wi->menu[WINDOW_MENU].ob_height -= i ;

		/* no quit in accessories */
		if ( !ACSblk->application )
		{
			wi->menu[QUIT_SEPARATOR].ob_flags |= HIDETREE ;
			wi->menu[QUIT]          .ob_flags |= HIDETREE ;
			wi->menu[FILE_MENU].ob_height -= wi->menu[QUIT].ob_height * 2 ;
		}
	}

	/* make desktop menu consistent with data */
	update_menu() ;	
	
	/* open files specified as program arguments */
	for (i = 1 ; i < ACSblk->argc ; i ++) 
		create(ACSblk->argv[i]) ;

	/* work around bug in ACS or ST Emulator 1.6 + MINT + Thing ? */
	/* Amo_unbusy() ; No. Busy mouse only when starting out of Pure C */
	
	return OK ;
}


int my_init0(void)
	/* my_init0 is called once very early in the start-up of ACS. */
	/*   See also ACS manual. */
{
	INT16 s = (INT16)sizeof(DOCUMENT) ;
	if (s & 0x8000)
	{
		/* structure too big for PURE C */
		my_alert_str( ACSblk->description->mess[AD_GENERAL_STR], "DOCUMENT struct too big!" );
		return FAIL ;
	}

	/* init dither mode with this default: */
	ACSblk->dither = 0x80/* white text backgr.*/ 
		| (IP_4PATT << 4) | BLACK ;
		
	if ( ACSblk->multitask && ACSblk->application )
	{
		/* we use the new pure desktop */
		ACSdescr.root = &PUR_DESK ;

		/* replace desktop menu */
		PUR_DESK.menu = &DESK_MENU ;
		
		/* replace window title */
		PUR_DESK.name = CAPTION_WITH_BLANKS ;
		
		/* customize module window */
		PUR_MODULE.name = "Windows" ;
/*		PUR_MODULE.toolbar = NULL ; crashes on Magic with ACS 3 beta */
	}
	else
	{
	    ACSdescr.root = &DESKTOP ;
		DESKTOP.menu  = &DESK_MENU ;
		DESKTOP.name = CAPTION_WITH_BLANKS ;

		/* replace desktop background object */
		if ( ACSblk->application )
		{
			_01_BACKGND_2.ob_width  = _01_BACKGND_16.ob_width  = ACSblk->desk.w ;
			_01_BACKGND_2.ob_height = _01_BACKGND_16.ob_height = ACSblk->desk.h ;
		}
		else
		{
			_01_BACKGND_2.ob_width  = _01_BACKGND_16.ob_width  = ACSblk->desk.w/2 ;
			_01_BACKGND_2.ob_height = _01_BACKGND_16.ob_height = ACSblk->desk.h/2 ;
		}
		if ( ACSblk->ncolors < 16 ) 
			DESKTOP.service(NULL, AS_BACKOBJECT, &_01_BACKGND_2) ;
		else if ( ACSblk->ncolors <= 256 ) /* avoid terrible red background object on Falcon in true color mode */
			DESKTOP.service(NULL, AS_BACKOBJECT, &_01_BACKGND_16) ;

		/* replace "trash" and "new" icons */
		DESKTOP.service(NULL, AS_ICONNEW,   &NEW_ICON  ) ;
		DESKTOP.service(NULL, AS_ICONTRASH, &TRASH_ICON) ;

	}
	/* always OK */
	return OK ;
}
