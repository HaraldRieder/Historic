/**************************************************************
*
*                SCHMEDIT.C
*
**************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#if defined (__PUREC__)
#	include <acs.h>
#	include <acsplus.h>
#	include "messages.h"
#   include "scheme.h"
#	include "schmedit.h"
#	include "schmedit.ah"
#	include <diskfile.h>
#	include <stylesel.h>
#	include <colorsel.h>
#endif
#include <acs_plus.h>
#include <graphic.h>
#include <graphicf.h>

#include "schmedit.hpp"

#ifndef __PUREC__
#	define WHITE RGB_WHITE
#	define BLACK RGB_BLACK
#endif

/*static char scheme_file_extension[] = "PAR,par\0" ;*/
static char scheme_file_extension[8] = "\0\0\0\0\0\0\0\0" ;

void set_schmedit_file_extension(const char *ext)
{
	strcpy(scheme_file_extension, ext) ;
}

#if defined (__PUREC__)

/* [extended] VDI workstation handles used for all output */
static INT32 xhandle ;	
static int handle ;

void schmedit_set_handle(INT32 _xhandle) 
{ 
	xhandle = _xhandle ; 
	handle = (int)_xhandle ;
}

static char textbuff[PATHNAME_LENGTH] = "" ;

typedef struct
{
	char path[256] ;
	char *file ; 	/* points to file part inside path */
	COLOR_SCHEME scheme ;
	
	int current_dodecime ;
} 
SCHMEDIT_DB ;

static int dodecimes[] =
	{ DODECIME0, DODECIME1, DODECIME2, DODECIME3, 
	  DODECIME4, DODECIME5, DODECIME6, DODECIME7,   
	  DODECIME8, DODECIME9, DODECIME10 } ;

static int heads[] =
	{ HEAD0, HEAD1, HEAD2, HEAD3, 
	  HEAD4, HEAD5, HEAD6, HEAD7,   
	  HEAD8, HEAD9, HEAD10, HEAD11 } ;

static int bodies[] =
	{ BODY0, BODY1, BODY2, BODY3, 
	  BODY4, BODY5, BODY6, BODY7,   
	  BODY8, BODY9, BODY10, BODY11 } ;

static int tails[] =
	{ TAIL0, TAIL1, TAIL2, TAIL3, 
	  TAIL4, TAIL5, TAIL6, TAIL7,   
	  TAIL8, TAIL9, TAIL10, TAIL11 } ;


static INT16 keys(Awindow *wi, INT16 kstate, INT16 key)
{
/*	switch (ACSblk->ev_mkreturn & 0xFF)
	{
	case NK_RIGHT:
		if (ACSblk->ev_mkreturn & NKF_ALT)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_NEXTPAGE, NULL); 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_NEXT, NULL); 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	case NK_LEFT:
		if (ACSblk->ev_mkreturn & NKF_ALT)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_PREVPAGE, NULL); 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_PREV, NULL); 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	case NK_CLRHOME:
		if (ACSblk->ev_mkreturn & NKF_ALT)
		     Auo_slider(wi->work + TRACK_SLIDER, AUO_BEGIN, NULL) ; 
		else Auo_slider(wi->work + TRACK_SLIDER, AUO_END, NULL) ;
		Auo_slider(wi->work + TRACK_SLIDER, AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + TRACK_SLIDER, AUO_FULLUPDATE, NULL); 
		return 0 /* consumed */ ;
	}
*/	/* forward event to ACS for further treatment (e.g. by the desktop) */
	return Awi_keys(wi, kstate, key) ;
}


static void redisplay_heads(Awindow *wi) 
{
	int i ;
	for (i = 0 ; i < 12 ; i++)
		Awi_obchange(wi, heads[i], -1) ;
}


static void redisplay_bodies(Awindow *wi) 
{
	int i ;
	for (i = 0 ; i < 12 ; i++)
		Awi_obchange(wi, bodies[i], -1) ;
}


static void redisplay_tails(Awindow *wi) 
{
	int i ;
	for (i = 0 ; i < 12 ; i++)
		Awi_obchange(wi, tails[i], -1) ;
}


static void redisplay_dodecimes(Awindow *wi) 
{
	int i ;
	for (i = 0 ; i < 11 ; i++)
		Awi_obchange(wi, dodecimes[i], -1) ;
}


static void redisplay(Awindow *wi)
{
	SCHMEDIT_DB *db = wi->user ;

	if (db)
	{
		/* update window info line */
		if ( SCHMEDIT_WORK.ob_width < strlen(db->path) )
			Awi_setinfo(wi, db->file) ;
		else
			Awi_setinfo(wi, db->path) ;
		{
			/* update icon text */
			char *s = wi->iconblk->monoblk.ib_ptext ;
			if (s) Ast_delete(s) ;
			wi->iconblk->monoblk.ib_ptext = Ast_create(db->file) ;
		}
	}
	redisplay_dodecimes(wi) ;
	Awi_obchange(wi, BARS   , -1) ;
	Awi_obchange(wi, _SCHEME, -1) ;

	if (db && db->path[0])
	{
		wi->menu[SCHEME_RELOAD].ob_state &= ~DISABLED ;
		wi->menu[SCHEME_SAVE  ].ob_state &= ~DISABLED ;
	}
	else
	{
		wi->menu[SCHEME_RELOAD].ob_state |= DISABLED ;
		wi->menu[SCHEME_SAVE  ].ob_state |= DISABLED ;
	}
}


static void update_path(SCHMEDIT_DB *db, const char *path)
{
	char *c = strrchr(path, '\\') ;
	strcpy(db->path, path) ;
	if (c)
		db->file = c + 1 ;
	else db->file = db->path ;
}


int do_save_scheme(SCHMEDIT_DB *db, const char *path) 
{
	if (save_scheme(&(db->scheme), path) < 0)
	{
		my_alert_str(ACSblk->description->mess[AD_WRITE_STR], db->path) ;
		return -1 ;
	}
	update_path(db, path) ;
	Awi_sendall(FILE_WAS_SAVED, db->path) ;
	return 0 ;
}


static void do_load_scheme(SCHMEDIT_DB *db, const char *path) 
{
  	if ( load_scheme(&(db->scheme), path) == 0 )
	   	update_path(db, path) ;
   	else 
   	{
   		default_scheme(&(db->scheme)) ;
	   	update_path(db, "") ;
   	}
}


static void unload_scheme(SCHMEDIT_DB *db)
{
	COLOR_SCHEME scheme_on_disk ;
	default_scheme(&scheme_on_disk) ;

	if ( db->path[0] )
		load_scheme(&scheme_on_disk, db->path) ;
	if ( memcmp(&scheme_on_disk, &(db->scheme), sizeof(scheme_on_disk)) )
	{
		/* different from disk */
		if (db->path[0])
		{
			/* scheme from disk was edited */
			if ( 1 == my_alert_str(SAVE_CHANGED_SCHEME, db->path) )
				do_save_scheme(db, db->path) ;
		}
		else
		{
			/* default scheme was edited */
			if (Af_select("Save scheme as:", db->path, scheme_file_extension))
				do_save_scheme(db, db->path) ;
		}
	}
}


static void destroy(Awindow *wi)
{
	unload_scheme(wi->user) ;
	Awi_delete(wi) ; 
}


static void update_data(Awindow *wi, STYLE_MESSAGE *sm, COLOR_MESSAGE *cm)
{
	SCHMEDIT_DB *db = wi->user ;
	int i, obnr, found, fullredraw = FALSE ;
	INT16 color ;
	
	if (cm)
	{
		color = (cm->index != -1) ? cm->index : cm->rgb ; 
	}
	Adr_start() ;
	while((obnr = Adr_next()) >= 0)
	{
		found = FALSE ;

		if (!found && BACKGROUND == obnr)
		{
			if (sm) db->scheme.back_style = sm->style ;
			if (cm)	db->scheme.back_color = color ;
			found = TRUE ;
			fullredraw = TRUE ;
		}
		if (!found && BARS == obnr)
		{
			if (cm) db->scheme.text_color = color ;
			found = TRUE ;
			fullredraw = TRUE ;
		}
		for (i = 0 ; !found && i < 12 ; i++)
		{
			if (heads[i] == obnr)
			{
				if (sm) db->scheme.note_style_ends[i] = sm->style ;
				if (cm)	db->scheme.note_color_ends[i] = color ;
				if (!fullredraw)
					Awi_obredraw(wi, tails[i]) ;
				found = TRUE ;
			}
			else if (bodies[i] == obnr)
			{
				if (sm) db->scheme.note_style[i] = sm->style ;
				if (cm)	db->scheme.note_color[i] = color ;
				found = TRUE ;
			}
			else if (i < 11 && dodecimes[i] == obnr)
			{
				if (sm) db->scheme.dodecime_style[i] = sm->style ;
				if (cm)	db->scheme.dodecime_color[i] = color ;
				found = TRUE ;
				if (i == db->current_dodecime)
					if (!fullredraw)
						Awi_obchange(wi, _SCHEME, -1) ;
			}
		}
		if (found && !fullredraw)
			Awi_obredraw(wi, obnr) ;
	}
	if (fullredraw)
	{
		Awi_obchange(wi, BARS   , -1) ;
		Awi_obchange(wi, _SCHEME, -1) ;
	}
}


static INT16 load_dragged_scheme(INT16 check_only) 
{
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	Awindow *ori = ACSblk->Aselect.window ;
	INT16 obnr ;
	OBJECT  *obj  ;
	AOBJECT *aobj ;

	if (!db) return FALSE ;

	if (ACSblk->Aselect.actlen < 1)
		return FALSE ;
		
	Adr_start() ;
	for (obnr = Adr_next() ; obnr != -1 ; obnr = Adr_next())
	{
		obj = (obnr & A_TOOLBAR ? &ori->toolbar[obnr & A_MASK] : &ori->work[obnr]) ;
		aobj = (!(obj[0].ob_flags & LASTOB) && obj[1].ob_flags & AEO ? (AOBJECT *)&obj[1] : NULL) ;
		
		if (aobj && aobj->type == AT_FILE)
		{
			char *file = aobj->userp1 ;
			char *dot = strrchr(file, '.') ;
			if (dot && 
				!strnicmp(dot + 1, scheme_file_extension, strlen(scheme_file_extension)))
			{
				if (!check_only)
				{
					if (db->file && *db->file)
						unload_scheme(db) ;
					do_load_scheme(db, file) ;
					redisplay(wi) ;
					Adr_del(ori, obnr) ;
				}
				return TRUE ;
			}
		}
	}
	return FALSE ;
}


static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	switch (task)
	{	
		case AS_TERM:
			destroy(wi) ; 
			break ; 
		case AS_CHECKDRAG:
			*((INT16 *)in_out) = load_dragged_scheme(TRUE /* check only */) ;
			break ;
		case AS_INFO: 
/*			A_dialog(&FILTER_INFO) ;
			Awi_dialog(&INFO_INFO_WINDOW) ; */
			break ;
		case SET_DATABASE:
			if (wi->user != in_out)
				/* redisplay with new database */
				service(wi, DATA_CHANGED, in_out) ;
			break ;
		case INVALIDATE_DATABASE:
			if (wi->user == in_out)
				/* this is my database, it shall become invalid */
				service(wi, SET_DATABASE, NULL) ;
			break ;
		case DATA_CHANGED:
			wi->user = in_out ;
			redisplay(wi) ;
			break ;
		case IS_FILE_OPEN:
			{
				SCHMEDIT_DB *db ;
				QUERY_MESSAGE *msg ;
				msg = in_out ;
				db = wi->user ;
				if (msg && !stricmp(msg->query, db->path))
				{
					/* yes, our instance edits this file */
					msg->answer = TRUE ;
					Awi_show(wi) ;
				}
			}
			break ;
		case STYLE_CLICKED:
		case STYLE_DRAGGED:
			update_data(wi, (STYLE_MESSAGE *)in_out, NULL) ;
			break ;
		case COLOR_CLICKED:
		case COLOR_DRAGGED:
			update_data(wi, NULL, (COLOR_MESSAGE *)in_out) ;
			break ;
		default: return Awi_service(wi, task, in_out) ;
	}
	return TRUE ;	/* task has been treated */
}


static Awindow *create(void *scheme_path)
{
	int i ;
	Awindow *wi = NULL ;
	char *sp = scheme_path ;
	QUERY_MESSAGE msg ;
	msg.query  = sp ;
	msg.answer = FALSE ;
	
	Awi_sendall(IS_FILE_OPEN, &msg) ;
	if (msg.answer != TRUE)
	{
		/* file is not yet open => open it now */
		SCHMEDIT_DB *db ;
		db = Ax_malloc(sizeof(*db)) ;
		if (!db)
			return NULL ;
		do_load_scheme(db, sp) ;
		db->current_dodecime = 0 ;

		wi = Awi_create(&SCHMEDIT_WINDOW) ;
		if (wi)
		{
			wi->user = db ;
			redisplay(wi) ;

			for (i = 0 ; i < 11 ; i++)			
				wi->work[dodecimes[i]].ob_spec.userblk->ub_parm = (long)db ;
			for (i = 0 ; i < 12 ; i++)
			{
				wi->work[heads [i]].ob_spec.userblk->ub_parm = 
				wi->work[bodies[i]].ob_spec.userblk->ub_parm = 
				wi->work[tails [i]].ob_spec.userblk->ub_parm = (long)db ;
			}
			wi->work[BARS      ].ob_spec.userblk->ub_parm = 
			wi->work[_SCHEME   ].ob_spec.userblk->ub_parm = 
			wi->work[BACKGROUND].ob_spec.userblk->ub_parm =  (long)db ;
			
			wi->open(wi) ;
			
			i = FALSE ;
			Awi_sendall(COLOR_AVAILABLE, &i) ;
			if (!i)
			{
				/* there is now style selector => load one */
				sprintf(textbuff, "%s%s", ACSblk->apppath, "COLORSEL.AM") ;
				Ash_module(textbuff) ;
			}
			i = FALSE ;
			Awi_sendall(STYLE_AVAILABLE, &i) ;
			if (!i)
			{
				/* there is now style selector => load one */
				sprintf(textbuff, "%s%s", ACSblk->apppath, "STYLESEL.AM") ;
				Ash_module(textbuff) ;
			}
		}
	}
	return wi ;
}


static int draw(PARMBLK *parmblk, int style, int color, int border)
{
	int points[10], type = BODY_RECT ;
	
	vs_clip_from_parmblk(handle, parmblk) ;
	
	points[0] = points[2] = points[8] = parmblk->pb_x ; 
	points[1] = points[7] = points[9] = parmblk->pb_y ; 
	points[3] = points[5] = parmblk->pb_y + parmblk->pb_h - 1 ;
	points[4] = points[6] = parmblk->pb_x + parmblk->pb_w - 1 ; 

	if (parmblk->pb_currstate & SELECTED)
	{
		vsl_color(handle, BLACK) ;
		vsl_type(handle, DOT) ;
	}
	else
	{
		vsl_color(handle, LWHITE) ;
		vsl_type(handle, SOLID) ;
	}
	v_pline(handle, 5, points) ;
	
	points[0] = parmblk->pb_x + 1 ; 
	points[1] = parmblk->pb_y + 1 ; 
	points[2] = parmblk->pb_x + parmblk->pb_w - 2 ; 
	points[3] = parmblk->pb_y + parmblk->pb_h - 2 ;
	if (!border)
		type |= BORDERS_NONE ;
	draw_note(xhandle, points, type, style, color, 0,0) ;

	vs_clip(handle, FALSE, NULL) ;
	return(parmblk->pb_currstate & ~SELECTED) ; /* AES shall not draw SELECTED, we did it */
}


static int cdecl dodecime_draw(PARMBLK *parmblk)  
{ 
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;
	
	/* find dodecime index */
	int style, color ;
	int i ;
	int index = -1 ;
	for (i = 0 ; i < 11 ; i++)
		if (dodecimes[i] == parmblk->pb_obj)
			index = i ;
	if (index < 0)
	{
		style = db->scheme.dodecime_style[db->current_dodecime] ; 
		color = db->scheme.dodecime_color[db->current_dodecime] ;
		return draw(parmblk, style, color, FALSE) ;
	}
	style = db->scheme.dodecime_style[index] ; 
	color = db->scheme.dodecime_color[index] ;
	return draw(parmblk, style, color, FALSE) ;
}


static int cdecl background_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;

	return draw(parmblk,
		db->scheme.back_style,
		db->scheme.back_color, FALSE) ;          
}


static int cdecl bars_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;
	int dummy ;
	int state = background_draw(parmblk) ;
	
	vs_clip_from_parmblk(handle, parmblk) ;

	vswr_mode(handle, MD_TRANS) ;
	vst_point(handle, 8, &dummy, &dummy, &dummy, &dummy ) ;
	vst_font(handle, 1) ; 	/* system font */
	rgb_tcolor(xhandle, db->scheme.text_color) ;
	vst_alignment(handle, 1, 2, &dummy, &dummy) ;
	v_gtext(handle, 
		parmblk->pb_x + parmblk->pb_w / 2, 
		parmblk->pb_y + parmblk->pb_h / 2, "Bars") ;
	
	vs_clip(handle, FALSE, NULL) ;
	return state ;          
}


static int cdecl scheme_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;

	vs_clip_from_parmblk(handle, parmblk) ;

	draw_scheme(xhandle, &(db->scheme), 0 /*no transpose*/,
		parmblk->pb_x, parmblk->pb_y, parmblk->pb_w, parmblk->pb_h,
		db->current_dodecime, 2 /* lines */, -1 /* dots */, between, 
		0 /* no notes */, FALSE) ;

	vs_clip(handle, FALSE, NULL) ;
	return(parmblk->pb_currstate) ;          
}


static int cdecl head_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;
	
	/* find head index */
	int i ;
	for (i = 0 ; i < 11 ; i++)
		if (heads[i] == parmblk->pb_obj)
			break ;
	return draw(parmblk, 
		db->scheme.note_style_ends[i], 
		db->scheme.note_color_ends[i], TRUE) ;
}


static int cdecl tail_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;
	
	/* find tail index */
	int i ;
	for (i = 0 ; i < 11 ; i++)
		if (tails[i] == parmblk->pb_obj)
			break ;
	return draw(parmblk, 
		db->scheme.note_style_ends[i], 
		db->scheme.note_color_ends[i], TRUE) ;
}


static int cdecl body_draw(PARMBLK *parmblk) 
{
	SCHMEDIT_DB *db = (SCHMEDIT_DB *)parmblk->pb_parm ;
	
	/* find note index */
	int i ;
	for (i = 0 ; i < 11 ; i++)
		if (bodies[i] == parmblk->pb_obj)
			break ;
	return draw(parmblk, 
		db->scheme.note_style[i], 
		db->scheme.note_color[i], TRUE) ;
}


static void scheme_drag(void)
{
	load_dragged_scheme(FALSE) ;
}


static void scheme_open(void)
{
	static char open_path[PATHNAME_LENGTH] = "" ;
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	
   	if ( Af_select("Select scheme:", open_path, scheme_file_extension) )
   	{
    	do_load_scheme(db, open_path) ;
		redisplay(wi) ;
    }
}


static void scheme_close(void)
{
	destroy(ACSblk->ev_window) ;
}


static void scheme_save(void)
{
	SCHMEDIT_DB *db = ACSblk->ev_window->user ;
	do_save_scheme(db, db->path) ;
}

static void scheme_save_as(void)
{
	static char save_as_path[PATHNAME_LENGTH] = "" ;
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;

	sprintf(textbuff, "Save %s as:", db->file) ;
	if (Af_select(textbuff, save_as_path, scheme_file_extension))
	{
		do_save_scheme(db, save_as_path) ;
		redisplay(wi) ;
	}
}


static void scheme_reload(void)
{
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;

	if ( my_alert_str(RELOAD_SCHEME, db->path) != 1 )
		do_load_scheme(db, db->path) ;
	redisplay(wi) ;
}


static void dodecime_cycle(void)
{
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;

	Aus_cycle() ;
	Auo_cycle(wi->work + DODECIME_CYCLE, AUO_CYCGETINDEX, &(db->current_dodecime)) ;
	Awi_obchange(wi, _SCHEME, -1) ;
}


static void dodecime(void)
{
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	int i, buff ;

	switch (ACSblk->ev_obnr)
	{
	case DODECIME_ALL:
		for (i = 10 ; i >= 0 ; i--)
		{
			if (wi->work[DODECIME0].ob_state & SELECTED)
				Adr_del(wi, dodecimes[i]) ;
			else
				Adr_add(wi, dodecimes[i]) ;
		}
		break ;

	case DODECIME_SWAP:
    	for (i = 0 ; i < 5 ; i++)
    	{
    		buff = db->scheme.dodecime_color[i] ;
    		db->scheme.dodecime_color[i] = db->scheme.dodecime_color[0xA - i] ;
    		db->scheme.dodecime_color[0xA - i] = buff ;
    		
    		buff = db->scheme.dodecime_style[i] ;
    		db->scheme.dodecime_style[i] = db->scheme.dodecime_style[0xA - i] ;
    		db->scheme.dodecime_style[0xA - i] = buff ;
    	}
     	redisplay_dodecimes(wi) ;
    	Awi_obchange(wi, _SCHEME, -1) ;
    	break ;
    	
	case DODECIME_ROT:
    	/* rotate colors and styles */

    	buff = db->scheme.dodecime_color[10] ;
    	for (i = 10 ; i > 0 ; i--)
    		db->scheme.dodecime_color[i] = db->scheme.dodecime_color[i-1] ;
    	db->scheme.dodecime_color[0] = buff ;

    	buff = db->scheme.dodecime_style[10] ;
    	for (i = 10 ; i > 0 ; i--)
    		db->scheme.dodecime_style[i] = db->scheme.dodecime_style[i-1] ;
    	db->scheme.dodecime_style[0] = buff ;

     	redisplay_dodecimes(wi) ;
    	Awi_obchange(wi, _SCHEME, -1) ;
    	break ;
	}
}

static void note(void)
{
	int buff_note_color     , buff_note_style      ;
	int buff_note_color_ends, buff_note_style_ends ;
	
	int i ;
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	
	switch (ACSblk->ev_obnr)
	{
	case NOTE_ALL:
		for (i = 11 ; i >= 0 ; i--)
		{
			if (wi->work[BODY0].ob_state & SELECTED)
			{
				Adr_del(wi, heads [i]) ;
				Adr_del(wi, bodies[i]) ;
/*				Adr_del(wi, tails [i]) ;*/
			}
			else
			{
				Adr_add(wi, heads [i]) ;
				Adr_add(wi, bodies[i]) ;
/*				Adr_add(wi, tails [i]) ;*/
			}
		}
		break ;

	case NOTE_6_6:
		for (i = 11 ; i >= 0 ; i--)
		{
			if ((wi->work[BODY0].ob_state & SELECTED && i % 2 == 0) ||
			  (!(wi->work[BODY0].ob_state & SELECTED) && i % 2 ) )
			{
				Adr_del(wi, heads [i]) ;
				Adr_del(wi, bodies[i]) ;
/*				Adr_del(wi, tails [i]) ;*/
			}
			else
			{
				Adr_add(wi, heads [i]) ;
				Adr_add(wi, bodies[i]) ;
/*				Adr_add(wi, tails [i]) ;*/
			}
		}
		break ;

	case NOTE_7_5:
		for (i = 11 ; i >= 0 ; i--)
		{
			switch (i)
			{
			case 0: case 2: case 4: case 5: case 7: case 9: case 11:
				if (wi->work[BODY0].ob_state & SELECTED)
				{
					Adr_del(wi, heads [i]) ;
					Adr_del(wi, bodies[i]) ;
/*					Adr_del(wi, tails [i]) ;*/
				}
				else
				{
					Adr_add(wi, heads [i]) ;
					Adr_add(wi, bodies[i]) ;
/*					Adr_add(wi, tails [i]) ;*/
				}
				break ;
			case 1: case 3: case 6: case 8: case 10:
				if (wi->work[BODY0].ob_state & SELECTED)
				{
					Adr_add(wi, heads [i]) ;
					Adr_add(wi, bodies[i]) ;
/*					Adr_add(wi, tails [i]) ;*/
				}
				else
				{
					Adr_del(wi, heads [i]) ;
					Adr_del(wi, bodies[i]) ;
/*					Adr_del(wi, tails [i]) ;*/
				}
				break ;
			}
		}
		break ;

	case NOTE_SWAP:
    	for (i = 0 ; i < 6 ; i++)
    	{
    		buff_note_color      = db->scheme.note_color     [i] ;
    		buff_note_color_ends = db->scheme.note_color_ends[i] ;
    		db->scheme.note_color     [i] = db->scheme.note_color     [11 - i] ;
    		db->scheme.note_color_ends[i] = db->scheme.note_color_ends[11 - i] ;
    		db->scheme.note_color     [11 - i] = buff_note_color      ;
    		db->scheme.note_color_ends[11 - i] = buff_note_color_ends ;
    		
    		buff_note_style      = db->scheme.note_style     [i] ;
    		buff_note_style_ends = db->scheme.note_style_ends[i] ;
    		db->scheme.note_style     [i] = db->scheme.note_style     [11 - i] ;
    		db->scheme.note_style_ends[i] = db->scheme.note_style_ends[11 - i] ;
    		db->scheme.note_style     [11 - i] = buff_note_style      ;
    		db->scheme.note_style_ends[11 - i] = buff_note_style_ends ;
    	}
    	redisplay_heads (wi) ;
    	redisplay_bodies(wi) ;
    	redisplay_tails (wi) ;
    	break ;

	case NOTE_ROT:
    	/* rotate note colors and styles */
    	buff_note_color = db->scheme.note_color[0xB] ;
    	buff_note_style = db->scheme.note_style[0xB] ;

    	buff_note_color_ends = db->scheme.note_color_ends[0xB] ;
    	buff_note_style_ends = db->scheme.note_style_ends[0xB] ;

    	for (i = 11 ; i > 0 ; i--)
    	{
    		db->scheme.note_color[i] = db->scheme.note_color[i-1] ;
    		db->scheme.note_style[i] = db->scheme.note_style[i-1] ;
    		
    		db->scheme.note_color_ends[i] = db->scheme.note_color_ends[i-1] ;
    		db->scheme.note_style_ends[i] = db->scheme.note_style_ends[i-1] ;
    	}
    	db->scheme.note_color[0] = buff_note_color ;
    	db->scheme.note_style[0] = buff_note_style ;

    	db->scheme.note_color_ends[0] = buff_note_color_ends ;
    	db->scheme.note_style_ends[0] = buff_note_style_ends ;
    	
    	redisplay_heads (wi) ;
    	redisplay_bodies(wi) ;
    	redisplay_tails (wi) ;
    	break ;
	}
}


static void body(void)
{
	int i, buff_note_color, buff_note_style ;
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	
	switch (ACSblk->ev_obnr)
	{
	case BODY_ALL:
		for (i = 11 ; i >= 0 ; i--)
		{
			if (wi->work[BODY0].ob_state & SELECTED)
				Adr_del(wi, bodies[i]) ;
			else
				Adr_add(wi, bodies[i]) ;
		}
		break ;

	case BODY_SWAP:
    	for (i = 0 ; i < 6 ; i++)
    	{
    		buff_note_color      = db->scheme.note_color     [i] ;
    		db->scheme.note_color     [i] = db->scheme.note_color     [11 - i] ;
    		db->scheme.note_color     [11 - i] = buff_note_color      ;
    		
    		buff_note_style      = db->scheme.note_style     [i] ;
    		db->scheme.note_style     [i] = db->scheme.note_style     [11 - i] ;
    		db->scheme.note_style     [11 - i] = buff_note_style      ;
    	}
    	redisplay_bodies(wi) ;
    	break ;
    	
    case BODY_ROT:
    	/* rotate colors and styles */
    	buff_note_color = db->scheme.note_color[0xB] ;
    	buff_note_style = db->scheme.note_style[0xB] ;

    	for (i = 11 ; i > 0 ; i--)
    	{
    		db->scheme.note_color[i] = db->scheme.note_color[i-1] ;
    		db->scheme.note_style[i] = db->scheme.note_style[i-1] ;
    	}
    	db->scheme.note_color[0] = buff_note_color ;
    	db->scheme.note_style[0] = buff_note_style ;

    	redisplay_bodies(wi) ;
    	break ;
	}
}


static void ends(void)
{
	int i, buff_note_color_ends, buff_note_style_ends ;
	Awindow *wi = ACSblk->ev_window ;
	SCHMEDIT_DB *db = wi->user ;
	
	switch (ACSblk->ev_obnr)
	{
	case ENDS_ALL:
		for (i = 11 ; i >= 0 ; i--)
		{
			if (wi->work[HEAD0].ob_state & SELECTED)
			{
				Adr_del(wi, heads[i]) ;
/*				Adr_del(wi, tails[i]) ;*/
			}
			else
			{
				Adr_add(wi, heads[i]) ;
/*				Adr_add(wi, tails[i]) ;*/
			}
		}
		break ;
		
	case ENDS_SWAP:
    	for (i = 0 ; i < 6 ; i++)
    	{
    		buff_note_color_ends = db->scheme.note_color_ends[i] ;
    		db->scheme.note_color_ends[i] = db->scheme.note_color_ends[11 - i] ;
    		db->scheme.note_color_ends[11 - i] = buff_note_color_ends ;
    		
    		buff_note_style_ends = db->scheme.note_style_ends[i] ;
    		db->scheme.note_style_ends[i] = db->scheme.note_style_ends[11 - i] ;
    		db->scheme.note_style_ends[11 - i] = buff_note_style_ends ;
    	}
    	redisplay_heads (wi) ;
    	redisplay_tails (wi) ;
    	break ;

	case ENDS_ROT:
	   	/* rotate colors and styles */
    	buff_note_color_ends = db->scheme.note_color_ends[0xB] ;
    	buff_note_style_ends = db->scheme.note_style_ends[0xB] ;

    	for (i = 11 ; i > 0 ; i--)
    	{
    		db->scheme.note_color_ends[i] = db->scheme.note_color_ends[i-1] ;
    		db->scheme.note_style_ends[i] = db->scheme.note_style_ends[i-1] ;
    	}
    	db->scheme.note_color_ends[0] = buff_note_color_ends ;
    	db->scheme.note_style_ends[0] = buff_note_style_ends ;
    	
    	redisplay_heads (wi) ;
    	redisplay_tails (wi) ;
    	break ;
	}
}


#endif /* PURE C */