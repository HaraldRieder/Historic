/**************************************************************
*
*                PRINT.C
*
**************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <tos.h>
#include <acs.h>
#include <acsplus.h>
#include <graphic.h>
#include <acs_plus.h>
#include <diskfile.h>

#include "version.h"
#include "common.h"
#include "params.hpp"
#include "filter.hpp"

#include "print.ah"
#include "print.hpp"

static INT16 print_in[11] ;
static INT16 print_out[57] ;
static INT16 x_microm, y_microm ;  /* pixel width / height from v_opnwk in micrometers */
static INT16 number_print_fonts ;
static char buff[512] ;

#define landscape    ( db->width > db->height )
#define meta         ( db->stngs.driver_id == 31 || db->copy_page )
#define image        ( db->stngs.driver_id == 91 )
#define all_into_one ( db->options->meta_print_mode == ALL_INTO_ONE || db->copy_page )
/*#define scale_self   ( !db->options->use_WDIALOG || db->stngs.driver_id == 91 )*/

void my_clswk(PRINT_DB *db)
{
	INT16 handle = (INT16)(db->xhandle) ;
	
	if (handle)
	{
		if ( meta )
		{
			/* never change the sequence of the following functions: PURE C error !!! */
			v_meta_extents(handle, 0, 0, db->width, db->height) ;
			vm_pagesize   (handle, db->width, db->height) ;
			vm_coords     (handle, 0, db->height, db->width, 0) ;
		}
		else
			v_clrwk(handle) ;

		vst_unload_fonts(handle, 0) ;	
		v_clswk(handle) ;
		db->xhandle = 0 ;
	}
}

void my_opnwk(PRINT_DB *db)
{
	INT16 i, handle = 0 ;
	char metafile[FILENAME_LENGTH] = "" ;
	
	db->xhandle = 0 ;

	print_in[0] = db->stngs.driver_id ;
	for ( i = 1 ; i <= 8 ; i++ ) 
		print_in[i] = 1 ; 
	print_in[9] = 0 ; 
	print_in[10] = 2 /* RC */ ; 

	if ( meta )
	{
		if ( all_into_one )
		{
			/* metafile name is file name but with extension ".gem" */
			char *dot ;
			strcpy(metafile, db->metaname) ;
			dot = strrchr(metafile, '.') ;
			if (dot) 
				*dot = 0 ;
			strcat(metafile, ".gem") ;
		}
		else
			/* construct filename from page number, e.g. "1.gem" for page 1 */
			sprintf(metafile, "%d.gem", db->page) ;
		
		/* buffer driver ID */
		i = db->stngs.driver_id ;
		print_in[0] = db->stngs.driver_id = 31 ;

		/* security: we do not want 8+3 *file* names like "C:\DIREC.ORY" in the FAT! */
		/* illegal characters in the metafile name are *NOT* detected by TOS !!! */
		if ( strpbrk(metafile, "/:\\") )
		{
			my_alert_str(FILENAME_NOT_VALID, metafile) ;
			return ;
		}
	}
	
	if (image)
	{
		/* unforunately no effect on image file driver: */
		int maxlen = max(db->width, db->height) ;
		db->stngs.scale = 10000l * 0x7fff / maxlen ;
	}

	if (meta || !db->options->use_WDIALOG)
		v_opnwk(print_in, &handle, print_out) ;
/*		v_opnmeta(print_in, &handle, print_out, metafile);*/
	else
/*		v_opnprn(print_in, &handle, print_out, 
				0,0,	/* max x/y resolution matrix printers only */
				PAGE_DEFAULT,	/* e.g. US Letter or DIN A4 */
				&(db->stngs) ) ;*/
		v_opnprnwrk(&handle, print_in, &(db->stngs), print_out) ;
	if (!handle)
	{
		my_alert_str(PRINTING_NOT_POSSIBLE, NULL) ;
		return ;
	}
	
	db->width  = print_out[0] ;
	db->height = print_out[1] ;
	x_microm = print_out[3] ;
	y_microm = print_out[4] ;

	/* load fonts for driver */
	number_print_fonts = 
		print_out[10] + vst_load_fonts(handle, 0) ;

	if ( meta )
	{
		float float_width, float_height ;

		/* restore original driver ID */
		db->stngs.driver_id = i ;
		
		/* copies make no sense with metafiles */
		db->ncopies = 1 ;
		
		/* same color mode as on screen */
		if (direct_color)
			db->xhandle = mark_handle_rgb(handle) ;
		else
			db->xhandle = handle ;
		
		/* file name no effect in v_opnwk ? */
		vm_filename(handle, metafile) ;

		/* metafile driver needs additional infos */
		if (db->options->format == FORMAT_DIN_A4)
		{
			float_width  = DIN_A4_WIDTH  ;
			float_height = DIN_A4_HEIGHT ;
		}
		else
		{
			float_width  = US_LETTER_WIDTH  ;
			float_height = US_LETTER_HEIGHT ;
		}
		/* Note: micrometers => 1/10 millimeters */
		float_width  /= 100 ;
		float_height /= 100 ;
		print_out[3] = print_out[4] = 100 ;
	
		if (landscape)
		{
			db->width  = (INT16)(float_height + 0.5) ;
			db->height = (INT16)(float_width  + 0.5) ;
		}
		else
		{
			db->width  = (INT16)(float_width  + 0.5) ;
			db->height = (INT16)(float_height + 0.5) ;
		}			
	}
	else
	{
		/* normal printer */
		/* query parameters from printer, here: color parameters */
		vq_extnd(handle, 1 /* extended info */, print_out) ;

		if (!db->options->use_WDIALOG)
    		db->ncopies = db->stngs.no_copies ; /* we make the copies */
		else
		{
			/* can the driver make copies ? */
			if ( v_copies(handle, -1) <= 1 )
    			db->ncopies = db->stngs.no_copies ; /* no */
			else db->ncopies = 1 ;	/* yes, it will do it for us */
		}
		/* in the metafile we use the same color mode as on the screen */
		/* for the printer we might need to map: */
		if (!db->converted)
		{
			if (print_out[1] < 2 || print_out[1] > 256 || print_out[4] >= 15 )
			{
				/* printer is direct color (typical for all color printers ?) */	
				db->xhandle = mark_handle_rgb(handle) ;
				
				if (!direct_color)
					/* convert screen indices to printer RGB colors */
					index_to_rgb_scheme( &(db->scheme) ) ;
			}
			else
			{
				/* printer has only color palette (typically black ink only) */
				db->xhandle = handle ;
				
				if (direct_color)
					/* convert screen RGBs to screen palette colors */
					/* and hope that the printer has the same palette */
					/* (256 color palette is available on screen in direct color mode also) */
					rgb_to_index_scheme( &(db->scheme) ) ;
				/* else: use screen indices also on printer.
				   If the printer palette has less/different colors as the screen,
				   ouput will be ugly !!! */
			
				/* really necessary or already done by VDI ??? */
				/*copy_color_palette(
					db->screen_xhandle, db->screen_ncolors, 
					db->xhandle, print_out[1] ) ;*/
			}
			db->converted = TRUE ;
		}
	}

}

#if 0

/*** dummy functions for testing Ash_thermometer and print dialog ***/

INT16 print_init( ThermoData *thermo ) { return TRUE ; }
INT16 print_start( ThermoData *thermo ) 
{
	thermo->aktuell = 0 ; thermo->maximum = 2 ;
	sprintf(thermo->text, "aktuell=%d maximum=%d", 
			thermo->aktuell, thermo->maximum) ;
	return TRUE ;
}
INT16 print_cont( ThermoData *thermo ) {
	if (thermo->aktuell > thermo->maximum) return FALSE ;
	return TRUE ;
}
INT16 print_do( ThermoData *thermo ) {
	thermo->aktuell++ ;
	return TRUE ;
}
INT16 print_stop( ThermoData *thermo ) { return TRUE ; }
INT16 print_quit( ThermoData *thermo ) { return TRUE ; }

#else

/*** the real functions ***/

INT16 print_init ( ThermoData *thermo )	
{
	/* Note: according to HISTORY.TXT, Ash_thermometer() will ignore 
	   the return code of this function => use print_start() */
	PRINT_DB *db = thermo->data ;

	db->page = db->copy_page ? db->copy_page : db->stngs.first_page ;
	db->copy = 1 ;
	db->xhandle = 0 ;		/* invalid => no v_clswk() */
	db->drive_buffer = -1 ;	/* invalid => no Dset...() to restore original drive/path */
	db->scale = db->stngs.scale ; /* backup for later restoration */

	/* increasing or decreasing page numbers ? */
	db->page_inc = 1 ;	/* normally */
	if ( db->stngs.first_page > db->stngs.last_page && !db->copy_page )
	     db->page_inc = -1 ;

	/* init printer color scheme with same color mode as screen */
	memcpy(&(db->scheme), &(db->params->scheme), sizeof(db->scheme)) ;
	db->converted = FALSE ;	/* the scheme colors are not yet converted for the printer */
		
	return TRUE ; 
}

INT16 print_start( ThermoData *thermo )
{
	PRINT_DB *db = thermo->data ;
	char metapath[PATHNAME_LENGTH] = "" ;
	char dirname [FILENAME_LENGTH] = "" ;

	if ( meta )
	{
		char *name ;

		/* buffer current drive and path */
		db->drive_buffer = Dgetdrv() ;
		Dgetpath(db->path_buffer, 0) ;

		if ( db->copy_page )
		{
			/* metafile goes to clipboard as "scrap.gem" */
			strcpy(metapath, ACSblk->scrp_path) ;
			strcat(metapath, "scrap.gem") ;
		}
		else
		{
			if ( !db->stngs.device[0] )
				/* init metapath from MIDI file's path */
				strcpy(db->stngs.device, db->pathname) ;

			/* full path with drive ? */
			if ( db->stngs.device[1] == ':' && 
			     db->stngs.device[2] == '\\' )
				strcpy(metapath, db->stngs.device) ;
			else
			{
				/* make path abolute */
				metapath[0] = 'A' + db->drive_buffer ;
				sprintf(metapath + 1, ":%s\\%s", 
					db->path_buffer, db->stngs.device) ;
			}
		}
		/* set current drive to metafile's drive */
		Dsetdrv( (metapath[0] - 'A') & 0x1F ) ;
			
		/* init metafile directory with file directory */
		name = strrchr(metapath, '\\') + 1 ;
		strcpy(db->metaname, name) ;

		if ( all_into_one )
		{
			if ( Af_length(metapath) == -1 )
			{
				/* a directory with this name exists already */
				my_alert_str(DIR_EXISTS, metapath) ;
				return FALSE ;
			}
			*name = 0 ;	/* pure path with backslash at the end */
		}
		else
		{
			*name = 0 ;	/* pure path with backslash at the end */

			/* metafile directory is MIDI file directory + filename without dot */
			if ( Dsetpath(metapath + 2) < 0 )
			{
				my_alert_str(SET_PATH_ERROR, metapath + 2) ;
				return FALSE ;
			}
			/* create sub-directory for the output metafiles */
			/* sub-dir. with same name as MIDI file but wihtout extension */
			strcpy(dirname, db->metaname) ;
			
			switch( (int)Af_length( db->stngs.device ) )
			{
			case -1: break ;	/* directory exists already */
			case -2:
				/* no file with this name => create this dir. */
				if ( Dcreate(dirname) < 0 )
				{
					my_alert_str(COULD_NOT_CREATE, dirname) ;
					return FALSE ;
				}
				break ;
			default: 
				/* a file with the same name exists */
				if ( my_alert_str(DELETE_FILE, db->stngs.device ) == 1 )
					/* "No" selected by user */
					return FALSE ;
				if ( unlink(db->stngs.device) != 0 )
				{
					my_alert_str(COULD_NOT_DELETE, db->stngs.device) ;
					return FALSE ;
				}
				if ( Dcreate(dirname) < 0 )
				{
					my_alert_str(COULD_NOT_CREATE, dirname) ;
					return FALSE ;
				}
			}
			strcat(metapath, dirname) ;
			strcat(metapath, "\\") ;
		}
		/* set output path for metafiles */
		if ( Dsetpath(metapath + 2) < 0 )
		{
			my_alert_str(SET_PATH_ERROR, metapath + 2) ;
			return FALSE ;
		}
	}
	if ( !meta || all_into_one )
	{
		my_opnwk(db) ;	/* sets also db->ncopies */
		if (!db->xhandle)
			return FALSE ;

		if ( db->copy_page )
			sprintf(buff, "%s%s", metapath, db->metaname) ;
		else if ( meta )
			sprintf(buff, 
				"Generating %s with pages %i .. %i", db->metaname,
				db->stngs.first_page, db->stngs.last_page) ;
		else sprintf(buff, 
				"Printing pages %i .. %i (%i copies)", 
				db->stngs.first_page, db->stngs.last_page, db->ncopies) ;
	}
	else 
	{
		db->ncopies = 1 ;
		sprintf(buff, 
			"Generating metafiles %i.gem .. %i.gem", 
			db->stngs.first_page, db->stngs.last_page) ;
	}
	strncpy(thermo->text, buff, sizeof(thermo->text) - 1) ;
	thermo->text[ sizeof(thermo->text) - 1 ] = 0 ;
	thermo->aktuell = 0 ;
	thermo->maximum = 
		(1 + abs(db->stngs.last_page - db->stngs.first_page))
		* db->ncopies ;
	if (db->copy_page)
		thermo->maximum = 1 ;	/* always one page goes to clipboard */

	return TRUE ;
}

INT16 print_cont( ThermoData *thermo )
{
	PRINT_DB *db = thermo->data ;

	if (db->copy_page)
	{
		if (db->copy_page < 0)
			/* < 0 is the stop indication */
			return FALSE ;
	}
	else if (db->copy >= db->ncopies)
	{    	
		/* Note: depending on page_inc, last page may
		   be less or more than and even equal to page ! */
		if (db->page_inc > 0)
		{
			if (db->page > db->stngs.last_page)
				return FALSE ;
		}
		else
		{
			if (db->page < db->stngs.last_page)
				return FALSE ;
		}
	}
	return TRUE ;
}

static void next_sheet(PRINT_DB *db, INT16 is_last)
{
	INT16 handle = (INT16)(db->xhandle) ;
	
	if ( meta )
	{
		if ( all_into_one && !is_last )
			v_form_adv(handle) ;
	}
	else
	{
		v_updwk(handle) ;
		v_clrwk(handle) ;
	}
} 

INT16 print_do( ThermoData *thermo )
{
	PRINT_DB *db = thermo->data ;
	INT16 x = 0, w ; 
	INT16 points[4] ;
	INT16 pts = db->params->points, foot_pts = FOOTLINE_HEIGHT ;
	int line_width, line_width_bars, line_width_sub_bars, line_width_notes ;

	if (!db->xhandle)
	{
		/* 1 metafile per sheet, open metafile driver */
		my_opnwk(db) ;
		if (!db->xhandle)
			return FALSE ;
	}
	/* db->width calculated in my_opnwk() for metafiles,
	   x/y-micrometers not set before my_opnwk(): */
	line_width         = mm_to_pixel(db->params->line_width        , y_microm) ;
	line_width_bars    = mm_to_pixel(db->params->bar_line_width    , x_microm) ; 
	line_width_sub_bars= mm_to_pixel(db->params->sub_bar_line_width, x_microm) ;
	line_width_notes   = mm_to_pixel(db->params->note_line_width   , y_microm) ;
	w = db->width ;	
	
	if (landscape)
	{
		/* 2 draw_page() per paper side */
		if ( ( db->page_inc > 0 && db->page % 2 == 0 ) ||
		     ( db->page_inc < 0 && db->page % 2 != 0 ) )
			/* now we print onto the right part of the sheet */
			x = db->width / 2 ;
		w /= 2 ;
		pts = pts * 7/10 ; 	/* around 1/sqrt(2) */
		foot_pts = foot_pts * 7/10 ;
		line_width          = line_width          * 7/10 ;
		line_width_bars     = line_width_bars     * 7/10 ; 
		line_width_sub_bars = line_width_sub_bars * 7/10 ;
		line_width_notes    = line_width_notes    * 7/10 ;
	}
	
	/* no clipping at all */
	points[0] = points[1] = 0 ;
	points[2] = db->width ; 
	points[3] = db->height ;

	if ( ( (db->page & 1) && (db->stngs.page_flags & PG_ODD_PAGES )) ||
	     (!(db->page & 1) && (db->stngs.page_flags & PG_EVEN_PAGES)) || 
	     db->copy_page )
	{
		draw_page(db->xhandle, 
			x, 0, w, db->height,
			points,				/* clipping */ 
			y_microm,
			db->track_table,	/* the data to draw... */
			db->filter->track,
			db->layout,		/* with this layout... */
			db->page - 1,	/* index of page to draw */
			db->params->font, pts,
			db->params->effects,	/* text effects for title only */
			foot_pts,
			db->params->title,
			db->filename,	/* for footline ... */
			db->filesize,
			CAPTION, VERSION, PLATFORM,
			db->params->note_height,	
			MAX_DYNSCALE, db->params->note_dynscale,        
			db->params->mode,			/* Rieder, Beyreuther, Mix */
			db->params->note_type,	/* e.g. with tail, etc. */
			&(db->scheme),
			db->params->transpose,
			db->params->bars_per_line,
			db->params->sub_bars,
			line_width, 
			line_width_bars, 
			line_width_sub_bars, 
			line_width_notes
			) ;
		db->copy_page = (- db->copy_page) ; /* "ready" indication if != 0 */
	}
	thermo->aktuell++ ;

	if (landscape)
	{
		if (x)
		{
			/* this was the right page */
			db->copy++ ;
			if (db->copy <= db->ncopies)
				/* decrement to left page for next sheet of paper */
				db->page -= db->page_inc ;
			else
			{
				/* go to next page and sheet, copy number 1 */
				db->copy = 1 ;
				db->page += db->page_inc ;
			}
		}
		else
		{
			/* sheet not yet filled completely */
			/* no next_sheet() here ! */
			db->page += db->page_inc ;
			return TRUE ;
		}
	}
	else /* 1 page per sheet side */
	{
		db->copy++ ;
		if (db->copy > db->ncopies)
		{
			/* go to next page, copy number 1 */
			db->copy = 1 ;
			db->page += db->page_inc ;
		}
	}

	next_sheet(db, !print_cont(thermo)) ;
	
	if ( meta && !all_into_one )
	{
		/* this was the last component on this sheet in a 
		   metafile with 1 or 2 (landscape) pages per file */
		my_clswk(db) ;
	}	
	return TRUE ;
}

INT16 print_stop( ThermoData *thermo ) 
{ 
	PRINT_DB *db = thermo->data ;
	
	/* close physical workstation for printer */
	my_clswk(db) ;

	if ( meta )
	{
		/* "GEMFILE.GEM" exists because of GDOS error ? */
		/* note: metaname could be GEMFILE.MID */
		if ( !strstr(db->metaname, "GEMFILE.") )
			/* does not harm the dir. in one_per_page mode: */
			Fdelete("GEMFILE.GEM") ;
	}
	if (db->drive_buffer >= 0)
	{
		/* restore original drive and path */
		Dsetdrv (db->drive_buffer) ;
		Dsetpath(db->path_buffer ) ;
		db->drive_buffer = -1 ;
	}

	/* restore scale changed for image output */
	db->stngs.scale = db->scale ; 

	return TRUE ; 
}

INT16 print_quit( ThermoData *thermo ) { return print_stop(thermo) ; }

#endif

/*
{
	int first, last, page, i, length ;
	char path_buffer [pathname_length], 
	     clipboard   [pathname_length], 
		 metafilename[filename_length] ;
	char *point, pagestring[9] ;
	int points[4], drive, drive_buffer ;
	unsigned long existing_drives ;
	int handle, work_in[11], work_out[57] ;

	/*** print (to printer or to file ?) ***/
	if (ACSblk->ev_object[TO_FILE].ob_state & SELECTED)
	{
		/*** buffer current drive and path ***/
		drive_buffer = Dgetdrv() ;
		Dgetpath(path_buffer, 0) ;

		/*** check which drives exist (get bit table) ***/
		existing_drives = Dsetdrv(drive_buffer) ;

		/*** get/set clipboard path ***/
		scrp_read(clipboard) ;
		if (clipboard[0])
		{
			/*** test if clipboard path already defined physically exists ***/
			Dsetdrv( (*clipboard - 'A') & 0x1F ) ;
			if ( Dsetpath(clipboard + 2) < 0 )
			{
				alert_str(PATH_NOT_EXIST, clipboard) ;
				clipboard[0] = 0 ;
			}
		}
		else
		{
			/*** no valid clipboard path defined ***/
			existing_drives >>= 2 ; /* drive 'C' in least bit */

			/*** search first existing drive ***/
			for ( drive = 'C' ; drive <= 'Z' ; drive++ )
			{
				if (existing_drives & 0x0001)
				{
					clipboard[0] = drive ; 
					drive = 'Z' + 2 ;
				}
				existing_drives >>= 1 ; /* test next drive */
			}
			/*** if no drive found, use current drive ***/
			if ( !clipboard[0] ) clipboard[0] = drive_buffer + 'A' ;
			clipboard[1] = 0 ;
			strcat(clipboard, ":\\CLIPBRD\\") ;

			/*** test if clipboard path already exists ***/
			Dsetdrv( (*clipboard - 'A') & 0x1F ) ;
			if ( Dsetpath("\\CLIPBRD\\") < 0 )
			{
				/*** directory must be created ***/
				Dsetpath("\\") ;
				if ( Dcreate("CLIPBRD") < 0 )
				{
					alert_str(DIR_NOT_CREATED, clipboard) ;
					Dsetpath(p->path) ;
				}
				else
				{
					/*** define path for clipboard ***/
					alert_str(DIR_CREATED, clipboard) ;
					Dsetpath("\\CLIPBRD\\") ;
					scrp_write(clipboard) ;
				}
			}
		}
		if (ACSblk->ev_object[INTO_ONE].ob_state & SELECTED)
		{
			/*** all pages into SCRAP.GEM separated by form advances ***/
			/*** open physical workstation (metafile driver) ***/
			work_in[0] = METAFILE_DRIVER ; /* metafile driver of assign.sys */
			for ( i = 1 ; i <= 8 ; i++ ) work_in[i] = 1 ; 
			work_in[9] = 0 ; work_in[10] = RC ; 
			v_opnwk(work_in, &handle, work_out) ;
			if (handle)
			{
				vm_filename(handle, "SCRAP.GEM") ;

				/*** load metafile fonts ***/
				vst_load_fonts(handle, 0) ;

				/*** layout  and "print" ***/
/*				if ( page_layouter(p->screen_handle, p->screen_width, p->screen_height, 
				     p->drawer_wi, FALSE) == LAYOUT_GOOD ) for ( page = first ; page <= last ; page++ ) 
*/				{
					itoa(page + 1, ACSblk->ev_object[PAGE].ob_spec.tedinfo->te_ptext, 10) ;
					Awi_obchange(ACSblk->ev_window, PAGE_CARRIER, -1) ;      
					points[0] = points[1] = 0 ;
					points[2] = p->screen_width ; 
					points[3] = p->screen_height ;
/*					draw_page(handle, p->drawer_wi, 0, 0, points, 1, page) ;
*/					v_form_adv(handle) ;
				}
/*				reset_layout(p->drawer_wi) ;*/
				/*** never change the sequence of the following functions: PURE C error !!! ***/
				v_meta_extents(handle, 0, 0, p->screen_width, p->screen_height) ;
				vm_pagesize(handle, 2090, 2970) ;	/* DIN A4 */
				vm_coords(handle, 0, p->screen_height, p->screen_width, 0) ;

				vst_unload_fonts(handle, 0) ;	
				v_clswk(handle) ;
			}
			else alert_str(METAFILING_NOT_POSSIBLE, "") ;
		}
		else for ( page = first ; page <= last ; page++ )
		{
			/*** 1 file per page ***/ 
			itoa(page + 1, ACSblk->ev_object[PAGE].ob_spec.tedinfo->te_ptext, 10) ;
			Awi_obchange(ACSblk->ev_window, PAGE_CARRIER, -1) ;      

			/*** open physical workstation (metafile driver) ***/
			work_in[0] = METAFILE_DRIVER ; /* metafile driver of assign.sys */
			for ( i = 1 ; i <= 8 ; i++ ) work_in[i] = 1 ; 
			work_in[9] = 0 ; work_in[10] = RC ; 
			v_opnwk(work_in, &handle, work_out) ;
			if (handle)
			{
				/*** set file name, set extension to "GEM", include page number ***/
				strcpy(metafilename, p->filename) ;
				point = strrchr(metafilename, '.') ;
				if (!point) 
				{
					point = metafilename + strlen(metafilename) ;
					point[0] = '.' ; point[1] = 0 ;
				}
				strcpy( point + 1, "GEM" ) ;
				itoa(page + 1, pagestring, 10) ;
				length = strlen(pagestring) ;
				memcpy( point - length, pagestring, length ) ;
				vm_filename(handle, metafilename) ;

				/*** load metafile fonts ***/
				vst_load_fonts(handle, 0) ;

				/*** layout  and "print" ***/
/*				if ( page_layouter(p->screen_handle, p->screen_width, p->screen_height, 
				     p->drawer_wi, FALSE /* all */) == LAYOUT_GOOD )   
*/				{
					points[0] = points[1] = 0 ;
					points[2] = p->screen_width ; 
					points[3] = p->screen_height ;
/*					draw_page(handle, p->drawer_wi, 0, 0, points, 1, page) ;
*/					v_meta_extents(handle, 0, 0, p->screen_width, p->screen_height) ;
					vm_pagesize(handle, 2090, 2970) ;
					vm_coords(handle, 0, p->screen_height, p->screen_width, 0) ;
				}
/*				reset_layout(p->drawer_wi) ;*/
				vst_unload_fonts(handle, 0) ;	
				v_clswk(handle) ;
			}
			else alert_str(METAFILING_NOT_POSSIBLE, "") ;
		}

		/*** "GEMFILE.GEM" exists because of GDOS error ? ***/
		Fdelete("GEMFILE.GEM") ; /* a workaround ! */

		/*** restore original drive and path ***/		
		Dsetdrv(drive_buffer) ;
		Dsetpath(path_buffer) ;
	}
	else 
	{
		/*** generate printed paper ***/
		points[0] = points[1] = 0 ;
		points[2] = p->print_width - 1 ; 
		points[3] = p->print_height - 1 ;
		for ( page = first ; page <= last ; page++ )
		{
/*			draw_page(p->handle, p->drawer_wi, 0, 0, points, 1, page) ;*/
			v_updwk(p->handle) ;
			v_clrwk(p->handle) ;
		}
	}
}


*/