/**************************************************************
*
*                PARAMS.C
*
**************************************************************/
#if defined (__PUREC__)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <tos.h>
#include <acs.h>
#include <acsplus.h>
#include <acs_plus.h>
#include <diskfile.h>
#include "messages.h"
#include "common.h"
#include "schmedit.h"
#include "schmedit.hpp"
#endif

#include <graphic.h>
#include <graphicf.h>

#include "params.hpp"

static FNT_DIALOG *fnt_dialog ; 

static const char LINE_WIDTHS[] = "0.1 mm|0.2 mm|0.3 mm|0.5 mm|0.7 mm|1.0 mm|1.4 mm|2.0 mm" ;


#if defined (__PUREC__)

/*static char scheme_file_extension[] = "PAR,par\0" ;*/
static char scheme_file_extension[8] = "\0\0\0\0\0\0\0\0" ;

void set_scheme_file_extension(const char *ext)
{
	strcpy(scheme_file_extension, ext) ;
	set_schmedit_file_extension(ext) ;
}

static INT16 use_wdialog = FALSE ;
static INT16 pixel_height ;

void use_WDIALOG(INT16 use, INT16 micrometers)
{
	use_wdialog = use ;
	pixel_height = micrometers ;
}

static char textbuff[PATHNAME_LENGTH] = "" ;

/* WDIALOG font selector: */
#define	FONT_FLAGS	 ( FNTS_BTMP + FNTS_OUTL + FNTS_MONO + FNTS_PROP )
#define	BUTTON_FLAGS ( FNTS_SNAME + FNTS_SSTYLE + FNTS_SSIZE + FNTS_BSET )

#include "params.h"
#include "params.ah"

static INT32 xhandle ; /* VDI handle, extended */

void params_set_handle(INT32 _xhandle)
{
	xhandle = _xhandle ;
	schmedit_set_handle(xhandle) ;
}

static char slider_text[12] ; /* buffer used in slider live procedures */

static int messages = TRUE ;

static char *int_live(void *value, long pos)
{
	if (messages) 
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return A_int_live(value, (int)pos) ;
}

static char *plus_1_int_live(void *value, long pos)
{
	if (messages) 
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return A_plus_1_int_live(value, (int)pos) ;
}

static char * right_border_live(void *value, long pos)
{
	if (messages)
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	pos = MAX_BORDER - pos ; /* this slider goes from right to left ! */
	return A_int_live(value, (int)pos) ;
}

static void update_border_sliders(Awindow *wi)
{
	PARAMS_DB *db = wi->user ;
	long pos1, pos2 ;
	INT16 i ;
	SLLIVE sllive1, sllive2 ;
	
	if (!db) 
	{
		sllive1.call = sllive2.call = A_slider_dead ;
		pos1 = 0 ;
		pos2 = MAX_BORDER ;
	}
	else
	{
		sllive1.call = int_live ;
		sllive2.call = right_border_live ;	/* reverse */
	
		/* set slider positions and live data */
		Auo_cycle(wi->work + BORDERS_CYCLE, AUO_CYCGETINDEX, &i) ;
		if (i == 0)
		{
			/* top and bottom */
			pos1 = db->upper_border ;
			pos2 = MAX_BORDER - db->lower_border ;
			sllive1.obj = &(db->upper_border) ;
			sllive2.obj = &(db->lower_border) ;
		}
		else 
		{
			/* left and right */
			pos1 = db->left_border ;
			pos2 = MAX_BORDER - db->right_border ;
			sllive1.obj = &(db->left_border ) ;
			sllive2.obj = &(db->right_border) ;
		}
	}
	/* set live procedures */
	Auo_slider(wi->work + LEFT_BORDER , AUO_SLCALL, &sllive1) ; 
	Auo_slider(wi->work + RIGHT_BORDER, AUO_SLCALL, &sllive2) ; 

	/* set positions */
	Auo_slider(wi->work + LEFT_BORDER , AUO_POS, &pos1) ; 
	Auo_slider(wi->work + RIGHT_BORDER, AUO_POS, &pos2) ; 

    /* refresh text */
	Auo_slider(wi->work + LEFT_BORDER , AUO_SLLIVE, NULL) ; 
	Auo_slider(wi->work + RIGHT_BORDER, AUO_SLLIVE, NULL) ; 

	/* redisplay */
	Auo_slider(wi->work + LEFT_BORDER , AUO_FULLUPDATE, NULL) ; 
	Auo_slider(wi->work + RIGHT_BORDER, AUO_FULLUPDATE, NULL) ; 
}

static char * note_distance_live(void *value, long pos) 
{
	/* example: MAX_NOTE_DISTANCE is 0.8
	   The slider is then adjusted to 16 - 1 = 15.
	   The range is 0..15, i.e. it has 16 separate positions.
	   The float range then is 0.05 .. 0.8, also 16 positions. */
	float distance = (float)(++pos) / 20 ;
	*((float *)value) = distance ;
	sprintf(slider_text, "%.2f", distance) ; 
	if (messages)
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return slider_text ;
}

/*#define HEIGHT_STEPS 20 */

/*static char * note_height_live(void *value, long pos) 
{
	/* y(x) = mx + c */
	float *height = value ;
	*height = MAX_AVERAGE_HEIGHT / HEIGHT_STEPS * pos + MIN_AVERAGE_HEIGHT ;
	sprintf(slider_text, "%.2f", *height) ; 
	if (messages)
		Awi_sendall(DATA_CHANGED_SLIDER, NULL) ;
	return slider_text ;
}*/


static void update_distance_slider(Awindow *wi)
{
	PARAMS_DB *db = wi->user ;
	OBJECT   *obj = wi->work + DISTANCE_SLIDER ;
	INT16 i ;
	SLLIVE sllive ;

	if (!db) 
	{
		sllive.call = A_slider_dead ;
		A_slider_init(obj, 15, 2, 0, &sllive) ;
	}
	else
	{
		/* set slider position and data */
		Auo_cycle(wi->work + DISTANCE_CYCLE, AUO_CYCGETINDEX, &i) ;
		switch (i)
		{
		case 0:	
			sllive.call = plus_1_int_live ;
			sllive.obj  = &(db->system_distance) ;
			A_slider_init(obj, MAX_SYSTEM_DISTANCE-1, 3, db->system_distance-1, &sllive) ;
			break ;
		case 1:	
			sllive.call = plus_1_int_live ;
			sllive.obj  = &(db->track_distance) ;
			A_slider_init(obj, MAX_TRACK_DISTANCE-1, 3, db->track_distance-1, &sllive) ;
			break ;
		case 2:	
			sllive.call = note_distance_live ;
			sllive.obj  = &(db->note_distance) ;
			A_slider_init(obj, (long)(MAX_NOTE_DISTANCE*20)-1, 5, (long)(db->note_distance*20+0.5) - 1, &sllive) ;
			break ;
		}
	}
    /* refresh text */
	Auo_slider(obj, AUO_SLLIVE, NULL) ; 

	/* redisplay */
	Auo_slider(obj, AUO_FULLUPDATE, NULL) ; 
}

static void update_scheme_text(Awindow *wi)
{
	PARAMS_DB *db = wi->user ;
	AUSERBLK *auserblk = (AUSERBLK*)(wi->work[SCHEME].ob_spec.userblk) ;
	char *s = "?" ;
	if ( db && db->scheme_path[0] ) 
		s = strrchr( db->scheme_path, '\\' ) + 1 ;
	if (!s) s = db->scheme_path ;

	if (auserblk->bubble)
		Ast_delete(auserblk->bubble) ;
	auserblk->bubble = Ast_create(s) ;
}

static void redisplay_note_type(Awindow *wi)
{
	Awi_obredraw(wi, HEAD) ;
	Awi_obredraw(wi, BODY) ;
	Awi_obredraw(wi, TAIL) ;
}


static void update_3d_checkbox(Awindow *wi)
{
	PARAMS_DB *db = wi->user ;

	if (!db || (db->note_type & BORDERS_NONE))
		wi->work[_3D].ob_state |= DISABLED ;
	else
		wi->work[_3D].ob_state &= ~DISABLED ;
		
	Awi_obredraw(wi, _3D) ;
}


static void redisplay(Awindow *wi)
{
	PARAMS_DB *db = wi->user ;
	SLLIVE sllive ; 
	long pos ;
	/* not multiply used = "normal" */
	int normal_sliders[] = {
		BARS_PER_LINE, BAR_LENGTH, SUB_BARS, 
		HEIGHT, DYNAMIC, 0 /* the end */ } ;
	int buttons[] = { 
		HEAD, BODY, TAIL, 
		HEAD_CYCLE, BODY_CYCLE, TAIL_CYCLE,
		_BOLD, _ITALIC, _UNDERLINED, _FONT,
		BORDERS, AUTO_BACK,
		SCHEME, BARS_ATTR, SUB_BARS_ATTR, NOTES_ATTR, LINES_ATTR,
		0 /* the end */ } ;
	int i ;

	/* fast exit */
	if (ACSblk->appexit)
		return ;
		
	Awi_setinfo(wi, db?db->filename:"?") ;

	/* This is an action for the params window and not more. 
	   Avoid DATA_CHANGED_SLIDER messages because of updated
	   slider positions (AUO_SLLIVE). */
	messages = FALSE ;

	if (!db)
	{
		/* set live procedures */
		sllive.call = A_slider_dead ;
		for (i = 0 ; normal_sliders[i] ; i++) 
			Auo_slider(wi->work + normal_sliders[i], AUO_SLCALL, &sllive) ; 
		Aob_puttext(wi->work, TITLE, "?") ;
	}
	else
	{
		char *s ;
		validate(db) ;
	
		if ( !db->title[0] )
		{
			/* init with file name */
			strcpy(db->title, db->filename) ;
			s = strrchr(db->title, '.') ;
			if (s) *s = 0 ;		/* cut away extension */
		}
		Aob_puttext(wi->work, TITLE, db->title) ;
		
		/* set live procedures and positions */
		/* sliders starting from 1 */
		sllive.call = plus_1_int_live ; 
		sllive.obj  = &(db->bars_per_line) ; Auo_slider(wi->work + BARS_PER_LINE, AUO_SLCALL, &sllive) ; 
		sllive.obj  = &(db->bar_length   ) ; Auo_slider(wi->work + BAR_LENGTH   , AUO_SLCALL, &sllive) ; 
		sllive.obj  = &(db->sub_bars     ) ; Auo_slider(wi->work + SUB_BARS     , AUO_SLCALL, &sllive) ; 
		sllive.obj  = &(db->note_height  ) ; Auo_slider(wi->work + HEIGHT       , AUO_SLCALL, &sllive) ; 
		pos = db->bars_per_line-1; if (pos < 0) pos = 0 ;
		Auo_slider(wi->work + BARS_PER_LINE, AUO_POS, &pos) ; 
		pos = db->bar_length   -1; if (pos < 0) pos = 0 ;
		Auo_slider(wi->work + BAR_LENGTH   , AUO_POS, &pos) ; 
		pos = db->sub_bars     -1; if (pos < 0) pos = 0 ;
		Auo_slider(wi->work + SUB_BARS     , AUO_POS, &pos) ; 
		pos = db->note_height  -1; if (pos < 0) pos = 0 ;
		Auo_slider(wi->work + HEIGHT       , AUO_POS, &pos) ; 

		/* sliders starting from 0 */
		sllive.call = int_live ; 
		sllive.obj  = &(db->note_dynscale) ; 
		Auo_slider(wi->work + DYNAMIC, AUO_SLCALL, &sllive) ; 
		pos = db->note_dynscale ; 
		Auo_slider(wi->work + DYNAMIC, AUO_POS, &pos) ; 

		/* float sliders */
/*		sllive.call = note_height_live ;
		sllive.obj  = &(db->note_height) ;
		Auo_slider(wi->work + HEIGHT, AUO_SLCALL, &sllive) ; 
		pos = (int)(db->note_height / MIN_AVERAGE_HEIGHT + 0.5) - 1 ; 
		Auo_slider(wi->work + HEIGHT, AUO_POS, &pos) ; */
		
		redisplay_note_type(wi) ;
		
		/* horizontal lines */
		switch (db->horizontal_lines)
		{
		case 1: case 2: 
		case 3:	case 4:	
			i = db->horizontal_lines - 1 ; 
			break ;
		case 5:	
			db->horizontal_lines = 6 ; /* 5 is not allowed */
		case 6:  
			i = 4 ;
			break ;
		default: 
			db->horizontal_lines = i = 1 ; /* not allowed */
		}
		Auo_cycle(wi->work + LINES, AUO_CYCINDEX, &i) ;
		Awi_obchange(wi, LINES, -1) ;
		
		/* transpose */
		i = db->transpose ;
		Auo_cycle(wi->work + TRANSPOSE, AUO_CYCINDEX, &i) ;
		Awi_obchange(wi, TRANSPOSE, -1) ;
		
		/* mode */
		switch (db->mode)
		{
			case Beyreuther: i = 0 ; break ;
			case Mix:        i = 2 ; break ;
			default:         i = 1 ; /* Rieder */
		}		
		Auo_cycle(wi->work + INVENTOR, AUO_CYCINDEX, &i) ;
		Awi_obchange(wi, INVENTOR, -1) ;
		
		/* text effects */
		if (db->effects & TF_THICKENED)
		     wi->work[_BOLD].ob_state |= SELECTED ;
		else wi->work[_BOLD].ob_state &= ~SELECTED ;
		if (db->effects & TF_SLANTED)
		     wi->work[_ITALIC].ob_state |= SELECTED ;
		else wi->work[_ITALIC].ob_state &= ~SELECTED ;
		if (db->effects & TF_UNDERLINED)
		     wi->work[_UNDERLINED].ob_state |= SELECTED ;
		else wi->work[_UNDERLINED].ob_state &= ~SELECTED ;
		
		/* borders */
		if (db->note_type & BORDERS_NONE)
		     wi->work[BORDERS].ob_state &= ~SELECTED ;
		else wi->work[BORDERS].ob_state |= SELECTED ;
		if (db->note_type & BORDERS_3D)
		     wi->work[_3D].ob_state |= SELECTED ;
		else wi->work[_3D].ob_state &= ~SELECTED ;
	}
	Awi_obchange(wi, TITLE, -1) ;
	update_border_sliders(wi) ;
	update_distance_slider(wi) ;
	update_scheme_text(wi) ;
	update_3d_checkbox(wi) ;

	for (i = 0 ; normal_sliders[i] ; i++) 
	{
		Auo_slider(wi->work + normal_sliders[i], AUO_SLLIVE, NULL) ; 
		Auo_slider(wi->work + normal_sliders[i], AUO_FULLUPDATE, NULL) ; 
	}
	for (i = 0 ; buttons[i] ; i++) 
	{
		if (db)
		     wi->work[buttons[i]].ob_state &= ~DISABLED ;
		else wi->work[buttons[i]].ob_state |= DISABLED ;
		/*Awi_obchange(wi, buttons[i], -1) ; too weak for check boxes */
		Awi_obredraw(wi, buttons[i]) ;
	}
	messages = TRUE ;
}


static INT16 init( Awindow* wi )
{
	/* redraw has no effect in click procedure of popup,
	   therefore we do it afterwards with the help of AWS_LATEUPDATE */
	redisplay_note_type(wi) ;
	return OK ;
}


static INT16 load_dragged_scheme(INT16 check_only) 
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	Awindow *ori = ACSblk->Aselect.window ;
	INT16 obnr ;
	OBJECT  *obj  ;
	AOBJECT *aobj ;

	if (!db) return FALSE ;

	if (ACSblk->Aselect.actlen < 1)
		return FALSE ;
		
	Adr_start() ;
	for (obnr = Adr_next() ; obnr != -1 ; obnr = Adr_next())
	{
		obj = (obnr & A_TOOLBAR ? &ori->toolbar[obnr & A_MASK] : &ori->work[obnr]) ;
		aobj = (!(obj[0].ob_flags & LASTOB) && obj[1].ob_flags & AEO ? (AOBJECT *)&obj[1] : NULL) ;
		
		if (aobj && aobj->type == AT_FILE)
		{
			char *file = aobj->userp1 ;
			char *dot = strrchr(file, '.') ;
			if (dot && 
				!strnicmp(dot + 1, scheme_file_extension, strlen(scheme_file_extension)))
			{
				if (!check_only)
				{
					do_load_scheme(db, file) ;
					Adr_del(ori, obnr) ;
					Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;	
				}
				return TRUE ;
			}
		}
	}
	return FALSE ;
}


static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	PARAMS_DB *db = wi->user ;
	
	switch (task)
	{	
		case AS_CHECKDRAG:
			/*form_alert( 1, "[1][AS_CHECKDRAG received.][OK]" );*/
			*((INT16 *)in_out) = load_dragged_scheme(TRUE /* check only */) ;
			return TRUE ;
		/*case AS_DRAGGED:
			return load_dragged_scheme(FALSE) ; done be scheme_drag() */
		case AS_TERM: 
			if (ACSblk->appexit)
			{
				/* only necessary for direct call of fnts_... functions
				   (ASH_FONT not defined) */
				if (fnt_dialog)
				{
					/* destroy singleton font selector, late
					   destruction saves expensive fnts_create() calls */
					/* handle != 0 => unload fonts! */
					fnts_delete( fnt_dialog, ACSblk->vdi_handle ); 
					fnt_dialog = NULL ; 
				}
				Awi_delete(wi) ; 
			}
			break ; 
		case AS_FONT:
			{
				A_FontSel *fnt ;
				fnt = (A_FontSel *)in_out ;
				if ( db != NULL &&
				     (fnt->button == FNTS_OK || 
				      fnt->button == FNTS_SET) )
				{
					db->font   = (int)(fnt->font_id) ;
					db->points = (int)(fnt->pt >> 16) ;
					Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;	
				}
			}
			break ;
		case AS_INFO: 
/*			A_dialog(&PARAMS_INFO) ;
			Awi_dialog(&INFO_INFO_WINDOW) ; */
			break ;
		case SET_DATABASE:
			if (wi->user != in_out)
				/* redisplay with new database */
				service(wi, DATA_CHANGED, in_out) ;
			break ;
		case INVALIDATE_DATABASE:
			if (wi->user == in_out)
				/* this is my database, it shall become invalid */
				service(wi, SET_DATABASE, NULL) ;
			break ;
		case DATA_CHANGED:
			/* somebody else informs us that our database did change */
			wi->user = in_out ;
			wi->work[SCHEME].ob_spec.userblk->ub_parm = 
			wi->work[HEAD   ].ob_spec.userblk->ub_parm = 
			wi->work[BODY   ].ob_spec.userblk->ub_parm = 
			wi->work[TAIL   ].ob_spec.userblk->ub_parm = (long)in_out ;
			redisplay(wi) ;
			break ;
		case FILE_WAS_SAVED:
			if (!stricmp(db->scheme_path, (const char*)in_out))
			{
				/* scheme file changed by scheme editor => reload */
				do_load_scheme(db, db->scheme_path) ;
				update_scheme_text(wi) ;
				Awi_obredraw(wi, SCHEME) ;
				Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
			}
			break ;
		default: return Awi_service(wi, task, in_out) ;
	}
	return TRUE ;	/* task has been treated */
}


static Awindow *create (void *parent)
{
	SLLIVE sllive ;
	
	Awindow *wi = Awi_create(parent) ;
	if (wi)
	{
/*		long range ;*/
		sllive.call = A_slider_dead ;
		
		A_slider_init(wi->work + LEFT_BORDER , MAX_BORDER, 3,          0, &sllive) ;
		A_slider_init(wi->work + RIGHT_BORDER, MAX_BORDER, 3, MAX_BORDER, &sllive) ;

/*		range = HEIGHT_STEPS -1 ;
		A_slider_init(wi->work + HEIGHT , range       , 5, range/2, &sllive) ;*/
		A_slider_init(wi->work + DYNAMIC, MAX_DYNSCALE        , 3, 0      , &sllive) ;
		
		A_slider_init(wi->work + HEIGHT       , MAX_AVERAGE_HEIGHT-1, 2, 0, &sllive) ;
		A_slider_init(wi->work + BARS_PER_LINE, MAX_BARS_PER_LINE -1, 3, 0, &sllive) ;
		A_slider_init(wi->work + BAR_LENGTH   , MAX_BAR_LENGTH    -1, 3, 0, &sllive) ;
		A_slider_init(wi->work + SUB_BARS     , MAX_SUB_BARS      -1, 3, 0, &sllive) ;
		
		/* distance slider is updated dynamically */

		/* not yet implemented: */
		wi->work[AUTO_BACK].ob_flags |= HIDETREE ;
		redisplay(wi) ;
	}
	return wi ;
}


static INT16 set_font(void *para, A_FontSel *fnt)
{
	Awindow *wi = para ;
	wi->service(wi, AS_FONT, fnt) ;

	/* return OK -> non-modal font selector does not close */
	return OK ;
}


static void font()
{
	static A_FontSel fnt = {
		0,   /* button */
		0,   /* check boxes */
		1L,  /* system font */
		0xA0000L,   /* 10 point << 16 */ 
		0x10000L    /* ratio 1L << 16 */
	} ;
	
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;

	if (!db) return ;
		
	fnt.font_id = max(db->font, 1) ;
	fnt.pt      = (INT32)db->points << 16 ;

	if (!use_wdialog)
	{
		/* ACS built-in font selector: */
		INT16 fontid = (INT16)(fnt.font_id) ;
		INT16 height = (INT16)((float)db->points * MICROMETER_PER_POINT / pixel_height + 0.5);  
		if ( OK == A_fontsel (&fontid, &height, TRUE) )
		{
			fnt.font_id = fontid ;
			/* ACS font selector uses pixel, we need point */
			fnt.pt = ((INT32)((float)height * pixel_height / MICROMETER_PER_POINT + 0.5)) << 16 ;
			fnt.button = FNTS_OK ;
			wi->service(wi, AS_FONT, &fnt) ;
		}
		return ;
	}
	
/*
#define ASH_FONT	/* fnts_... via ACS */
#define ASH_FONT_MODAL	/* window-modal */
*/
#ifdef ASH_FONT
	switch ( Ash_font(db?db->filename:"?",	-1,-1,
		FONT_FLAGS, BUTTON_FLAGS,
		&fnt, db?db->title:"?" /*the sample*/,
		"Options", /* options button label */
		(A_FontFkt)set_font, /* set function */ 
		(A_FontFkt)NULL, /* mark function */
		(A_FontFkt)NULL, /* option function */
		wi, /* params for A_FontFkt type functions */
#  ifdef ASH_FONT_MODAL
		NULL) )
#  else
		wi) )
#  endif
	{
	case 0: /* modal */
	case 1: /* window-modal */
	case 2: /* non-modal */
		wi->service(wi, AS_FONT, &fnt) ;
		break ;
	case -3: my_alert_str("[1][No fonts available!][Cancel]", NULL) ; break ;
	case -2: my_alert_str("[1][No fnts_...() functions.|Please start WDIALOG!][Cancel]", NULL) ; break ;
	default: my_alert_str("[1][Error!|Please start WDIALOG!][Cancel]", NULL) ; break ;
	}
#else	/* direct call of fnts_... functions */
	Amo_unbusy() ;
	{
		INT16 flag_3d = ((ACSblk->description->flags & AB_NO3D) != AB_NO3D) ;

		ACSblk->fonts += vst_load_fonts( ACSblk->vdi_handle, 0 );		
		
		if (!fnt_dialog) 
			fnt_dialog = fnts_create( 
				ACSblk->vdi_handle, ACSblk->fonts, FONT_FLAGS, flag_3d,
				db?db->title:"?", 0L );
		fnt.button = FNTS_SET ;
		if ( fnt_dialog )
			while ( fnt.button != FNTS_OK && fnt.button != FNTS_CANCEL )
		{
			fnt.button = fnts_do( fnt_dialog, BUTTON_FLAGS /*& ~FNTS_BSET*/, 
				fnt.font_id, fnt.pt, fnt.ratio, 
				&fnt.check_boxes, &fnt.font_id, &fnt.pt, &fnt.ratio );
			switch ( fnt.button )
			{
			case FNTS_CANCEL:
				break;
			case FNTS_SET:
			case FNTS_OK:
				wi->service(wi, AS_FONT, &fnt) ; /* modal mode only! */
				break;
			}
		}
		else form_alert( 1, "[1][Please start WDIALOG.][Cancel]" );
	}
	Amo_busy() ;
#endif
}


static void head(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	db->note_type &= ~HEAD_FLAGS ;
	
	switch (ACSblk->ev_obnr)
	{
	case HEAD_0: break ;
	case HEAD_1: db->note_type |= HEAD_LINE ; break ;
	case HEAD_2: db->note_type |= HEAD_TRI  ; break ;
	case HEAD_3: db->note_type |= HEAD_DOT  ; break ;
	}
/*	Awi_obchange(wi, HEAD, -1) ;*/
	wi->state |= AWS_LATEUPDATE ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void body(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	db->note_type &= ~BODY_FLAGS ;
	
	switch (ACSblk->ev_obnr)
	{
	case BODY_0: break ;
	case BODY_1: db->note_type |= BODY_RECT  ; break ;
	case BODY_2: db->note_type |= BODY_ELLIP ; break ;
	case BODY_3: db->note_type |= BODY_TRI   ; break ;
	}
/*	Awi_obchange(wi, BODY, -1) ;*/
	wi->state |= AWS_LATEUPDATE ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void tail(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	db->note_type &= ~TAIL_FLAGS ;
	
	switch (ACSblk->ev_obnr)
	{
	case TAIL_0: break ;
	case TAIL_1: db->note_type |= TAIL_LINE ; break ;
	case TAIL_2: db->note_type |= TAIL_TRI  ; break ;
	case TAIL_3: db->note_type |= TAIL_DOT  ; break ;
	}
/*	Awi_obchange(wi, TAIL, -1) ;*/
	wi->state |= AWS_LATEUPDATE ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void next_head(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	int old_type = db->note_type ;
	db->note_type &= ~HEAD_FLAGS ;

	switch (old_type & HEAD_FLAGS)
	{
	case 0:         db->note_type |= HEAD_LINE ; break ;
	case HEAD_LINE: db->note_type |= HEAD_TRI  ; break ;
	case HEAD_TRI:  db->note_type |= HEAD_DOT  ; break ;
	case HEAD_DOT:  db->note_type &= ~HEAD_FLAGS ; break ;
	}
	Awi_obredraw(wi, HEAD) ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void next_body(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	int old_type = db->note_type ;
	db->note_type &= ~BODY_FLAGS ;

	switch (old_type & BODY_FLAGS)
	{
	case 0:          db->note_type |= BODY_RECT  ; break ;
	case BODY_RECT:  db->note_type |= BODY_ELLIP ; break ;
	case BODY_ELLIP: db->note_type |= BODY_TRI   ; break ;
	case BODY_TRI:   db->note_type &= ~BODY_FLAGS ; break ;
	}
	Awi_obredraw(wi, BODY) ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void next_tail(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	int old_type = db->note_type ;
	db->note_type &= ~TAIL_FLAGS ;

	switch (old_type & TAIL_FLAGS)
	{
	case 0:         db->note_type |= TAIL_LINE ; break ;
	case TAIL_LINE: db->note_type |= TAIL_TRI  ; break ;
	case TAIL_TRI:  db->note_type |= TAIL_DOT  ; break ;
	case TAIL_DOT:  db->note_type &= ~TAIL_FLAGS ; break ;
	}
	Awi_obredraw(wi, TAIL) ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void scheme_popup(void)
{
	Ame_popup(ACSblk->ev_window, &SCHEME_POPUP, -1,-1) ;
}

static void scheme_drag(void)
{
	load_dragged_scheme(FALSE) ;
}


/* distinguishes the current popup, because the object
   indexes in the 3 different popups are the same */
static enum {_NONE, _HEAD, _BODY, _TAIL } head_body_tail ;

static void head_popup(void)
{
	head_body_tail = _HEAD ;
	Ame_popup(ACSblk->ev_window, &HEAD_POPUP, -1,-1) ;
	head_body_tail = _NONE ;
}

static void body_popup(void)
{
	head_body_tail = _BODY ;
	Ame_popup(ACSblk->ev_window, &BODY_POPUP, -1,-1) ;
	head_body_tail = _NONE ;
}

static void tail_popup(void)
{
	head_body_tail = _TAIL ;
	Ame_popup(ACSblk->ev_window, &TAIL_POPUP, -1,-1) ;
	head_body_tail = _NONE ;
}


static void select_scheme(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	if (!db) return ;
	    
	if ( db->scheme_path[0] ) 
		strcpy(textbuff, db->scheme_path) ;
	else
		/* init path */
		sprintf(textbuff, "%s%s", ACSblk->apppath, "SCHEMES\\") ;
   	if ( Af_select("Select scheme", textbuff, scheme_file_extension) )
   	{
		do_load_scheme(db, textbuff) ;
		update_scheme_text(wi) ;
		Awi_obredraw(wi, SCHEME) ;
		Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
    }
}


static void edit_scheme(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	if (!db) return ;

	SCHMEDIT_WINDOW.create(db->scheme_path) ;
}


static int cdecl scheme_draw(PARMBLK *parmblk) 
{
	PARAMS_DB *db = (PARAMS_DB *)parmblk->pb_parm ;
	int dots = -1 /* no dots */ ; 
	int mark_mode = behind ;
	int handle = (int)xhandle ;
	
	if (!handle || !db || ACSblk->appexit) 
		return (parmblk->pb_currstate) ; 
	
	vs_clip_from_parmblk(handle, parmblk) ;

	if      (db->mode == Rieder) mark_mode = between ;
	else if (db->mode == Beyreuther)
		dots = 4 ;

	draw_scheme(xhandle, &(db->scheme), db->transpose,
		parmblk->pb_x, parmblk->pb_y, parmblk->pb_w, parmblk->pb_h,
		5 /* dodecime index */,
		db->horizontal_lines, dots, mark_mode,
		db->note_type,
		TRUE) ;

	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}



static int cdecl note_draw(PARMBLK *parmblk) 
{
	PARAMS_DB *db = (PARAMS_DB *)parmblk->pb_parm ; 
	INT16 points[4] ;
	int type = 0 ;
	int handle = (int)xhandle ;

	/* the popups the handle and not the db */
	if (!handle || ACSblk->appexit) 
		return (parmblk->pb_currstate) ; 
	
	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	points[0] = parmblk->pb_x ;	
	points[1] = parmblk->pb_y ;	
	points[2] = parmblk->pb_x + parmblk->pb_w - 1 ;	
	points[3] = parmblk->pb_y + parmblk->pb_h - 1 ;	

	vsl_width(handle, 1) ;

	if (ACSblk->ncolors < 16)
	{
		/* white background */
		/* on screen (not on printer) there is always a palette */
		/* we do not need the RGB functions here */
		vsf_color(handle, WHITE) ;
		vsf_interior(handle, FIS_SOLID) ;
		vsf_perimeter(handle, FALSE) ;
		v_bar(handle, points) ;
	}
	/* the note ends may be twice as high as the body */
	points[1] += (parmblk->pb_h >> 2) ;	
	points[3] -= (parmblk->pb_h >> 2) ;	

	/* draw corresponding note */
	switch (head_body_tail)
	{
	/* draw current selection */
	case _NONE:
		if (!db)
			return (parmblk->pb_currstate) ; /* and these need also the database */
		switch(parmblk->pb_obj)
		{
		case HEAD: type = db->note_type & HEAD_FLAGS ; break ;
		case BODY: type = db->note_type & BODY_FLAGS ; break ;
		case TAIL: type = db->note_type & TAIL_FLAGS ; break ;
		}
		break ;

	/* offer for new selection */
	case _HEAD:
		switch(parmblk->pb_obj)
		{
		case HEAD_0: break ;
		case HEAD_1: type = HEAD_LINE ; break ;
		case HEAD_2: type = HEAD_TRI  ; break ;
		case HEAD_3: type = HEAD_DOT  ; break ;
		}
		break ;
		
	case _BODY:
		switch(parmblk->pb_obj)
		{
		case BODY_0: break ;
		case BODY_1: type = BODY_RECT  ; break ;
		case BODY_2: type = BODY_ELLIP ; break ;
		case BODY_3: type = BODY_TRI   ; break ;
		}
		break ;
		
	case _TAIL:
		switch(parmblk->pb_obj)
		{
		case TAIL_0: break ;
		case TAIL_1: type = TAIL_LINE ; break ;
		case TAIL_2: type = TAIL_TRI  ; break ;
		case TAIL_3: type = TAIL_DOT  ; break ;
		}
		break ;
	}
	if (type & HEAD_FLAGS)
	{
		/* shift to the right */
	    points[0] += (points[3]-points[1]) ;
	    points[2] += (points[3]-points[1]) ;
	}
	else if (type & TAIL_FLAGS)
	{
		/* shift to the left */
	    points[0] -= (points[3]-points[1]) ;
	    points[2] -= (points[3]-points[1]) ;
	}
	else if (type & BODY_FLAGS)
	{
	    points[0] += (points[3]-points[1]) ;
	    points[2] -= (points[3]-points[1]) ;
	}
	/* solid black notes */
	draw_note(xhandle, points, type, 8,BLACK,8,BLACK) ;

	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}


static void effects(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	switch (ACSblk->ev_obnr)
	{
		case _BOLD:       db->effects ^= TF_THICKENED  ; break ;
		case _ITALIC:     db->effects ^= TF_SLANTED    ; break ;
		case _UNDERLINED: db->effects ^= TF_UNDERLINED ; break ;
	}
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void borders(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	if (ACSblk->ev_object[ACSblk->ev_obnr].ob_state & SELECTED)
		db->note_type &= ~BORDERS_NONE ;
	else
		db->note_type |= BORDERS_NONE ;

	update_3d_checkbox(wi) ;

	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void _3d(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	if (ACSblk->ev_object[ACSblk->ev_obnr].ob_state & SELECTED)
		db->note_type |= BORDERS_3D ;
	else
		db->note_type &= ~BORDERS_3D ;

	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static void auto_back(void)
{
	/* automatic background coloring not yet implemented */
}


static void borders_cycle(void)
{
	Aus_cycle();
	messages = FALSE ;
	update_border_sliders(ACSblk->ev_window) ;
	messages = TRUE ;
}

static void distance_cycle(void)
{
	Aus_cycle();
	messages = FALSE ;
	update_distance_slider(ACSblk->ev_window) ;
	messages = TRUE ;
}

static void inventor(void)
{
	char *s ;
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;

	Aus_cycle();
	if (!db) return ;
	
	Auo_cycle(wi->work + INVENTOR, AUO_GETVAL, &s) ;
	switch (s[0])
	{
		case 'B': db->mode = Beyreuther ; break ;
		case 'M': db->mode = Mix        ; break ;
		default : db->mode = Rieder ;
	}
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}

static void lines(void)
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	Aus_cycle();
	if (!db) return ;
	
	Aob_scanf(wi->work, LINES, "%d", &(db->horizontal_lines)) ; 
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}

static void lines_attr(void)
	/* click procedure to set line widths */
{
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	char *current, *s ;
	
	switch (ACSblk->ev_obnr)
	{
	case BARS_ATTR:     s = db->bar_line_width     ; break ;
	case SUB_BARS_ATTR: s = db->sub_bar_line_width ; break ;
	case NOTES_ATTR:    s = db->note_line_width    ; break ;
	default:            s = db->line_width         ;
	}
	current = strstr(LINE_WIDTHS, s) ;
	if (current == NULL)
		current = LINE_WIDTHS ;

	current = Ame_strpopup(ACSblk->ev_window, LINE_WIDTHS, current, 
		ACSblk->gl_wbox * 9, -1,-1) ;

	if (current == NULL)
		return ;

	strncpy(s, current, LINE_WIDTH_STRLEN) ;
	s[LINE_WIDTH_STRLEN] = 0 ; 
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}

static void transpose(void)
{
	char *s ;
	Awindow *wi = ACSblk->ev_window ;
	PARAMS_DB *db = wi->user ;
	
	Aus_cycle();
	if (!db) return ;
	
	Auo_cycle(wi->work + TRANSPOSE, AUO_GETVAL, &s) ;
	if (s[0] >= '0' && s[0] <= '9')
		db->transpose = s[0] - '0' ;
	else
		db->transpose = s[0] - 'A' + 10 ;
	Awi_obchange(wi, SCHEME, -1) ;
	Awi_sendall(DATA_CHANGED_BUTTON, NULL) ;
}


static INT16 keys(
	Awindow *wi,	/* input: parameters window */
	INT16 kstate, 	/* input: see ACS manual */
	INT16 key		/* input: ASCII code and scan code */
)
{
	PARAMS_DB *db = wi->user ;
	/* forward event to ACS for further treatment (e.g. by the title boxedit) */
	INT16 rc = Awi_keys(wi, kstate, key) ;
	if (db) 
	{
		Aob_gettext(wi->work, TITLE, db->title) ;
		Awi_sendall(DATA_CHANGED_KEY, NULL) ;
	}
	return rc ;
}


#endif /* PURE C */