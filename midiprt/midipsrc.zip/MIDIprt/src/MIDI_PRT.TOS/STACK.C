/**************************************************************
*
*                STACK.C
*
**************************************************************/

#include <stddef.h>
#include "stack.h"

static void * stack[STACK_SIZE] ;


static int get_index(void *ptr)
{
	int i ;
	for (i = 0 ; i < STACK_SIZE ; i++)
		if (stack[i] == ptr)
			return i ;
	return -1 ;
}


void remove_from_stack(void *ptr)
{
	int i = get_index( ptr ) ;
	if (i >= 0)
	{
		stack[i] = NULL ;
		i++ ;
		while (i < STACK_SIZE)
		{
			stack[i-1] = stack[i] ;
			stack[i] = NULL ;
			i++ ;
		}
	}
}


void push_on_stack(void *ptr)
{
	int i = get_index(ptr) ;
	if (i >= 0)
	{
		/* is already on stack, remove first */
		remove_from_stack( ptr ) ;
	}
	/* add to the end */
	for (i = STACK_SIZE - 1 ; i >= 0 ; i--)
	{
		if (stack[i] == NULL)
		{
			stack[i] = ptr ;
			return ;
		}
	}
	/* stack overflow, throw out lowest entry */
	remove_from_stack( stack[0] ) ;
	stack[STACK_SIZE - 1] = ptr ;
}


void *get_top_pointer()
{
  int i  ;
  for (i = STACK_SIZE - 1 ; i >= 0 ; i--)
  {
  	if (stack[i] != NULL)
  		return stack[i] ;
  }
  return NULL ;	/* nothing on stack */
}
