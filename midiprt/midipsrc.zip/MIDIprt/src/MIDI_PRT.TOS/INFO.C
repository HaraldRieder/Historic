/**************************************************************
*
*                INFO.C
*
**************************************************************/

#include <acs.h>
#include <acsplus.h>
#include <string.h>
#include <stdlib.h>
#include <acs_plus.h>
#include "messages.h"
#include "info.hpp"
#include "info.h"
#include "info.ah"


static INT16 keys(Awindow *wi, int kstate, int key)
{
	return Awi_keys(wi, kstate, key) ;
}

static void redisplay(Awindow *wi)
{
	INFO_DB *db = wi->user ;
	int ob_state = 0 ;

	/* fast exit */
	if (ACSblk->appexit) return ;
	
	/* test only */
	/*if (!db->copyright)
		db->copyright = strdup("Test copyright text.") ;*/
	
	Awi_setinfo(wi, db?db->filename:"?") ;

	if (!db)
		ob_state |= DISABLED ; /* for all together */

	wi->work[TRANSFORMED_SIZE].ob_state = 
	wi->work[FILE_SIZE       ].ob_state = 
	wi->work[MIDI_FILE_TYPE  ].ob_state = 
	wi->work[NUMBER_OF_TRACKS].ob_state = 
	wi->work[SMPTE           ].ob_state = 
	wi->work[TICKS_PER_FRAME ].ob_state = 
	wi->work[TICKS_PER_BEAT  ].ob_state = 
	wi->work[TEMPO           ].ob_state = 
	wi->work[KEY             ].ob_state = 
	wi->work[TIME            ].ob_state = 
	wi->work[COPYRIGHT_NOTICE].ob_state = ob_state ;
	
	if (db)
	{
		Aob_printf(wi->work, TRANSFORMED_SIZE, "%li", db->transformed_size >> 10 /* in units of 1024 Byte */) ;
		Aob_printf(wi->work, FILE_SIZE       , "%li", db->filesize >> 10 /* in units of 1024 Byte */) ;
		Aob_printf(wi->work, MIDI_FILE_TYPE  , "%i", db->midi_header.midi_file_type) ;
		Aob_printf(wi->work, NUMBER_OF_TRACKS, "%i", db->midi_header.number_tracks) ;
		
		if (db->midi_header.smpte > 0)
		{
			/* SMPTE format */
			wi->work[TICKS_PER_BEAT].ob_state |= DISABLED ;
			Aob_printf(wi->work, SMPTE          , "%i", db->midi_header.smpte) ;
			Aob_printf(wi->work, TICKS_PER_FRAME, "%i", db->midi_header.ticks_per_frame) ;
		}
		else 
		{
			/* non-SMPTE format */
			wi->work[SMPTE          ].ob_state |= DISABLED ;
			wi->work[TICKS_PER_FRAME].ob_state |= DISABLED ;
			Aob_printf(wi->work, TICKS_PER_BEAT, "%i", db->midi_header.ticks_per_beat) ;
		}
		
		if (db->tempo[0] == 0)
		     wi->work[TEMPO].ob_state |= DISABLED ;
		else wi->work[TEMPO].ob_state &= ~DISABLED ;
		if (db->key[0] == 0)
		     wi->work[KEY].ob_state |= DISABLED ;
		else wi->work[KEY].ob_state &= ~DISABLED ;
		if (db->time[0] == 0)
		     wi->work[TIME].ob_state |= DISABLED ;
		else wi->work[TIME].ob_state &= ~DISABLED ;
		
		Aob_puttext(wi->work, TEMPO, db->tempo) ;
		Aob_puttext(wi->work, KEY  , db->key  ) ;
		Aob_puttext(wi->work, TIME , db->time ) ;

		if (db->copyright == NULL)
		{
			wi->work[COPYRIGHT_NOTICE].ob_state |= DISABLED ;
			wi->work[COPYRIGHT_NOTICE].ob_flags &= ~DEFAULT ;
		}
		else 
		{
			wi->work[COPYRIGHT_NOTICE].ob_state &= ~DISABLED ;
			wi->work[COPYRIGHT_NOTICE].ob_flags |= DEFAULT ;
		}
	}
	Awi_obchange(wi, TRANSFORMED_SIZE, -1) ;
	Awi_obchange(wi, FILE_SIZE       , -1) ;
	Awi_obchange(wi, MIDI_FILE_TYPE  , -1) ;
	Awi_obchange(wi, NUMBER_OF_TRACKS, -1) ;
	Awi_obchange(wi, SMPTE           , -1) ;
	Awi_obchange(wi, TICKS_PER_FRAME , -1) ;
	Awi_obchange(wi, TICKS_PER_BEAT  , -1) ;
	Awi_obchange(wi, TEMPO           , -1) ;
	Awi_obchange(wi, KEY             , -1) ;
	Awi_obchange(wi, TIME            , -1) ;
	Awi_obchange(wi, COPYRIGHT_NOTICE, -1) ;
}

static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	switch (task)
	{	
		case AS_TERM: 
			if (ACSblk->appexit)
				Awi_delete(wi) ; 
			break ; 
		case AS_INFO: 
/*			A_dialog(&INFO_INFO) ;
			Awi_dialog(&INFO_INFO_WINDOW) ; */
			break ;
		case SET_DATABASE:
			if (wi->user != in_out)
				/* redisplay with new database */
				service(wi, DATA_CHANGED, in_out) ;
			break ;
		case INVALIDATE_DATABASE:
			if (wi->user == in_out)
				/* this is my database, it shall become invalid */
				service(wi, SET_DATABASE, NULL) ;
			break ;
		case DATA_CHANGED:
			wi->user = in_out ;
			redisplay(wi) ;
			break ;
		default: return FALSE ;
	}
	return TRUE ;	/* task has been treated */
}


static Awindow *create (void *parent)
{
	Awindow *wi = Awi_create(parent) ;
	if (wi)
		redisplay(wi) ;
	return wi ;
}


static void copyright_notice(void)
{
	/* somebody clicked on the button => show in editor */
	static Awindow *wi ;
	INFO_DB *db = ACSblk->ev_window->user ;

	if (wi)
		/* destroy previous copyright window */
		wi->service(wi, AS_TERM, NULL) ;
		
	wi = EDITOR.create(NULL) ;
	if (wi)
	{
		wi->kind &= ~AW_GHOSTICON ;
		wi->service(wi, AS_EDICONTEXT, "Copyright") ;
		wi->service(wi, AS_EDPUTSTRING, db->copyright) ;
		wi->open(wi) ;
	}
}

