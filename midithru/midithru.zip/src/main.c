/*
 Copyright (c) 2002, Harald Rieder, Stuttgart, Germany
 All rights reserved.
*/
#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS
#include <BuildDefines.h>
#ifdef DEBUG_BUILD
#define ERROR_CHECK_LEVEL ERROR_CHECK_FULL
#endif
#include <PalmOS.h>
// new serial manager exists from OS version 3.3 on 
#include <SerialMgrOld.h>
#include "resource.h"
#include "palmutil.h"
#include "midi.h"

// The minimum OS version we support
#define OUR_MIN_VERSION	sysMakeROMVersion(3,0,0,sysROMStageRelease,0)

#define MIDI_BAUD_RATE 31250	    // MIDI speed

static UInt32 ticks_per_second ;  // Palm OS ticks per second

/* =================== timer =========================== */

#define TIMEOUT 500 // milli seconds

static Boolean timer_is_running = false ;
static Int32 start_time ; // in ticks ;
static Int32 timeout ;    // in ticks ;

static Boolean timer_is_expired()
{
  Int32 now = TimGetTicks() ;
  if (timeout)
  {
    // timer is running
    if (now - timeout >= start_time)
    {
      // expired => retrigger timer
      start_time = now ;
      return true ;
    }
    return false ;
  }
  // not yet started
  timeout = (ticks_per_second * TIMEOUT) / 1000 ;
  start_time = now ;
  return false ;
}

static void stop_timer() { timeout = 0 ; }

/* =================== serial =========================== */

UInt16 port_id ;  // handle to our serial interface 
Err recv_error ;  
Err send_error ;  

static UInt16 port_is_open = false ;

static void close_serial(FormPtr form)
{
  if (port_is_open)
  {
    /* restore the default buffer before closing the 
       serial port */
    /*DoSetReceiveBuffer(port_id, NULL, 0) ;*/
    SerClearErr(port_id) ;
    SerClose(port_id) ;
    port_is_open = false ;
  }
  recv_error = errNone ;
  send_error = errNone ;
  if (form)
  {
    FrmHideObject(form, FrmGetObjectIndex(form, RECV_ERROR)) ;
    FrmHideObject(form, FrmGetObjectIndex(form, SEND_ERROR)) ;
  }
}


static Err open_serial(UInt32 baud_rate, FormPtr form)
{
  Err err ;
  close_serial(form) ;

  //err = SrmOpen(serPortCradleRS232Port, baud_rate, &port_id) ;
	err = SysLibFind("Serial Library", &port_id);
	if (err)
  {
    SysFatalAlert("Could not open 'Serial Libary'!") ;
    return err ;
  }
	err = SerOpen(port_id, 0, baud_rate);
  if (err == serErrAlreadyOpen)
    FrmAlert(SERIAL_IN_USE_ALERT) ;
  else if (err)
    FrmAlert(CANT_OPEN_SERIAL_ALERT) ;
  else
    port_is_open = true ;
  return err ;
}

/* ============== database ================= */

#define DB_NAME "MIDI Through DB" 

typedef struct
{
  Int16 baud_rate ;  // only the index into the list
  Boolean monitor ;  // whether monitor shall be visible
} 
Database ;
Database db ;
DmOpenRef db_ref ;

Err close_DB(void)
{
  Err err = errNone ;
  if (db_ref)
  {
    err = DmCloseDatabase(db_ref) ;
    db_ref = 0 ;
  }
  return err ;
}

Err open_DB(UInt16 mode)
{
  Err err = errNone ;

  if (db_ref)
    // already open
    return errNone ;

  // Find my database. If it doesn't exist, create it.

  db_ref = DmOpenDatabaseByTypeCreator('DATA', CREATOR_ID, mode) ;
  if (!db_ref)
  {
    err = DmGetLastErr() ;
    if (err == dmErrCantFind)
    {
      err = DmCreateDatabase(0, DB_NAME, CREATOR_ID, 'DATA', false) ;
      if (err == errNone || err == dmErrAlreadyExists)
      {
        db_ref = DmOpenDatabaseByTypeCreator('DATA', CREATOR_ID, mode) ;
        if (!db_ref)
          err = DmGetLastErr() ;
        else
          err = errNone ;
      }
    }
  }
  return err ;
}


/* ============================================== */

static Char text_buffer[MONITOR_MAXCHARS+1] ; // +1 for the 0-termination


static Char byte_to_char(UInt8 byte) 
{
  static Char c[] = "0123456789abcdef" ;
  if (byte < sizeof(c))
    return c[byte] ;
  return '?' ;
}


/* ============= main form ================= */

static void update_monitor_visibility(FormPtr form) 
{
  if (db.monitor)
  {
    FrmShowObject(form, FrmGetObjectIndex(form, MONITOR)) ;
    FrmShowObject(form, FrmGetObjectIndex(form, RECV_LABEL)) ;
  }
  else
  {
    FrmHideObject(form, FrmGetObjectIndex(form, MONITOR)) ;
    FrmHideObject(form, FrmGetObjectIndex(form, RECV_LABEL)) ;
  }
}


static 
void MainFormInit(FormPtr form)
{
#pragma unused(form)
  // warning-- don't do any drawing in this routine.
  // Also, don't call FrmSetFocus from here (it must be called *after*
  // FrmDrawForm)
}


static 
void MainFormDeinit(FormPtr form)
{
#pragma unused(form)
}

#define FIRST_NOTE (12 * 5)
#define MIDI_CHANNELS 16
static UBYTE channel = MIDI_CHANNELS ;
char channel_text[] = "Ch. 0" ; // start with current channel 0

Boolean MainFormHandleEvent(EventPtr event)
{
  static UInt8 byte = '0' ;
  UInt8 i ;
  FormPtr form = FrmGetActiveForm();
  FieldPtr field ;
  Err err ;

  switch (event->eType) 
  {
  case frmOpenEvent:
    MainFormInit(form);
    FrmDrawForm(form);
    // here's where you'd add a call to FrmSetFocus
    {
      // set baud rate according to stored setting
      Char *text ;
      ListPtr list = get_object( form, BAUD_RATE_LIST ) ;
      LstSetSelection(list, db.baud_rate) ;
      {
        ControlPtr popup = get_object( form, BAUD_RATE_TRIGGER ) ;
        Char *text = LstGetSelectionText(list, db.baud_rate) ;
        if (text)
        {
          CtlSetLabel(popup, text) ;
          if (text[0] == 'M')
            open_serial( MIDI_BAUD_RATE,  NULL ) ;
          else
            open_serial( StrAToI(text), NULL ) ;
        }
      }
      // set monitor visibility according to stored setting
      {
        CtlSetValue(get_object(form, MONITOR_CHECKBOX), db.monitor) ;
        update_monitor_visibility(form) ;
      }
    }
    return true ;
      
  case frmCloseEvent:
    MainFormDeinit(form);
    return false;

  case menuEvent:
    switch (event->data.menu.itemID)
    {
    case ABOUT_ME:
      FrmAlert(ABOUT_ME_ALERT) ;
      return true ;
    }
    return false ;

  case popSelectEvent:
    // active form seems to be the popup list here ?!?
    {
      Char *text = LstGetSelectionText(
        event->data.popSelect.listP, 
        event->data.popSelect.selection) ;
      if (text != NULL)
      {
        db.baud_rate = event->data.popSelect.selection ;
        if (text[0] == 'M')
          open_serial( MIDI_BAUD_RATE, form ) ;
        else
          open_serial( StrAToI(text), form ) ;
        // erase received data display
/*        text_buffer[0] = 0 ;
        field = get_object_from_active(RECV_FIELD) ;
        set_field_text(field, text_buffer, true) ;*/
        MemSet(text_buffer, MONITOR_MAXCHARS, ' ') ;
        text_buffer[MONITOR_MAXCHARS] = 0 ;
        FrmCopyLabel(form, MONITOR, text_buffer) ;
      }
      else
        SysFatalAlert("Could not get text from baud rate list!") ;
    }
    return false ;  // Palm OS shall update trigger text

  case ctlSelectEvent:
    switch (event->data.ctlSelect.controlID) 
    {
    case SEND_TEST_BUTTON:
      channel = 0 ; // start playing the sequence
      note_on (channel, FIRST_NOTE, MEAN_DYNAMIC) ;
      if (send_error != errNone)
      {
        // abort
        FrmShowObject(form, FrmGetObjectIndex(form, SEND_ERROR)) ;
        channel = MIDI_CHANNELS ;
      }
      else
      {
        channel_text[4] = byte_to_char(channel) ;
        FrmCopyLabel(form, CHANNEL_INDICATOR, channel_text) ;
        FrmShowObject(form, FrmGetObjectIndex(form, CHANNEL_INDICATOR)) ;
      }
      return true ;

    case MONITOR_CHECKBOX:
      db.monitor = event->data.ctlSelect.on ;
      update_monitor_visibility(form) ;
      return true ;
    }
    break;

  case nilEvent:
    if (channel < MIDI_CHANNELS)
    {
      // test sequence is running
      if (timer_is_expired())
      {
        // play next note
        note_off(channel, FIRST_NOTE + channel, MEAN_DYNAMIC) ;
        channel++ ;
        if (channel < MIDI_CHANNELS)
        {
          channel_text[4] = byte_to_char(channel) ;
          FrmCopyLabel(form, CHANNEL_INDICATOR, channel_text) ;
          note_on (channel, FIRST_NOTE + channel, MEAN_DYNAMIC) ;
        }
        else 
        {
          stop_timer() ;
          FrmHideObject(form, FrmGetObjectIndex(form, CHANNEL_INDICATOR)) ;
        }
      }
    }

    if (recv_error)
      // do nothing until the error gets cleared
      return true ;
    //SndPlaySystemSound(sndWarning); // test whether called often enough

    // prepare (erase) text buffer
    i = 0 ;
    MemSet(text_buffer, MONITOR_MAXCHARS, ' ') ;
    text_buffer[MONITOR_MAXCHARS] = 0 ;
    do
    {
      if (midi_data_available && recv_error == errNone)
      {
        UInt8 byte = midi_in ;

        // as long as data is received, avoid automatic power-off
        EvtResetAutoOffTimer() ;

        if (recv_error)
          FrmShowObject(form, FrmGetObjectIndex(form, RECV_ERROR)) ;
        else
        {
//          const Char * field_text ;
          // convert byte to 2 hex digits + space char
          // and append to field text
/*          field = get_object_from_active(RECV_FIELD) ;
          if ( field_text = FldGetTextPtr(field) )
            StrCopy(text_buffer, field_text);*/
          // erase old content
          if (i+3 < sizeof(text_buffer))
          {
            text_buffer[i++] = byte_to_char((byte >> 4) & 0xF) ; 
            text_buffer[i++] = byte_to_char(byte & 0xF) ; 
            i++ ; // 1 blank as separator
          }
          // the MIDI through function:
          midi_out(byte) ;
          if (send_error != errNone)
          {
            FrmShowObject(form, FrmGetObjectIndex(form, SEND_ERROR)) ;
            send_error = errNone ;
          }
        }
      }
      else if (recv_error != serErrTimeOut)
        FrmShowObject(form, FrmGetObjectIndex(form, RECV_ERROR)) ;
    } 
    while (recv_error == errNone) ;
    recv_error = errNone ; // possible timeout is no error 

    // now show the bytes received in the loop
    if (i > 0)
      FrmCopyLabel(form, MONITOR, text_buffer) ;
    return true ;
  }  
  return false ;
}


/* =============== application ================== */

static Boolean AppHandleEvent(EventPtr event)
{
  UInt16 formId;
  FormPtr form;

  if (event->eType == frmLoadEvent) 
  {
    // Load the form resource.
    formId = event->data.frmLoad.formID;
    form = FrmInitForm(formId);
    ErrFatalDisplayIf(!form, "Can't initialize form");
    FrmSetActiveForm(form);

    // Set the event handler for the form.  The handler of the currently
    // active form is called by FrmHandleEvent each time is receives an
    // event.
    switch (formId) 
    {
    case MAIN_FORM:
      FrmSetEventHandler(form, MainFormHandleEvent);
      break;

    default:
      ErrFatalDisplay("Invalid Form Load Event");
      break;

    }
    return true;
  } 
  else 
    return false;
}


static void AppEventLoop(void)
{
  Err error;
  EventType event;

  do 
  {
    EvtGetEvent(&event, 0 /*evtWaitForever*/);
    
    if (! SysHandleEvent(&event))
      if (! MenuHandleEvent(0, &event, &error))
        if (! AppHandleEvent(&event))
          FrmDispatchEvent(&event);
  }
  while (event.eType != appStopEvent);
}



static Err AppStart(void)
{
  /* O'Reilly Palm OS Programming 2nd editidion page 426 */
  /* we need only default serial port for MIDI 
     => use backward comptible old serial manager */
  ticks_per_second = SysTicksPerSecond() ;

  if (open_DB(dmModeReadWrite) == errNone)
  {
    // read data 
    UInt16 index = 0 ;
    MemHandle record = DmQueryRecord(db_ref, index) ;
    if (record)
    {
      Database *dbPtr = (Database *)MemHandleLock(record) ;
      db = *dbPtr ;
      MemHandleUnlock(record) ;
    }
    if (close_DB() != errNone)
      ErrFatalDisplay("Can't close database '"DB_NAME"'!");
  }
  else ErrFatalDisplay("Can't open database '"DB_NAME"'!");

  return  ;
}


static void AppStop(void)
{
  close_serial(NULL) ;

  if (open_DB(dmModeReadWrite) == errNone)
  {
    // update data 
    UInt16 index = 0 ;
    Boolean changed = false ;
    MemHandle record = DmQueryRecord(db_ref, index) ;
    if (record)
    {
      // exists already, reserve it for writing
      // the record may be from an older version with different size
      record = DmResizeRecord(db_ref, index, sizeof(db)) ;
      //record = DmGetRecord(db_ref, index) ;
    }
    if (!record)
    {
      // create our single record
      record = DmNewRecord(db_ref, &index, sizeof(db)) ;
    }

    // consistency check: we always shoud have one single record
    ErrFatalDisplayIf(index != 0, "Record index != 0 in database '"DB_NAME"'!") ;

    if (record)
    {
      Database *dbPtr = (Database *)MemHandleLock(record) ;
      if ( MemCmp(dbPtr, &db, sizeof(db)) )
      {
        // data has changed, should be backed up during next hotsync
        changed = true ;
        if (DmWrite(dbPtr, 0, &db, sizeof(db)) != errNone)
          ErrFatalDisplay("Can't write record to database '"DB_NAME"'!") ;
      }
      MemHandleUnlock(record) ;
      DmReleaseRecord(db_ref, 0, changed) ;
    }
    else
      ErrFatalDisplay("Can't create record in database '"DB_NAME"'!") ;
  }
  else
    ErrFatalDisplay("Can't open database '"DB_NAME"'!");

  FrmCloseAllForms();
}



UInt32 PilotMain(UInt16 launchCode, MemPtr launchParameters, 
  UInt16 launchFlags)
{
#pragma unused(launchParameters)
  Err error;

  switch (launchCode)
  {
  case sysAppLaunchCmdNormalLaunch:
    if (error = rom_version_compatible(OUR_MIN_VERSION, launchFlags))
      return error ;
    if (error = AppStart()) 
      return error;
      
    FrmGotoForm(MAIN_FORM);
    AppEventLoop();
    AppStop();
    break;
  }
  return errNone;
}


