2002 November

This project will work with:
	
	PRC-Tools--Windows (PRC-tools 2.1 pre-3)
	PRC-Tools--Unix (PRC-tools 2.1 pre-3)
	
It requires:
	Palm OS 4.0 SDK
	
===================================

Harald.Rieder@imail.de

===================================
