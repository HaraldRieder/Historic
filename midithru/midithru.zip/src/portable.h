#ifndef INC_PORTABLE
#define INC_PORTABLE

#if defined (__PUREC__)
#	include <acstype.h>
	typedef unsigned char UBYTE ;
#elif defined (__PALM__)
#include <PalmOS.h>
#	ifndef INT32 
		typedef Int32 INT32 ;
#	endif
#	ifndef UINT32 
		typedef UInt32 UINT32 ;
#	endif
#	ifndef INT16
		typedef Int16 INT16 ;
#	endif
#	ifndef UINT16
		typedef UInt16 UINT16 ;
#	endif
#	ifndef UBYTE
		typedef UInt8 UBYTE ;
#	endif

#define strchr   StrChr
#define strlen   StrLen
#define strcpy   StrCopy
#define memcpy   MemMove
#define memmove  MemMove
#define memset(dest,character,N) MemSet(dest,N,character)

static Boolean isxdigit(Char c)
{
  if (c >= 'a' && c <= 'f')
    return true ;
  if (c >= 'A' && c <= 'F')
    return true ;
  if (c >= '0' && c <= '9')
    return true ;
  return false ;
}

static Char *strpbrk(const Char *src, const Char *breaks)
{
  UInt16 len = StrLen(breaks) ;
  UInt16 i ;
  for (i = 0 ; i < len ; i++)
  {
    Char *found_here = StrChr(src, breaks[i]) ;
    if (found_here)
      return found_here ;
  }
  return NULL ;
}

#else // Windoofs
#	ifndef INT32 
		typedef __int32 INT32 ;
#	endif
#	ifndef UINT32 
		typedef unsigned __int32 UINT32 ;
#	endif
#	ifndef INT16
		typedef __int16 INT16 ;
#	endif
#	ifndef UINT16
		typedef unsigned __int16 UINT16 ;
#	endif
#	ifndef UBYTE
		typedef unsigned char UBYTE ;
#	endif 	
#endif

#endif