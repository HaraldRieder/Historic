#ifndef CONSTANTS_H
#define CONSTANTS_H

#define CREATOR_ID				  'THRU'

// The minimum OS version we support
#define kOurMinVersion	sysMakeROMVersion(3,0,0,sysROMStageRelease,0)
#endif