#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS
#include <BuildDefines.h>
#ifdef DEBUG_BUILD
#define ERROR_CHECK_LEVEL ERROR_CHECK_FULL
#endif
#include <PalmOS.h>
#include "palmutil.h"
#include "resource.h"



Err rom_version_compatible(UInt32 requiredVersion, UInt16 launchFlags)
{
  UInt32 romVersion;

  // See if we're on in minimum required version of the ROM or later.
  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
  if (romVersion < requiredVersion) 
  {
    UInt16 safeToCallAlertFlags;
    
    safeToCallAlertFlags = sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp;
    if ((launchFlags & (safeToCallAlertFlags)) == safeToCallAlertFlags) 
    {
      FrmAlert (ROM_INCOMPATIBLE_ALERT);
    
      // Pilot 1.0 will continuously relaunch this app unless we switch to 
      // another safe one.
      if (romVersion < sysMakeROMVersion(2,0,0,sysROMStageRelease,0))
        AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
    }
    return sysErrRomIncompatible;
  }
  return errNone;
}


void *get_object(FormPtr form, UInt16 object_ID)
{ return FrmGetObjectPtr(form, FrmGetObjectIndex(form, object_ID)); }

void *get_object_from_active(UInt16 object_ID)
{ return get_object(FrmGetActiveForm(), object_ID); }


Err set_field_text(FieldPtr field, Char *s, Boolean redraw)
{
   MemHandle h = FldGetTextHandle(field);
   if (h) 
   {
     Err	err;
     
     FldSetTextHandle(field, NULL);
     err = MemHandleResize(h, StrLen(s) + 1);
     if (err) {
       FldSetTextHandle(field, h);  // restore handle
       return err;
     }
   } 
   else 
   {
     h = MemHandleNew(StrLen(s) + 1);
     if (!h)
       return memErrNotEnoughSpace;
   }
   // at this point, we have a handle of the correct size

   // copy the string to the locked handle.
   StrCopy((Char *) MemHandleLock(h), s);
   // unlock the string handle.
   MemHandleUnlock(h);
   
   FldSetTextHandle(field, h);
   if (redraw)
   	 FldDrawField(field);
   return errNone;
} 
