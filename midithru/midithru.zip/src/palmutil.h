#ifndef PALMUTIL_H
#define PALMUTIL_H

Err rom_version_compatible(UInt32 required_version, UInt16 launch_flags);
void *get_object(FormPtr form, UInt16 object_ID);
void *get_object_from_active(UInt16 object_ID);
Err set_field_text(FieldPtr field, Char *s, Boolean redraw);

#endif
