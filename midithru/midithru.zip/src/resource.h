#define CREATOR_ID                   'THRU'

#define ROM_INCOMPATIBLE_ALERT        1001

#define SERIAL_IN_USE_ALERT           1100
#define CANT_OPEN_SERIAL_ALERT        1200
#define ABOUT_ME_ALERT                1300
#define HELP_STRING                   1301

#define MAIN_FORM                     2000	
#define BAUD_RATE_LIST                2010
#define BAUD_RATE_TRIGGER             2011
#define SEND_TEST_BUTTON              2020
#define SEND_ERROR                    2021
#define CHANNEL_INDICATOR             2022
#define RECV_LABEL                    2031
#define MONITOR                       2032
#define MONITOR_MAXCHARS                30
#define MONITOR_CHECKBOX              2033
#define RECV_ERROR                    2034

#define MAIN_MENU                     3000
#define ABOUT_ME                      3001
#define HELP                          3002
