2003 June

This project will work with:
	
	PRC-Tools--Windows (PRC-tools 2.1 pre-3)
	PRC-Tools--Unix (PRC-tools 2.1 pre-3)
	
It requires:
	Palm OS 4.0 SDK

Microsoft Visiual C++ is too stupid to preserve file names:
I use it as editor, since I have a license. But after modifiying
a file e.g. EVENTHDL.C, the stupid tool stores Eventhdl.c instead.
This is a problem for "make" of course. Therefore avoid pure 
capital file names for the Palm source files!
 	
===================================

Harald.Rieder@imail.de

===================================
