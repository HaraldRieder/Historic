/*
 Copyright (c) 2002, Harald Rieder, Stuttgart, Germany
 All rights reserved.
*/
#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS
#include <BuildDefines.h>
#ifdef DEBUG_BUILD
#  define ERROR_CHECK_LEVEL ERROR_CHECK_FULL
#endif
#include <PalmOS.h>
// new serial manager exists from OS version 3.3 on 
#include <SerialMgrOld.h>
#include "resource.h"
#include "palmutil.h"
#include "midi.h"
#include "eventhdl.h"
#include "common.h"

#ifdef DEBUG_BUILD
#  define debug(x) FrmCustomAlert(DEBUG_ALERT, x, "", "")
#else
#  define debug(x) 
#endif

// The minimum OS version we support
#define OUR_MIN_VERSION    sysMakeROMVersion(3,0,0,sysROMStageRelease,0)

#if 1
#  define MIDI_BAUD_RATE 31250        // MIDI speed
#else
#  define MIDI_BAUD_RATE 38400        // testing on DOSe with POSE
#endif 

static UInt32 ticks_per_second ;  // Palm OS ticks per second

/* =================== timer =========================== */

#define TIMEOUT 300 // milli seconds

static Boolean timer_is_running = false ;
static Int32 start_time ; // in ticks ;
static Int32 timeout ;    // in ticks ;

static Boolean timer_is_expired()
{
  Int32 now = TimGetTicks() ;
  if (timeout)
  {
    // timer is running
    if (now - timeout >= start_time)
    {
      // expired => retrigger timer
      start_time = now ;
      return true ;
    }
    return false ;
  }
  // not yet started
  timeout = (ticks_per_second * TIMEOUT) / 1000 ;
  start_time = now ;
  return false ;
}

static void stop_timer() { timeout = 0 ; }

/* =================== serial =========================== */

UInt16 port_id ;  // handle to our serial interface 
Err recv_error ;  
Err send_error ;  

Boolean port_is_open = false ;

static void set_error_text(FormPtr form, const Char *error_text)
{
  if (error_text)
  {
    UInt16 len = StrLen(error_text) ;
    if (len >= ERROR_MAXCHARS)
      StrNCopy(buff, error_text, ERROR_MAXCHARS) ;
    else
    {
      // right aligned
      MemSet(buff, ERROR_MAXCHARS - len,' ') ;
      StrCopy(buff + ERROR_MAXCHARS - len, error_text) ;
    }
    buff[ERROR_MAXCHARS] = 0 ;
    FrmCopyLabel(form, ERROR_INDICATOR, buff) ;
  }
}

static void close_serial(void)
{
  if (port_is_open)
  {
    // wait for our own data to be transmitted
    while ( !timer_is_expired() ) ;
    stop_timer() ;
    
    port_is_open = false ;
    SerClearErr(port_id) ;
    SerClose(port_id) ;
  }
  recv_error = errNone ;
  send_error = errNone ;
}


static Err open_serial(UInt32 baud_rate)
{
  Err err ;
  if (port_is_open)
    return errNone ;
    
  err = SysLibFind("Serial Library", &port_id) ;
  if (err)
  {
    SysFatalAlert("Could not open 'Serial Libary'!") ;
    return err ;
  }
  err = SerOpen(port_id, 0, baud_rate);
  if (err == serErrAlreadyOpen)
    FrmAlert(SERIAL_IN_USE_ALERT) ;
  else if (err)
    FrmAlert(CANT_OPEN_SERIAL_ALERT) ;
  else
    port_is_open = true ;
  return err ;
}

/* ============== database ================= */

#define DB_NAME "MIDI Enhancer DB" 

static UInt16 DB_RECORD_TUNE    = 0 ;
static UInt16 DB_RECORD_CONTROL = 1 ;
static UInt16 DB_RECORD_STRINGS = 2 ;
static UInt16 DB_RECORD_PC_DATA = 3 ;
static UInt16 DB_RECORD_TEXTES  = 4 ;
static UInt16 DB_RECORD_FORM    = 5 ;
static UInt16 DB_RECORD_VOLS    = 6 ; /* new in V2.1a for Palm */

DmOpenRef db_ref ;

Err close_DB(void)
{
  Err err = errNone ;
  if (db_ref)
  {
    err = DmCloseDatabase(db_ref) ;
    db_ref = 0 ;
  }
  return err ;
}

Err open_DB(UInt16 mode)
{
  Err err = errNone ;

  if (db_ref)
    // already open
    return errNone ;

  // Find my database. If it doesn't exist, create it.

  db_ref = DmOpenDatabaseByTypeCreator('DATA', CREATOR_ID, mode) ;
  if (!db_ref)
  {
    err = DmGetLastErr() ;
    if (err == dmErrCantFind)
    {
      err = DmCreateDatabase(0, DB_NAME, CREATOR_ID, 'DATA', false) ;
      if (err == errNone || err == dmErrAlreadyExists)
      {
        db_ref = DmOpenDatabaseByTypeCreator('DATA', CREATOR_ID, mode) ;
        if (!db_ref)
          err = DmGetLastErr() ;
        else
          err = errNone ;
      }
    }
  }
  return err ;
}


/* ============================================== */

static Char byte_to_char(UInt8 byte) 
{
  static Char c[] = "0123456789abcdef" ;
  if (byte < sizeof(c))
    return c[byte] ;
  return '?' ;
}

static Boolean MIDI_test_and_send(char *string) 
{
    char *err_text ;
    UINT16 len ;
    
    if ( err_text = ascii_to_midi(string, &len) )
    {
        FrmCustomAlert(NO_MIDI_STRING, err_text, "", "") ;
        return false ;
    }
    /* send string */
    if (len)
    {
      open_serial(MIDI_BAUD_RATE) ;
      Midiws(len - 1, string) ;
      if (send_error != errNone)
      {
        FrmAlert(CANT_SEND_SERIAL_ALERT) ;
        send_error = errNone ;
      }
      close_serial() ;
    }
    return true ;
}

/* ============= common for all forms ================= */

UInt16 last_form ;  /* contains last active form ID */

Boolean menu_handle_event(EventPtr event)
{
  switch (event->data.menu.itemID)
  {
  case ABOUT_ME: FrmAlert(ABOUT_ME_ALERT) ; return true ;
  case SHOW_CONTROLLER:     FrmGotoForm(MAIN_FORM)    ; return true;
  case SHOW_TUNER:          FrmGotoForm(TUNER_FORM)   ; return true ;
  case SHOW_STRINGS:        FrmGotoForm(STRINGS_FORM) ; return true ;
  case SHOW_PROGRAM_CHANGE: FrmGotoForm(PC_FORM)      ; return true ;
  case SHOW_VOLUMES:        FrmGotoForm(VOLUMES_FORM) ; return true ;
  }
  return false ;
}


Boolean key_handle_event(EventPtr event)
{
  WChar chr = event->data.keyDown.chr ;
  if (event->data.keyDown.modifiers & commandKeyMask)  
  {
    // Handle hard key virtual character.
    UInt16 next, prev ;
  
    switch (last_form)
    {
    case TUNER_FORM:   prev = MAIN_FORM    ; next = STRINGS_FORM ; break ;
    case STRINGS_FORM: prev = TUNER_FORM   ; next = PC_FORM      ; break ;
    case PC_FORM:      prev = STRINGS_FORM ; next = VOLUMES_FORM ; break ;
    case VOLUMES_FORM: prev = PC_FORM      ; next = MAIN_FORM    ; break ;
    default:           prev = VOLUMES_FORM ; next = TUNER_FORM   ; break ;
    }
    /*StrPrintF(buff, "Char=%X", (int)chr) ;
    debug(buff) ;*/
    switch (chr)
    {
    case 0x000b: FrmGotoForm(prev) ; return true ;
    case 0x000c: FrmGotoForm(next) ; return true ;
    }
  }
  return false ;
}

/* ============= controller (main form) ================= */

static void exit_event_handler_plus_GUI(FormPtr form)
{
  FrmShowObject(form, FrmGetObjectIndex(form, INIT_INDICATOR)) ; 
  exit_event_handler() ;
}

/*--- inputs ---*/

static int INS[16] =
{
    IN_CHANNEL_0, IN_CHANNEL_1, IN_CHANNEL_2, IN_CHANNEL_3, 
    IN_CHANNEL_4, IN_CHANNEL_5, IN_CHANNEL_6, IN_CHANNEL_7, 
    IN_CHANNEL_8, IN_CHANNEL_9, IN_CHANNEL_A, IN_CHANNEL_B,
    IN_CHANNEL_C, IN_CHANNEL_D, IN_CHANNEL_E, IN_CHANNEL_F
} ;

static void hide_ins (FormPtr form) 
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
        FrmHideObject(form, FrmGetObjectIndex(form, INS[i])) ;
}

static void show_ins (FormPtr form) 
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
        FrmShowObject(form, FrmGetObjectIndex(form, INS[i])) ;
}

static void in_click(FormPtr form, UInt16 clicked_ID)
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
    {
        int j = 1 << i ;
        if (clicked_ID == INS[i]) 
            control.input_channels ^= j ;
    }
    exit_event_handler_plus_GUI(form) ;
}

/*--- outputs ---*/

static int OUTS[16] =
{
    OUT_CHANNEL_0, OUT_CHANNEL_1, OUT_CHANNEL_2, OUT_CHANNEL_3, 
    OUT_CHANNEL_4, OUT_CHANNEL_5, OUT_CHANNEL_6, OUT_CHANNEL_7, 
    OUT_CHANNEL_8, OUT_CHANNEL_9, OUT_CHANNEL_A, OUT_CHANNEL_B,
    OUT_CHANNEL_C, OUT_CHANNEL_D, OUT_CHANNEL_E, OUT_CHANNEL_F
} ;

static void hide_outs(FormPtr form) 
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
        FrmHideObject(form, FrmGetObjectIndex(form, OUTS[i])) ;
}

static void show_outs(FormPtr form) 
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
        FrmShowObject(form, FrmGetObjectIndex(form, OUTS[i])) ;
}

static void out_click(FormPtr form, UInt16 clicked_ID)
{
    int i ;
    for (i = 0 ; i < 16 ; i++) 
    {
        int j = 1 << i ;
        if (clicked_ID == OUTS[i]) 
            control.output_channels ^= j ;
    }
    /* channels go into note list => full update necessary */
    exit_event_handler_plus_GUI(form) ;
}

/*--- common ---*/

static void tuner_to_controller(FormPtr form)
{
	if ( tune.mode & SCALE_TUNE )
    hide_outs(form) ;
  else if ( !(control.mode & THROUGH) )
		show_outs(form) ;
}


static void update_pitch_offset_GUI(FormPtr form, Boolean redraw)
{
  /* if offset overflow, indicate by '!' */
  if (critical_offset)
  {
    if (tune.mode == SCALE_TUNE)
      StrPrintF(buff, "%d !", pitch_offset) ;
    else
      StrPrintF(buff, "%4x$ !", pitch_offset) ;
  }
  else
  {
    if (tune.mode == SCALE_TUNE)
      StrPrintF(buff, "%d", pitch_offset) ;
    else
      StrPrintF(buff, "%4x$", pitch_offset) ;
  }
  FrmCopyLabel(form, PITCH_OFFSET, buff) ;
  /*set_field_text_id(form, PITCH_OFFSET, buff, redraw) ;  */
}

static void update_smoothing_GUI(FormPtr form)
{
  StrPrintF(buff, "%i", control.smoothing) ;
  select_popup_item(form, SMOOTHING_TRIGGER, SMOOTHING_LIST, buff) ;
}

static void update_table_GUI(FormPtr form)
{
  if (form != NULL)
  {
    /* update GUI */
    StrPrintF(buff, "%u", tune.table) ; 
    select_popup_item(form, TABLE_TRIGGER, TABLE_LIST, buff) ; 
  }
}

static void update_key_GUI(FormPtr form)
{
  if (control.key == INVALID)
    select_popup_item(form, KEY_TRIGGER, KEY_LIST, "-") ; 
  else
  {
    StrPrintF(buff, "%X", (unsigned)(control.key)) ; 
    select_popup_item(form, KEY_TRIGGER, KEY_LIST, buff + StrLen(buff) - 1) ;
  }
}

static void update_harmonizing_note_GUI(FormPtr form)
{
  if (harmonizing_note == INVALID) 
    StrCopy(buff, "-") ;
  else 
    StrPrintF(buff, "%X", harmonizing_note % 12) ;
  FrmCopyLabel(form, HARMONIZING_NOTE, buff + StrLen(buff) - 1) ;
}

static void update_automatic_GUI(FormPtr form)
{
    if (control.mode & AUTOMATIC) 
    {
        FrmHideObject(form, FrmGetObjectIndex(form, HOLD_CHECKBOX    )) ;
        FrmHideObject(form, FrmGetObjectIndex(form, TABLE_LABEL      )) ;
        FrmHideObject(form, FrmGetObjectIndex(form, TABLE_TRIGGER    )) ;
        FrmShowObject(form, FrmGetObjectIndex(form, SMOOTHING_LABEL  )) ;
        FrmShowObject(form, FrmGetObjectIndex(form, SMOOTHING_TRIGGER)) ;
    }
    else 
    {
        FrmShowObject(form, FrmGetObjectIndex(form, HOLD_CHECKBOX    )) ;
        FrmShowObject(form, FrmGetObjectIndex(form, TABLE_LABEL      )) ;
        FrmShowObject(form, FrmGetObjectIndex(form, TABLE_TRIGGER    )) ;
        FrmHideObject(form, FrmGetObjectIndex(form, SMOOTHING_LABEL  )) ;
        FrmHideObject(form, FrmGetObjectIndex(form, SMOOTHING_TRIGGER)) ;
    }
}

static void through(FormPtr form, Boolean through)
{
  set_error_text(form, "") ;
  send_error = recv_error = errNone ;
  exit_event_handler_plus_GUI(form) ;
  if (through) 
  {
    if ( !(control.mode & THROUGH) )
    {
      send_exit_string() ;
      //SndPlaySystemSound(sndError); 
    }
    control.mode |= THROUGH ;
    FrmHideObject(form, FrmGetObjectIndex(form, AUTO_CHECKBOX          )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, HOLD_CHECKBOX          )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, KEY_LABEL              )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, KEY_TRIGGER            )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, TABLE_LABEL            )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, TABLE_TRIGGER          )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, SMOOTHING_LABEL        )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, SMOOTHING_TRIGGER      )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, CONTROL_CHANNEL_LABEL  )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, CONTROL_CHANNEL_TRIGGER)) ;
    FrmHideObject(form, FrmGetObjectIndex(form, HARMONIZING_NOTE       )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, HARMONIZING_LABEL      )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, PITCH_OFFSET           )) ;
    FrmHideObject(form, FrmGetObjectIndex(form, PITCH_LABEL            )) ;
    hide_ins (form) ;
    hide_outs(form) ;
  }
  else 
  {
    if ( control.mode & THROUGH )
    {
      send_enter_string() ;
      //SndPlaySystemSound(sndWarning); 
    }
    control.mode &= ~THROUGH ;
    FrmShowObject(form, FrmGetObjectIndex(form, AUTO_CHECKBOX          )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, HOLD_CHECKBOX          )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, KEY_LABEL              )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, KEY_TRIGGER            )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, TABLE_LABEL            )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, TABLE_TRIGGER          )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, SMOOTHING_LABEL        )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, SMOOTHING_TRIGGER      )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, CONTROL_CHANNEL_LABEL  )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, CONTROL_CHANNEL_TRIGGER)) ;
    FrmShowObject(form, FrmGetObjectIndex(form, HARMONIZING_NOTE       )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, HARMONIZING_LABEL      )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, PITCH_OFFSET           )) ;
    FrmShowObject(form, FrmGetObjectIndex(form, PITCH_LABEL            )) ;
    update_automatic_GUI(form) ;
    show_ins(form) ;
    tuner_to_controller(form) ;
  }
}

static void controller_init(FormPtr form)
{
  INT16 i ;
  /* copy data into form objects */
  for (i = 0 ; i < 16 ; i++)
  {
    INT16 j = 1 << i ; /* channel mask */
    if ( j & control.harmonizing_channel )
    {
      /* attention: "%X", 3 leads to "0003" !!! */
      StrPrintF(buff, "%X", i) ;
      select_popup_item(form, CONTROL_CHANNEL_TRIGGER, CONTROL_CHANNEL_LIST, 
        buff + StrLen(buff) - 1) ;
    }
    CtlSetValue(get_object(form, INS [i]), control.input_channels  & j) ;
    CtlSetValue(get_object(form, OUTS[i]), control.output_channels & j) ;
  }
  CtlSetValue(get_object(form, HOLD_CHECKBOX   ), control.mode & HOLD     ) ;
  CtlSetValue(get_object(form, AUTO_CHECKBOX   ), control.mode & AUTOMATIC) ;
  CtlSetValue(get_object(form, THROUGH_BUTTON  ), control.mode & THROUGH  ) ;
  CtlSetValue(get_object(form, ENHANCE_BUTTON  ),!(control.mode & THROUGH)) ;

  through(form, control.mode & THROUGH) ;    /* disable/enable consistently */
/*  update_harmonizing_note_GUI(form) ; happens now after event handler init */
/*  update_pitch_offset_GUI    (form, false) ; happens now after event handler init */
  update_smoothing_GUI       (form) ;
  update_table_GUI           (form) ;
  update_key_GUI             (form) ;
}
    

Boolean main_form_handle_event(EventPtr event)
{
  INT16 i, message ;
  FormPtr form = FrmGetActiveForm();
  last_form = FrmGetActiveFormID();

  switch (event->eType) 
  {
  case frmOpenEvent:
    open_serial(MIDI_BAUD_RATE) ;
    if (!(control.mode & THROUGH))
    {
      send_enter_string() ;
      //SndPlaySystemSound(sndWarning); 
    }
    controller_init(form) ;
    FrmDrawForm(form);
    return true ;
      
  case frmCloseEvent:
    exit_event_handler_plus_GUI(form) ;
    if (!(control.mode & THROUGH))
    {
      send_exit_string() ;
      //SndPlaySystemSound(sndError); 
    }
    close_serial() ;
    return false;

  case menuEvent:
    if (event->data.menu.itemID == HELP)
    {
      FrmHelp(CONTROLLER_HELP) ;
      return true ;
    }
    return menu_handle_event(event) ;
    
  case keyDownEvent:
    return key_handle_event(event) ;
  
  case popSelectEvent:
    // active form seems to be the popup list here ?!?
    switch (event->data.popSelect.controlID) 
    {
    case CONTROL_CHANNEL_TRIGGER:
      control.harmonizing_channel = 1 << event->data.popSelect.selection ; 
      break ;
    case SMOOTHING_TRIGGER:
      update_smoothing(event->data.popSelect.selection) ; 
      break ;
    case KEY_TRIGGER:
      update_key(event->data.popSelect.selection - 1) ;
      /* key changes h. note in hold mode, too */
      update_harmonizing_note_GUI(form) ;
      break ;
    case TABLE_TRIGGER:
      update_table(event->data.popSelect.selection) ; 
      break ;
    }
    return false ;  // Palm OS shall update trigger text

  case ctlSelectEvent:
    switch (event->data.ctlSelect.controlID) 
    {
      case IN_CHANNEL_0: case IN_CHANNEL_1: case IN_CHANNEL_2: case IN_CHANNEL_3: 
      case IN_CHANNEL_4: case IN_CHANNEL_5: case IN_CHANNEL_6: case IN_CHANNEL_7: 
      case IN_CHANNEL_8: case IN_CHANNEL_9: case IN_CHANNEL_A: case IN_CHANNEL_B:
      case IN_CHANNEL_C: case IN_CHANNEL_D: case IN_CHANNEL_E: case IN_CHANNEL_F:
        in_click(form, event->data.ctlSelect.controlID) ;
        return true ;
      case OUT_CHANNEL_0: case OUT_CHANNEL_1: case OUT_CHANNEL_2: case OUT_CHANNEL_3: 
      case OUT_CHANNEL_4: case OUT_CHANNEL_5: case OUT_CHANNEL_6: case OUT_CHANNEL_7: 
      case OUT_CHANNEL_8: case OUT_CHANNEL_9: case OUT_CHANNEL_A: case OUT_CHANNEL_B:
      case OUT_CHANNEL_C: case OUT_CHANNEL_D: case OUT_CHANNEL_E: case OUT_CHANNEL_F:
        out_click(form, event->data.ctlSelect.controlID) ;
        return true ;

      case ENHANCE_BUTTON: through(form, false) ; return true ;
      case THROUGH_BUTTON: through(form, true ) ; return true ;

      case HOLD_CHECKBOX: 
        update_hold(event->data.ctlSelect.on) ; 
        return true ;

      case AUTO_CHECKBOX: 
        exit_event_handler_plus_GUI(form) ;
        if (event->data.ctlSelect.on)
          control.mode |= AUTOMATIC ;
        else
          control.mode &= ~AUTOMATIC ;
        update_automatic_GUI(form) ; 
        return true ;
    }
    break;

  case nilEvent:
    if (recv_error)
      // do nothing until the error gets cleared
      return true ;
    //SndPlaySystemSound(sndWarning); // test whether called often enough

	if (midi_data_available)
    {
      // as long as data is received without errors, avoid automatic power-off
      EvtResetAutoOffTimer() ;
    }

    /* On the Palm IDLE_RET is the only way to return from event_handler() ! */
    control.mode |= IDLE_RET ;  
    message = event_handler() ; 
    //StrPrintF(buff, "message=%d", (int)message) ; debug(buff) ;
    switch (message) 
    {
    case TABLE_CHANGED:    
      update_table_GUI(form) ; 
      break ;
    case KEY_CHANGED:
    case TIME_CHANGED:    
    case INITIALIZED:
      switch (message)
      {
      case KEY_CHANGED: 
        update_key_GUI(form) ; 
        /* key changes h. note in hold mode, too */
        update_harmonizing_note_GUI(form) ;
        break ;
      case TIME_CHANGED: 
        update_smoothing_GUI(form) ; 
        break ;
      case INITIALIZED:
        FrmHideObject(form, FrmGetObjectIndex(form, INIT_INDICATOR)) ;
        break ;
      }
      set_error_text(form, "") ;
      /* no break, continue ! */
    case H_NOTE_CHANGED:
      update_harmonizing_note_GUI(form) ;
      update_pitch_offset_GUI(form, true) ;
      break ;
    case ERROR_OCCURRED:
      set_error_text(form, error_text) ;
      break ;
    case MIDI_IDLE:
      /*update_idle_indicator(form) ;*/
      break ;
    }
    if (recv_error == serErrTimeOut)
    {
      recv_error = errNone ; // possible timeout is no error 
    }
    if (recv_error != errNone)
      set_error_text(form, "Receive error !") ;
    else if (send_error != errNone)
      set_error_text(form, "Send error !") ;
    return true ;
  }  
  return false ;
}

/* ============= tuner form ================= */

static TEXTES textes ;

UBYTE get_test_channel(void)
{
  void *trigger ;
  FormPtr form = FrmGetFormPtr(TUNER_FORM) ;
  if (!form)
    return 0 ;
  trigger = FrmGetObjectPtr(form, FrmGetObjectIndex(form, TEST_CHANNEL_TRIGGER)) ;
  if (!trigger)
    return 0 ;
	return (UBYTE)atoi( CtlGetLabel(trigger) ) ;
}

static void update_pitch(FormPtr form, Boolean with_slider, Boolean redraw)
{
  int cent        = tune.pitches[tune.table][pitch_index] ;
  int pitch       = cent_to_pb(cent) ;
  int scale_tune  = cent + MEAN_STUNE ;
  scale_tune = min(MAX_STUNE, scale_tune) ;
  scale_tune = max(MIN_STUNE, scale_tune) ;

  /* range is -100 .. +100 cent */
	StrPrintF(buff, "%i cent", cent) ;
/*  FrmCopyLabel(form, SLIDER_TEXT, buff) ;*/
  set_field_text_id(form, SLIDER_TEXT, buff, redraw) ;  

  /* range is 0x0000 .. 0x3fff */
  StrPrintF(buff, "%X", pitch) ; 
/*  FrmCopyLabel(form, PITCH_BEND_DISPLAY, buff) ;*/
  set_field_text_id(form, PITCH_BEND_DISPLAY, buff, redraw) ;  

	/* range is -64 .. +63 cent */
  StrPrintF(buff, "%i", scale_tune - MEAN_STUNE) ; 
/*  FrmCopyLabel(form, SCALE_TUNE_DISPLAY, buff) ;*/
  set_field_text_id(form, SCALE_TUNE_DISPLAY, buff, redraw) ;  

  /* (fitting text is empty, if pitch_index has no fitting entry) */
  set_field_text_id(form, FIT, get_fitting_text(cent), redraw) ;  

  if (with_slider)
    CtlSetValue(get_object(form, DISTANCE_SLIDER), cent + 100) ;

	send_tuning() ;
}


static void set_table_and_text(FormPtr form, unsigned char table,
                               Boolean redraw)
{
  /* update GUI */
  StrPrintF(buff, "%u", table) ; 
  select_popup_item(form, TABLE_TRIGGER_TUNER, TABLE_LIST_TUNER, buff) ; 

  if (table != tune.table)
  {
    /* table has changed, save changed text */
    const Char *txt = get_field_text_id(form, TABLE_TEXT) ;
    strncpy(textes[tune.table], txt, sizeof(textes[0])-1) ;

    tune.table = table ;
  }
  set_field_text_id(form, TABLE_TEXT, textes[table], redraw) ;

	if (pitch_index) switch_notes(0) ; /* notes off */
 	update_pitch(form, true, redraw) ;
	if (pitch_index) switch_notes(1) ; /* notes on */
}


static UInt16 pitch_display[] = { 
	PITCH_BEND_DISPLAY,
	SCALE_TUNE_DISPLAY,
	FIT,
	DISTANCE_SLIDER,
	SLIDER_TEXT,
	0	/* termination */
} ;


static void enable_pitch_displays(FormPtr form)
{
	int i = 0 ;
	while( pitch_display[i] )
	{
    FrmShowObject(form, FrmGetObjectIndex(form, pitch_display[i])) ;
		i++ ;
	}
  FrmShowObject(form, FrmGetObjectIndex(form, NEXT_FIT)) ;
  FrmShowObject(form, FrmGetObjectIndex(form, PREV_FIT)) ;
}


static void disable_pitch_displays(FormPtr form)
{
	int i = 0 ;
	while( pitch_display[i] )
	{
    FrmHideObject(form, FrmGetObjectIndex(form, pitch_display[i])) ;
		i++ ;
	}
  FrmHideObject(form, FrmGetObjectIndex(form, NEXT_FIT)) ;
  FrmHideObject(form, FrmGetObjectIndex(form, PREV_FIT)) ;
}


static void distance(FormPtr form, int new_index)
{
	/* previous notes off */
	if (pitch_index) switch_notes(0) ;

  pitch_index = new_index ;

	/* copy pitch to enabled pitch displays or disable pitch display */
	if (pitch_index) 
	{
    open_serial(MIDI_BAUD_RATE) ;
		enable_pitch_displays(form) ;
		update_pitch(form, true, true) ;
		switch_notes(1) ; /* notes on */
	}
	else 
	{
		disable_pitch_displays(form) ;
		update_pitch(form, true, true /*redraw*/) ;
		cleanup_pitches() ;
	  close_serial() ;
	}
}


static void select_distance_0(FormPtr form)
{
  CtlSetValue(get_object(form, DISTANCE_0), 1) ;
  CtlSetValue(get_object(form, DISTANCE_1), 0) ;
  CtlSetValue(get_object(form, DISTANCE_2), 0) ;
  CtlSetValue(get_object(form, DISTANCE_3), 0) ;
  CtlSetValue(get_object(form, DISTANCE_4), 0) ;
  CtlSetValue(get_object(form, DISTANCE_5), 0) ;
  CtlSetValue(get_object(form, DISTANCE_6), 0) ;
  CtlSetValue(get_object(form, DISTANCE_7), 0) ;
  CtlSetValue(get_object(form, DISTANCE_8), 0) ;
  CtlSetValue(get_object(form, DISTANCE_9), 0) ;
  CtlSetValue(get_object(form, DISTANCE_A), 0) ;
  CtlSetValue(get_object(form, DISTANCE_B), 0) ;
  distance(form, 0) ;
}


static void tuner_init(FormPtr form)
{
	int i ;
  for (i = 0 ; i < MAX_TABLES ; i++)
    textes[i][TABLE_TEXT_MAXCHARS] = 0 ;  /* safer */
  if (form)
  {
    CtlSetValue(get_object(form, TUNE_SCALE     ), tune.mode == SCALE_TUNE) ;
    CtlSetValue(get_object(form, TUNE_PITCH_BEND), tune.mode != SCALE_TUNE) ;
    set_table_and_text(form, tune.table, false) ;
	  update_pitch(form, true, false /*no redraw*/) ;
	
	  /* update controller appearance */
  	/*tuner_to_controller() ; not visible together with tuner on Palm !*/
  }
}


static const UInt16 preset_fields[MAX_PRESETS] = 
{
  PRESET_1_FIELD, PRESET_2_FIELD, PRESET_3_FIELD, PRESET_4_FIELD,
  PRESET_5_FIELD, PRESET_6_FIELD, PRESET_7_FIELD     
} ;

Boolean tuner_form_handle_event(EventPtr event)
{
  FormPtr form = FrmGetActiveForm();
  last_form = FrmGetActiveFormID();

  switch (event->eType) 
  {
  case frmOpenEvent:
  	select_distance_0(form) ; /* switch off tuner */
    tuner_init(form) ;
    FrmDrawForm(form);
    return true ;
      
  case frmCloseEvent:
    {
      /* save possibly changed text */
      const Char *txt = get_field_text_id(form, TABLE_TEXT) ;
      strncpy(textes[tune.table], txt, sizeof(textes[0])-1) ;
    }
  	select_distance_0(form) ; /* switch off tuner */
    return false ;  /* Palm OS shall erase screen and destroy form in memory */
      
  case popSelectEvent:
    // active form seems to be the popup list here ?!?
    switch (event->data.popSelect.controlID) 
    {
    case TABLE_TRIGGER_TUNER:
      set_table_and_text(form, event->data.popSelect.selection, true) ;
      break ;
    case TEST_CHANNEL_TRIGGER:
      switch_notes(0) ; /* notes off on old channel */
      break ;
    }
    return false ;  // Palm OS shall update trigger text

  case ctlRepeatEvent:    // is a feedback slider
    switch (event->data.ctlRepeat.controlID) 
    {
    case DISTANCE_SLIDER:
      tune.pitches[tune.table][pitch_index] = event->data.ctlRepeat.value - 100 ;
      update_pitch(form, false, true) ;
      break ;
    }
    break ;
    
  case ctlSelectEvent:
    switch (event->data.ctlSelect.controlID) 
    {
    case PRESET_BUTTON:
      {
        /* do modal preset dialog */
        UInt16 i ;
        FormPtr preset_form = FrmInitForm(PRESETS_FORM) ;
        for (i = 0 ; i < MAX_PRESETS ; i++)
        {
          set_field_text_id(preset_form, preset_fields[i], presets[i].name, false) ;  
        }
        switch ( FrmDoDialog(preset_form) )
        {
        case PRESET_1: i = 1 ; break ;
        case PRESET_2: i = 2 ; break ;
        case PRESET_3: i = 3 ; break ;
        case PRESET_4: i = 4 ; break ;
        case PRESET_5: i = 5 ; break ;
        case PRESET_6: i = 6 ; break ;
        case PRESET_7: i = 7 ; break ;
        default:       i = 0 ;  /* "Cancel" pressed */
        }
        FrmDeleteForm(preset_form) ;
        if (i)
        {
          i-- ; /* start with #0 */
          /* a preset was selected, copy it to current table */
          memcpy(&(tune.pitches[tune.table]), presets[i].pitches, sizeof(presets[i].pitches)) ;
          strncpy(textes[tune.table], presets[i].name, sizeof(textes[0])-1) ;
          set_table_and_text(form, tune.table, true) ;
        }
      }
      break ;
    /*case DISTANCE_SLIDER:
      tune.pitches[tune.table][pitch_index] = event->data.ctlSelect.value - 100 ;
      update_pitch(form, false, true) ;
      break ;*/
    case PREV_FIT:
    	/* update value and redisplay */
      goto_prev_fit() ;
	    update_pitch(form, true, true) ;
      break ;
    case NEXT_FIT:
    	/* update value and redisplay */
      goto_next_fit() ;
	    update_pitch(form, true, true) ;
      break ;
    case TUNE_PITCH_BEND:
      switch_notes(0) ; /* notes off */
      tune.mode = PITCH_BND ; 
      /*tuner_to_controller(form) ;*/
      break ;
    case TUNE_SCALE:
      switch_notes(0) ; /* notes off */
      tune.mode = SCALE_TUNE ; 
      /*tuner_to_controller(form) ;*/
      break ;
    case DISTANCE_0: distance(form, 0) ; break ;
    case DISTANCE_1: distance(form, 1) ; break ;
    case DISTANCE_2: distance(form, 2) ; break ;
    case DISTANCE_3: distance(form, 3) ; break ;
    case DISTANCE_4: distance(form, 4) ; break ;
    case DISTANCE_5: distance(form, 5) ; break ;
    case DISTANCE_6: distance(form, 6) ; break ;
    case DISTANCE_7: distance(form, 7) ; break ;
    case DISTANCE_8: distance(form, 8) ; break ;
    case DISTANCE_9: distance(form, 9) ; break ;
    case DISTANCE_A: distance(form,10) ; break ;
    case DISTANCE_B: distance(form,11) ; break ;
    }
    break ;

  case menuEvent: 
    if (event->data.menu.itemID == HELP)
    {
      FrmHelp(TUNER_HELP) ;
      return true ;
    }
    return menu_handle_event(event) ;
  case keyDownEvent:
    return key_handle_event(event) ;
  }
  return false ;
}


/* ============= enter/exit strings ================= */

Boolean strings_form_handle_event(EventPtr event)
{
  FormPtr form = FrmGetActiveForm();
  last_form = FrmGetActiveFormID();

  switch (event->eType) 
  {
  case frmOpenEvent:
    set_field_text_id(form, FIELD_ENTER_PB   , strings.on_enter_pb   , false);
    set_field_text_id(form, FIELD_EXIT_PB    , strings.on_exit_pb    , false);
    set_field_text_id(form, FIELD_ENTER_STUNE, strings.on_enter_stune, false);
    set_field_text_id(form, FIELD_EXIT_STUNE , strings.on_exit_stune , false);
    FrmDrawForm(form) ;
    return true ;
      
  case frmCloseEvent:
    strncpy(strings.on_enter_pb   , get_field_text_id(form, FIELD_ENTER_PB   ), sizeof(strings.on_enter_pb   )-1) ;
    strncpy(strings.on_exit_pb    , get_field_text_id(form, FIELD_EXIT_PB    ), sizeof(strings.on_exit_pb    )-1) ;
    strncpy(strings.on_enter_stune, get_field_text_id(form, FIELD_ENTER_STUNE), sizeof(strings.on_enter_stune)-1) ;
    strncpy(strings.on_exit_stune , get_field_text_id(form, FIELD_EXIT_STUNE ), sizeof(strings.on_exit_stune )-1) ;
    return false ;

  case ctlSelectEvent:
    switch (event->data.ctlSelect.controlID) 
    {
    case BUTTON_ENTER_PB:
        strncpy(buff, get_field_text_id(form, FIELD_ENTER_PB), sizeof(buff)-1) ;
        MIDI_test_and_send(buff) ;
        return true ;

    case BUTTON_EXIT_PB:
        strncpy(buff, get_field_text_id(form, FIELD_EXIT_PB), sizeof(buff)-1) ;
        MIDI_test_and_send(buff) ;
        return true ;

    case BUTTON_ENTER_STUNE:
        strncpy(buff, get_field_text_id(form, FIELD_ENTER_STUNE), sizeof(buff)-1) ;
        MIDI_test_and_send(buff) ;
        return true ;

    case BUTTON_EXIT_STUNE:
        strncpy(buff, get_field_text_id(form, FIELD_EXIT_STUNE), sizeof(buff)-1) ;
        MIDI_test_and_send(buff) ;
        return true ;
    }
    return false ;

  case menuEvent: 
    if (event->data.menu.itemID == HELP)
    {
      FrmHelp(STRINGS_HELP) ;
      return true ;
    }
    return menu_handle_event(event) ;
  case keyDownEvent:
    return key_handle_event(event) ;
  }
  return false ;
}


/* ============= program change mapper ================= */

static int PCS[MAX_PCS] = 
{ PC_0, PC_1, PC_2, PC_3, PC_4/*, PC_5, PC_6, PC_7, PC_8, PC_9*/ } ;

static int PC_STRINGS[MAX_PCS] = 
{ PC_STRING_0 ,PC_STRING_1 ,PC_STRING_2 ,PC_STRING_3 ,PC_STRING_4 /*,
  PC_STRING_5 ,PC_STRING_6 ,PC_STRING_7 ,PC_STRING_8 ,PC_STRING_9 */} ;


static void update_pc(FormPtr form, int i, Boolean redraw)
{
  if (pc_data[i].pc >= 0)
  {
    sprintf(buff, "%hd", (short)(pc_data[i].pc)) ;
  }
  else
  {
    if (pc_data[i].pc != -1)
    {
      pc_data[i].pc = -1 ;
      /*if (redraw)
        SndPlaySystemSound(sndWarning); // value was auto-corrected
        */
    }
    buff[0] = 0 ;
  }
  set_field_text_id(form, PCS[i], buff, redraw);
}


Boolean pc_form_handle_event(EventPtr event)
{
  FormPtr form = FrmGetActiveForm();
  UInt16 i ;
  last_form = FrmGetActiveFormID();

  switch (event->eType) 
  {
  case frmOpenEvent:
    for (i = 0 ; i < MAX_PCS ; i++)
    {
      update_pc(form, i, false) ;
      set_field_text_id(form, PC_STRINGS[i], pc_data[i].string, false);
    }
    FrmDrawForm(form) ;
    if (FrmGetFocus(form) == noFocus)
      /* set focus to one of the text fields, so the test button can be pressed */
      FrmSetFocus(form, FrmGetObjectIndex(form, PCS[0])) ;
    return true ;

  case fldEnterEvent:
  case frmCloseEvent:
    for (i = 0 ; i < MAX_PCS ; i++)
    {
      const Char *pc = get_field_text_id(form, PCS[i]) ;
      pc_data[i].pc = (char)StrAToI(pc) ;
      if (pc_data[i].pc == 0)
      {
        /* is this a really entered '0' ? */
        int l = strlen(pc) ;
        while (l)
        {
            if (pc[l-1] == '0')
                break ;
            l-- ;
        }
        if (l == 0)
            /* not meant as program change '0' */
            pc_data[i].pc = -1 ;
      }
      // correct PC, save and write back to form
      update_pc(form, i, event->eType != frmCloseEvent) ;
      // save string 
      strncpy(pc_data[i].string, get_field_text_id(form, PC_STRINGS[i]), PC_MAXCHARS) ;
    }
    return false ;

  case ctlSelectEvent:
    if (event->data.ctlSelect.controlID == BUTTON_PC_TEST)
    {
        UInt16 j = FrmGetFocus(form) ;
        if (j != noFocus)
        {
            j = FrmGetObjectId(form, j)    ;
            for (i = 0 ; i < MAX_PCS ; i++)
            {
                if (j == PCS[i] || j == PC_STRINGS[i])
                {
                    strncpy(buff, get_field_text_id(form, PC_STRINGS[i]), sizeof(buff)-1) ;
                    MIDI_test_and_send(buff) ;
                    break ;
                }
            }
        } /* else FormAlert() ? */
        return true ;
    }
    return false ;

  case menuEvent: 
    if (event->data.menu.itemID == HELP)
    {
      FrmHelp(PC_HELP) ;
      return true ;
    }
    return menu_handle_event(event) ;
  case keyDownEvent:
    return key_handle_event(event) ;
  }
  return false ;
}

/* ============= volumes transformer ================= */

typedef struct
{
  char data_0_2_4 ;
  char data_1_3   ;
  Boolean enabled ;
  unsigned regulation_point ;
} 
VOLS ;

VOLS vols ; /* on Palm only this info is persisitent */

static int VOL_CONTROLS[] =
{
    TEST_VOLUMES, RESET_VOLUMES, SLIDER_0_2_4, SLIDER_1_3, 
    REGULATION_POINT_SLIDER, REGULATION_POINT_INDICATOR, 
    -1/*last*/
} ;

static void update_regulation_point_indicator(FormPtr form)
{
  StrPrintF(buff, "%d", (int)BENDPOINT_2) ;
  FrmCopyLabel(form, REGULATION_POINT_INDICATOR, buff) ;
}

static void update_vol_controls (FormPtr form) 
{
    int i ;

    CtlSetValue(get_object(form, SLIDER_0_2_4), vols.data_0_2_4) ; 
    CtlSetValue(get_object(form, SLIDER_1_3  ), vols.data_1_3  ) ; 
    CtlSetValue(get_object(form, REGULATION_POINT_SLIDER),BENDPOINT_2-BENDPOINT_1-1) ;
    update_regulation_point_indicator(form) ;

    for (i = 0 ; 1 ; i++) 
    {
      if (VOL_CONTROLS[i] < 0)
        break ;
      if (vols.enabled)
        FrmShowObject(form, FrmGetObjectIndex(form, VOL_CONTROLS[i])) ;
      else 
        FrmHideObject(form, FrmGetObjectIndex(form, VOL_CONTROLS[i])) ;
    }
    CtlSetValue(get_object(form, ENABLE_VOLUMES), vols.enabled) ;
}

void update_0_2_4_volumes(char new_val)
{
  unsigned i = 0 ;
  vols.data_0_2_4 = new_val ;
  while (i < MAX_VOLUMES)
  {
    volumes.data[i] = new_val ;
    i += 2 ;
    if (i >= MAX_VOLUMES)
      break ;
    volumes.data[i] = new_val ;
    i += 2 ;
    if (i >= MAX_VOLUMES)
      break ;
    volumes.data[i] = new_val ;
    i += 8 ;
  }
}

void update_1_3_volumes(char new_val)
{
  unsigned i = 1 ;
  vols.data_1_3 = new_val ;
  while (i < MAX_VOLUMES)
  {
    volumes.data[i] = new_val ;
    i += 2 ;
    if (i >= MAX_VOLUMES)
      break ;
    volumes.data[i] = new_val ;
    i += 10 ;
  }
}

void update_regulation_point(char new_val)
{
	BENDPOINT_2 = vols.regulation_point = new_val ;
}

static void update_volumes()
{
  /* init uneditable (in Palm version) fields */
#if 0  
  volumes.mode     = VOL_LINEAR ;
  volumes.fixpoint = FIX_MIN ;
#else
  //volumes.fixpoint = FIX_ALL ;
  volumes.mode = VOL_ROLAND_JUNO_D ;
#endif

  /* set all volumes for all keys */
  set_volumes_all(HALF_VOLUME) ;
  if (vols.enabled)
  {
    update_0_2_4_volumes(vols.data_0_2_4) ;
    update_1_3_volumes  (vols.data_1_3  ) ;
  }
  update_regulation_point(vols.regulation_point) ;
}

void reset_volumes(FormPtr form)
{
  update_0_2_4_volumes(HALF_VOLUME) ;
  update_1_3_volumes  (HALF_VOLUME) ;
  update_vol_controls(form) ;
}

Boolean testing_volumes = false ;

void start_volumes_test(FormPtr form)
{
  CtlSetLabel(get_object( form, TEST_VOLUMES ), "Stop") ;
  set_error_text(form, "transforming...") ; /* max. 20 chars! */
  open_serial(MIDI_BAUD_RATE) ;
  testing_volumes = true ;
}

void stop_volumes_test(FormPtr form)
{
  CtlSetLabel(get_object( form, TEST_VOLUMES ), "Test") ;
  set_error_text(form, "") ;
  close_serial() ;
  testing_volumes = false ;
}


Boolean volumes_form_handle_event(EventPtr event)
{
  FormPtr form = FrmGetActiveForm();
  UInt16 i ;
  last_form = FrmGetActiveFormID();

  switch (event->eType) 
  {
  case frmOpenEvent:
    update_vol_controls(form) ;
    set_error_text(form, "") ;
    FrmDrawForm(form) ;
    return true ;

  case frmCloseEvent:
    if (testing_volumes)
      stop_volumes_test(form) ;  
    return false ;

  case ctlSelectEvent:
    switch (event->data.ctlSelect.controlID)
    {
    case RESET_VOLUMES:
      reset_volumes(form) ;
      return true ;
    case TEST_VOLUMES:
      if (testing_volumes)
        stop_volumes_test(form) ;
      else
        start_volumes_test(form) ;
      return true ;
    case ENABLE_VOLUMES:
      vols.enabled = event->data.ctlSelect.on ;
      update_vol_controls(form) ;
      update_volumes() ;
      return true ;
    }
    return false ;

  case ctlRepeatEvent:    // we have feedback sliders
    switch (event->data.ctlRepeat.controlID) 
    {
    case SLIDER_0_2_4:
      update_0_2_4_volumes(event->data.ctlRepeat.value) ;
      break ;
    case SLIDER_1_3:
      update_1_3_volumes(event->data.ctlRepeat.value) ;
      break ;
    case REGULATION_POINT_SLIDER:
      /* slider starts from 0 */
      update_regulation_point(event->data.ctlRepeat.value + BENDPOINT_1 + 1) ;
      update_regulation_point_indicator(form) ;
      break ;
    }
    break ;
    
  case nilEvent:
    if (!testing_volumes || recv_error)
      // do nothing until the error gets cleared
      return true ;

	if (midi_data_available)
    {
      // as long as data is received without errors, avoid automatic power-off
      EvtResetAutoOffTimer() ;
    }
    
    transform_volumes() ; 
    
    if (recv_error == serErrTimeOut)
    {
      recv_error = errNone ; // possible timeout is no error 
    }
    if (recv_error != errNone)
      set_error_text(form, "Receive error !") ;
    else if (send_error != errNone)
      set_error_text(form, "Send error !") ;
    return true ;

  case menuEvent: 
    if (event->data.menu.itemID == HELP)
    {
      FrmHelp(VOLUMES_HELP) ;
      return true ;
    }
    return menu_handle_event(event) ;
  case keyDownEvent:
    return key_handle_event(event) ;
  }
  return false ;
}


/* =============== application ================== */

static Boolean app_handle_event(EventPtr event)
{
  UInt16 form_ID;
  FormPtr form;

  if (event->eType == frmLoadEvent) 
  {
    // Load the form resource.
    form_ID = event->data.frmLoad.formID;
    form = FrmInitForm(form_ID);
    ErrFatalDisplayIf(!form, "Can't initialize form");
    FrmSetActiveForm(form);
    // Set the event handler for the form.  The handler of the currently
    // active form is called by FrmHandleEvent each time is receives an
    // event.
    switch (form_ID) 
    {
    case MAIN_FORM:    FrmSetEventHandler(form, main_form_handle_event   ); break;
    case TUNER_FORM:   FrmSetEventHandler(form, tuner_form_handle_event  ); break;
    case STRINGS_FORM: FrmSetEventHandler(form, strings_form_handle_event); break;
    case PC_FORM:      FrmSetEventHandler(form, pc_form_handle_event     ); break;
    case VOLUMES_FORM: FrmSetEventHandler(form, volumes_form_handle_event); break;
    default:
      ErrFatalDisplay("Invalid Form Load Event");
      break;
    }
    return true;
  } 
  else 
    return false;
}


static void app_event_loop(void)
{
  Err error;
  EventType event;

  do 
  {
    EvtGetEvent(&event, 0 /*evtWaitForever*/);
    
    if (! SysHandleEvent(&event))
      if (! MenuHandleEvent(0, &event, &error))
        if (! app_handle_event(&event))
          FrmDispatchEvent(&event);
  }
  while (event.eType != appStopEvent);
}



static Err app_start(void)
{
  Err err ;
  UInt16 form_ID = MAIN_FORM ;
  /* O'Reilly Palm OS Programming 2nd editidion page 426 */
  /* we need only default serial port for MIDI 
     => use backward comptible old serial manager */
  ticks_per_second = SysTicksPerSecond() ;

  /* init PC data if no DB exists yet to some senseful values */
  set_pcs_all(-1) ;

  err = open_DB(dmModeReadOnly) ;
  if (err == errNone)
  {
    // read data 
   	read_record(db_ref,	DB_RECORD_TUNE   , &tune   , sizeof(tune   )) ;
 	  read_record(db_ref, DB_RECORD_CONTROL, &control, sizeof(control)) ;
 	  read_record(db_ref, DB_RECORD_STRINGS, &strings, sizeof(strings)) ;
 	  read_record(db_ref, DB_RECORD_PC_DATA, pc_data , sizeof(pc_data)) ;
 	  read_record(db_ref, DB_RECORD_TEXTES , textes  , sizeof(textes )) ;
 	  read_record(db_ref, DB_RECORD_VOLS   , &vols   , sizeof(vols   )) ;
 	  read_record(db_ref, DB_RECORD_FORM   , &form_ID, sizeof(form_ID)) ;

    err = close_DB() ;
    if (err != errNone)
      ErrFatalDisplay("Can't close database '"DB_NAME"'!");
    FrmGotoForm(form_ID);
  }
  else ErrFatalDisplay("Can't open database '"DB_NAME"'!");

  /* init data structures for MIDI scale tune messages */
 	scale_tune_init() ;

  /* init key volumes structure */
  update_volumes() ;
 	
  return err ;
}


static void app_stop(void)
{
  FrmCloseAllForms() ; /* also fetches data from GUI */

  // not saved, should always be initially neutral:
  control.key = INVALID ; 

  if (open_DB(dmModeReadWrite) == errNone)
  {
    if (last_form != TUNER_FORM && last_form != STRINGS_FORM && 
        last_form != PC_FORM    && last_form != VOLUMES_FORM)
      last_form = MAIN_FORM ;

 	  if ( !update_record(db_ref, &DB_RECORD_TUNE   , &tune      , sizeof(tune     )) ||
         !update_record(db_ref, &DB_RECORD_CONTROL, &control   , sizeof(control  )) ||
         !update_record(db_ref, &DB_RECORD_STRINGS, &strings   , sizeof(strings  )) ||
         !update_record(db_ref, &DB_RECORD_PC_DATA, pc_data    , sizeof(pc_data  )) ||
         !update_record(db_ref, &DB_RECORD_TEXTES , textes     , sizeof(textes   )) ||
         !update_record(db_ref, &DB_RECORD_VOLS   , &vols      , sizeof(vols     )) ||
         !update_record(db_ref, &DB_RECORD_FORM   , &last_form , sizeof(last_form)) )
      ErrFatalDisplay("Can't update record in database '"DB_NAME"'!") ;
  }
  else
    ErrFatalDisplay("Can't open database '"DB_NAME"'!");
}



UInt32 PilotMain(UInt16 launchCode, MemPtr launchParameters, 
  UInt16 launchFlags)
{
#pragma unused(launchParameters)
  Err error;

  switch (launchCode)
  {
  case sysAppLaunchCmdNormalLaunch:
    if (error = rom_version_compatible(OUR_MIN_VERSION, launchFlags))
      return error ;
    if (error = app_start()) 
      return error;
    app_event_loop();
    app_stop();
    break;
  }
  return errNone;
}


