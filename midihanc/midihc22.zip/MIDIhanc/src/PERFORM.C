#include <ext.h>
/* use Pure C default.prj to compile */

#include <stdio.h>
#include <tos.h>

#define MAX 1000

/******************* result: **************************

- loop 1 with Bconout lasts ~15.5 s 
- loop 2 with Midiws  lasts ~15.5 s 
Both correspond to the time 1000 * 3 * 8 Bit need on
a 19000 baud connection.

- loop 3 with Bconout lasts ~25 s 
- loop 4 with Midiws  lasts ~28 s 
on Falcon030/32 MHz.

*******************************************************/

int main()
{
int n,i,j,k ;
unsigned char out[64] ;

	/* loop 1: test Bconout() speed to full buffer */	
	printf("starting Bconout() to full buffer now ...\n") ;
	for (n = 0 ; n < MAX ; n++)
	{
		for (i = 0; i < 16; i++)
		{
			Bconout(3, 0x10 | i) ;
			Bconout(3, 0x50) ; 
			Bconout(3, 0) ;
		}
	}

	/* loop 2: test Midiws() speed to full buffer */	
	printf("starting Midiws() to full buffer now ...\n") ;
	for (n = 0 ; n < MAX ; n++)
	{
		j = 0 ;
		for (i = 0; i < 16; i++)
		{
			out[j] = 0x10 | i ; j++ ;
			out[j] = 0x50 ; j++ ;
			out[j] = 0 ; j++ ;
		}
		if (j) { j-- ; Midiws(j, out) ; }
	}

	/* loop 3: test Bconout() speed to non-full buffer */	
	printf("starting Bconout() to non-full buffer now ...\n") ;
	for (n = 0 ; n < MAX ; n++)
	{
		for (i = 0; i < 16; i++)
		{
			Bconout(3, 0x10 | i) ;
			Bconout(3, 0x50) ; 
			Bconout(3, 0) ;
			for (k = 0; k < 13; k++) Bconstat(3) ;
		}
	}

	/* loop 4: test Midiws() speed to non-full buffer */	
	printf("starting Midiws() to non-full buffer now ...\n") ;
	for (n = 0 ; n < MAX ; n++)
	{
		j = 0 ;
		for (i = 0; i < 16; i++)
		{
			out[j] = 0x10 | i ; j++ ;
			out[j] = 0x50 ; j++ ;
			out[j] = 0 ; j++ ;
			for (k = 0; k < 13; k++) Bconstat(3) ;
		}
		if (j) { j-- ; Midiws(j, out) ; }
	}

	printf("ready.\n") ;
	getch() ; 
	return 0 ;
}