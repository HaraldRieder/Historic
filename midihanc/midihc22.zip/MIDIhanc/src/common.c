#ifdef __PALM__
#  define INT_MAX  32000
#  define INT_MIN -32000
#else
#  include <limits.h>		/* INT_MAX, ... */
#  include <tos.h>
#endif 

#include "portable.h"
#include "midi.h"
#include "eventhdl.h"
#include "common.h"

char buff[ TEXTBUFF_STRLEN + 1 ] ;

/********************************************************************
*
*         auxiliary functions
*
********************************************************************/

void pitch_bend_all(int value)
{
  int i ;
  for (i = 0 ; i < 16 ; i++)
    pitch_bend(i, value) ;
}


void cleanup_pitches(void)
{
  /* Set equal scale tune, because nasty to correct
     with synthesizer. Pitch bend not so critical, can
     be corrected with one touch of the pitch bend wheel. */
  scale_tune_init() ;
  scale_tune_send_all() ;
  pitch_bend_all(MEAN_PITCH) ;
}


/********************************************************************
*
*         strings
*
********************************************************************/

STRINGS strings ;

void set_pcs_all(char value)
{
	int i ;
	for (i = 0 ; i < MAX_PCS ; i++)
		pc_data[i].pc = value ;
}

static void map_and_send(const char *s)
  /* only for use within string */
{
  char mapped[MIDI_STRING_MAXCHARS+1] ;
  UINT16 len ;
  strcpy(mapped, s) ;
  
  if ( ascii_to_midi(mapped, &len) == 0 && len )
    /* good and not empty => send it */
    Midiws(len - 1, mapped) ;
}

void send_enter_string(void)
{
  if (tune.mode == SCALE_TUNE)
    map_and_send(strings.on_enter_stune) ;
  else
    map_and_send(strings.on_enter_pb) ;
}

void send_exit_string(void)
{
  if (tune.mode == SCALE_TUNE)
    map_and_send(strings.on_exit_stune) ;
  else
    map_and_send(strings.on_exit_pb) ;
}

/********************************************************************
*
*         velocities (volumes) modifier
*
********************************************************************/

void set_volumes_all(char value) 
{
	int i ;
	for (i = 0 ; i < MAX_VOLUMES ; i++)
		volumes.data[i] = value ;
}

void transform_volumes(void)
{
	UBYTE Rx_buffer, status, note, dynamic ;
	while( midi_data_available ) 
	{
		Rx_buffer = midi_in ; /* 1 byte in */
		if (Rx_buffer & STATUS)
		{
			/* status byte received */
			status = Rx_buffer ;
			midi_out(status) ;
		}
		else switch (status & MSN) 
		{
		case NOTE_ON: 
		/* case NOTE_OFF: event handler transforms ON only */
			note = Rx_buffer ;
			midi_out(note) ;
			while (!midi_data_available) ;
			dynamic = transform_dynamic(note, midi_in) ;
			midi_out(dynamic) ;
			break ;
		default:
			midi_out(Rx_buffer) ;
		}
	}
}

/********************************************************************
*
*         tuner 
*
********************************************************************/

typedef struct 
{
	int cent_from_tonica ;
	char text[14] ;
} 
CENT_FROM_TONICA_AND_TEXT ;

static CENT_FROM_TONICA_AND_TEXT fits[] =
{
  /* chromatic: */ 
    { -100, "C 2^(11/12)"},
    {    0, "tonica"     },
    {  100, "C 2^(1/12)" },
    {  200, "C 2^(2/12)" },
    {  300, "C 2^(3/12)" },
    {  400, "C 2^(4/12)" },
    {  500, "C 2^(5/12)" },
    {  600, "C 2^(6/12)" },
    {  700, "C 2^(7/12)" },
    {  800, "C 2^(8/12)" },
    {  900, "C 2^(9/12)" },
    { 1000, "C 2^(10/12)"},
    { 1200, "tonica"     },
    { 1300, "C 2^(1/12)" },
  /* meantone: */ 
    {  116, "M 2^(3/31)" },
    {  194, "M 2^(5/31)" },
    {  310, "M 2^(8/31)" },
    {  387, "M 2^(10/31)"},
    {  503, "M 2^(13/31)"},
    {  581, "M 2^(15/31)"},
    {  697, "M 2^(18/31)"},
    {  813, "M 2^(21/31)"},
    {  890, "M 2^(23/31)"},
    { 1006, "M 2^(26/31)"},
    { 1084, "M 2^(28/31)"},
  /* natural: */
    {  112, "4/3 * 4/5"  },
    {  204, "3/2 * 3/4"  },
    {  231, "4/7 * 2"    },
    {  182, "5/9 * 2"    },
    {  151, "6/11 * 2"   },
    {  316, "3/5 * 2"    },
    {  267, "7/6"        },
    {  386, "5/4"        },
    {  435, "9/7"        },
    {  498, "2/3 * 2"    },
    {  590, "3/2*3/2*5/8"},
    {  583, "7/5"        },
    {  617, "5/7 * 2"    },
    {  702, "3/2"        },
    {  765, "7/9 * 2"    },
    {  814, "4/5 * 2"    },
    {  884, "5/3"        },
    {  933, "6/7 * 2"    },
    {  969, "7/4"        },
    {  996, "4/3 * 4/3"  },
    { 1018, "9/5"        },
    { 1049, "11/6"       },
    { 1088, "3/2 * 5/4"  },
  /* termination: */
    {0,""}
} ;

int pitch_index = 0 ; /* stop button pressed */

void goto_prev_fit()
{
	CENT_FROM_TONICA_AND_TEXT *fit ;

	int current = tune.pitches[tune.table][pitch_index] + pitch_index * 100 ;
	int prev    = INT_MIN ;
	int max_in_interval = current ;
	int abs_min = pitch_index * 100 - PB_HALF_RANGE ;
	int abs_max = pitch_index * 100 + PB_HALF_RANGE ;
	
	for ( fit = fits ; fit->text[0] ; fit++ )
	{
		/* find out maximum fit in interval */
		if ( fit->cent_from_tonica <= abs_max )
			max_in_interval = max( max_in_interval, fit->cent_from_tonica ) ;

		/* is there a fit between current cent and start of interval ? */
		if ( fit->cent_from_tonica >= abs_min &&
		     fit->cent_from_tonica < current )
			prev = max( prev, fit->cent_from_tonica ) ;
	}
	if (prev == INT_MIN)	
		/* nothing was found in down direction, wrap around: */
		prev = max_in_interval ;
		
	tune.pitches[tune.table][pitch_index] = prev - pitch_index * 100 ;
}

void goto_next_fit(void)
{
	CENT_FROM_TONICA_AND_TEXT *fit ;

	int current = tune.pitches[tune.table][pitch_index] + pitch_index * 100 ;
	int next    = INT_MAX ;
	int min_in_interval = current ;
	int abs_min = pitch_index * 100 - PB_HALF_RANGE ;
	int abs_max = pitch_index * 100 + PB_HALF_RANGE ;
	
	for ( fit = fits ; fit->text[0] ; fit++ )
	{
		/* find out minimum fit in interval */
		if ( fit->cent_from_tonica >= abs_min )
			min_in_interval = min( min_in_interval, fit->cent_from_tonica ) ;

		/* is there a fit between current cent and end of interval ? */
		if ( fit->cent_from_tonica <= abs_max &&
		     fit->cent_from_tonica > current )
			next = min( next, fit->cent_from_tonica ) ;
	}
	if (next == INT_MAX)	
		/* nothing was found in up direction, wrap around: */
		next = min_in_interval ;
		
	tune.pitches[tune.table][pitch_index] = next - pitch_index * 100 ;
}

const char * get_fitting_text(int cent)
{
	CENT_FROM_TONICA_AND_TEXT *fit ;

  for ( fit = fits ; fit->text[0] ; fit++ )
		if ( pitch_index * 100 + cent == fit->cent_from_tonica )
			break ;

  return fit->text ;
}

void send_tuning(void)
{
	if ( tune.mode == PITCH_BND )
		pitch_bend( get_test_channel() + 1, 
		            cent_to_pb(tune.pitches[tune.table][pitch_index]) ) ;
	else
	{
		scale_tune_set_cent( tune.pitches[tune.table] ) ;
		scale_tune_send_all() ;
	}
}

void switch_notes(int on)
{
	UBYTE channel_0 = get_test_channel() ;
	UBYTE channel_1 = channel_0 ;
	
	if ( tune.mode == PITCH_BND )
	{
		channel_1++ ;
		channel_1 &= 0xF ;
	}
	if (on)
	{
		if ( tune.mode == PITCH_BND )
		{
			/* not really needed on channel_0, but easier
			   to test with tuner whether this branch is run */
			pitch_bend_sensitivity(channel_0, PB_SENS) ;
			pitch_bend_sensitivity(channel_1, PB_SENS) ;
		}
		note_on(channel_0, BASE_NOTE              , MEAN_DYNAMIC) ;
		note_on(channel_1, BASE_NOTE + pitch_index, MEAN_DYNAMIC) ;
	}
	else
	{
		note_off(channel_0, BASE_NOTE              , MEAN_DYNAMIC) ;
		note_off(channel_1, BASE_NOTE + pitch_index, MEAN_DYNAMIC) ;
	}
}


/*** presets ***/

PRESET presets[MAX_PRESETS] =
{
  {{0, -10, 4, -6, 8, -2, 12, 2, -8, 6, -4, 10}, "pythagorean"},
  {{0, 12, 4, 16, -14, -2, -10, 2, 14, -16, -4, -12}, "clean"},
  {{0, 12, 4, 16, -14, -2, 0, 2, 14, -16, -4, -12}, "clean symmetric"},
  {{0, -30, -18, -96, -14, -2, -10, 2, 84, 6, 18, -12}, "clean 2*2 and 2*9 (pitch bend mode only)"},
  {{0, 16, -6, 10, -13, 3, -19, -3, 13, -10, 6, -16}, "meantone"},
  {{0, -64, 31, -33, 35, -2, -66, 2, -35, 33, -31, -68}, "sevens (3/2 and 7/6)"},
  {{0, -50, 0, 50, 0, 0, 50, 0, 0, -50, 0, 50}, "arabian"}
} ;