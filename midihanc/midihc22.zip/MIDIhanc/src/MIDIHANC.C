/* MIDIHANC.C */

/* ACS < version 2.33 bug in some (the new ones) window objects (e.g. 3D buttons):

     Awi_obchange(controller_wi, START, controller_wi->work[START].ob_state & ~SELECTED) ;
	
   does change state, but redraws *before* changing the state, not afterwards !!!
   Better use this:

     controller_wi->work[START].ob_state &= ~SELECTED ;
     Awi_obchange(controller_wi, START, -1) ;
*/

#include <stdio.h>

#include <acs.h>
#include <acsplus.h>
#include <acs_plus.h>   /* my extensions */
#include <tos.h>        /* because of Dgetpath(), ... */
#include <ctype.h>      /* because of isxdigit() ... */
#include <string.h>     /* because of strrchr(), ... */
#include <stdlib.h>     /* because of itoa(), ... */

#include "eventhdl.h"
#include "common.h"
#include "midihanc.h"
#include "midihanc.ah"
#include <diskfile.h>
#include <servimem.h>
#include <graphic.h>

extern Awindow PUR_MODULE ; /* prototype of module window of ACS Pure Desk */

#define	wind_get( a, b, c, d, e, f ) \
			mt_wind_get( a, b, c, d, e, f, 0L )

static Awindow 
	*controller_wi = NULL, 
	*tuner_wi      = NULL, 
	*monitor_wi    = NULL, 
	*volumes_wi    = NULL,
	*string_wi     = NULL,
	*prog_chg_wi   = NULL ;

/* VDI handle of virtual screen workstation */
static int handle ;  

/********************************************************************
*
*         auxiliary functions
*
********************************************************************/

static void hide_out_arrows(void) ;
static void hide_in_arrows (void) ;
static void show_out_arrows(void) ;
static void show_in_arrows (void) ;

static int MIDI_test_and_send(char *string) 
{
	char *err_text ;
	UINT16 len ;
	
	if (!string || !*string)
		return TRUE ;

	if ( err_text = ascii_to_midi(string, &len) )
	{
		my_alert_str(NO_MIDI_STRING, err_text) ;
		return FALSE ;
	}
	/* send string */
	if (len)
		Midiws(len - 1, string) ;
	return TRUE ;
}


/********************************************************************
*
*         velocities (volumes) modifier
*
********************************************************************/

static void entry() {} ; /* click on button, unused at the moment */

static int userdefs[MAX_VOLUMES] =
{
	  UD0,  UD1,  UD2,  UD3,  UD4,  UD5,  UD6,  UD7,  UD8,  UD9, UD10, UD11, UD12, UD13, UD14, UD15,
	 UD16, UD17, UD18, UD19, UD20, UD21, UD22, UD23, UD24, UD25, UD26, UD27, UD28, UD29, UD30, UD31,
	 UD32, UD33, UD34, UD35, UD36, UD37, UD38, UD39, UD40, UD41, UD42, UD43, UD44, UD45, UD46, UD47,
	 UD48, UD49, UD50, UD51, UD52, UD53, UD54, UD55, UD56, UD57, UD58, UD59, UD60, UD61, UD62, UD63,
	 UD64, UD65, UD66, UD67, UD68, UD69, UD70, UD71, UD72, UD73, UD74, UD75, UD76, UD77, UD78, UD79,
	 UD80, UD81, UD82, UD83, UD84, UD85, UD86, UD87, UD88, UD89, UD90, UD91, UD92, UD93, UD94, UD95,
	 UD96, UD97, UD98, UD99,UD100,UD101,UD102,UD103,UD104,UD105,UD106,UD107,UD108,UD109,UD110,UD111,
	UD112,UD113,UD114,UD115,UD116,UD117,UD118,UD119,UD120,UD121,UD122,UD123,UD124,UD125,UD126,UD127
} ;
static int entries[MAX_VOLUMES] =
{
  ENTRY0,  ENTRY1,  ENTRY2,  ENTRY3,  ENTRY4,  ENTRY5,  ENTRY6,  ENTRY7,  ENTRY8,  ENTRY9, ENTRY10, ENTRY11, ENTRY12, ENTRY13, ENTRY14, ENTRY15,
 ENTRY16, ENTRY17, ENTRY18, ENTRY19, ENTRY20, ENTRY21, ENTRY22, ENTRY23, ENTRY24, ENTRY25, ENTRY26, ENTRY27, ENTRY28, ENTRY29, ENTRY30, ENTRY31,
 ENTRY32, ENTRY33, ENTRY34, ENTRY35, ENTRY36, ENTRY37, ENTRY38, ENTRY39, ENTRY40, ENTRY41, ENTRY42, ENTRY43, ENTRY44, ENTRY45, ENTRY46, ENTRY47,
 ENTRY48, ENTRY49, ENTRY50, ENTRY51, ENTRY52, ENTRY53, ENTRY54, ENTRY55, ENTRY56, ENTRY57, ENTRY58, ENTRY59, ENTRY60, ENTRY61, ENTRY62, ENTRY63,
 ENTRY64, ENTRY65, ENTRY66, ENTRY67, ENTRY68, ENTRY69, ENTRY70, ENTRY71, ENTRY72, ENTRY73, ENTRY74, ENTRY75, ENTRY76, ENTRY77, ENTRY78, ENTRY79,
 ENTRY80, ENTRY81, ENTRY82, ENTRY83, ENTRY84, ENTRY85, ENTRY86, ENTRY87, ENTRY88, ENTRY89, ENTRY90, ENTRY91, ENTRY92, ENTRY93, ENTRY94, ENTRY95,
 ENTRY96, ENTRY97, ENTRY98, ENTRY99,ENTRY100,ENTRY101,ENTRY102,ENTRY103,ENTRY104,ENTRY105,ENTRY106,ENTRY107,ENTRY108,ENTRY109,ENTRY110,ENTRY111,
ENTRY112,ENTRY113,ENTRY114,ENTRY115,ENTRY116,ENTRY117,ENTRY118,ENTRY119,ENTRY120,ENTRY121,ENTRY122,ENTRY123,ENTRY124,ENTRY125,ENTRY126,ENTRY127
} ;

static int changed ;
static char vel_path[128] ;

static void volumes_init(void) 
{
	int i ; long filesize ; char *v ;

	/* enumberate ACS objects and init volume values */
	for (i = 0 ; i < MAX_VOLUMES ; i++)
		volumes_wi->work[userdefs[i]].ob_spec.userblk->ub_parm = i ;
	set_volumes_all(HALF_VOLUME) ;

	/* append volume file name to volume path */
	sprintf(vel_path, "%sMIDIHANC.VEL", ACSblk->cfg_path) ;

	/* load the parameter file into RAM */
	v = (char *)load_file(vel_path, &filesize) ;
	if (v)
	{ 
		/* file successfully loaded */
		if ( filesize == sizeof(volumes) ) 
		{
			volumes_wi->toolbar[LINEAR   ].ob_state &= ~SELECTED ;
			volumes_wi->toolbar[QUADRATIC].ob_state &= ~SELECTED ;
			volumes_wi->toolbar[VOL_MIN  ].ob_state &= ~SELECTED ;
			volumes_wi->toolbar[VOL_MAX  ].ob_state &= ~SELECTED ;
			memcpy(&volumes, v, filesize) ;

			switch(volumes.mode)
			{
			case VOL_LINEAR:    i = LINEAR    ; break ;
			case VOL_QUADRATIC: i = QUADRATIC ; break ;
			}
			volumes_wi->toolbar[i].ob_state |= SELECTED ;

			switch (volumes.fixpoint)
			{
			case FIX_MIN:       i = VOL_MIN   ; break ;
			case FIX_MAX:       i = VOL_MAX   ; break ;
			}
			volumes_wi->toolbar[i].ob_state |= SELECTED ;
		}
		else my_alert_str(WRONG_FORMAT, vel_path) ; 
		unload_file(v) ;
	}
	if (volumes_wi->wi_id == -1)
		return ;
	Awi_obredraw (volumes_wi,             0);
	Awi_obredraw (volumes_wi, A_TOOLBAR | 1);
}

static void volumes_exit(void)
{
	int handle ;
	long rc ;

	if (changed)
	{
		/* try to open path */
		if ( (rc = /*Fopen*/Fcreate(vel_path, /*FO_WRITE*/0)) < 0 )
		{
			/* try to create MIDIHANC.VEL */
			if ( (rc = Fcreate(vel_path, 0 /* ordinary file */)) < 0 ) { 
				my_alert_str(NOT_CREATED, vel_path) ; 
				return ;
			}
		}
		handle = (int)rc ;
		
		/* save volumes */
		if ( Fwrite(handle, sizeof(volumes), &volumes) < 0 )
			my_alert_str(WRITE_ERROR, vel_path) ; 
		/* close file */
		Fclose(handle) ;
	}
}


static int cdecl USERDEF(PARMBLK *parmblk) 
{
	int points[4], inner_points[4] ;

	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	vswr_mode(handle, MD_REPLACE) ;

	/* draw outer and inner rectangles */
	vsf_interior(handle, FIS_SOLID) ;
	points[0] = parmblk->pb_x ;	
	points[1] = parmblk->pb_y + 5 ;	
	points[2] = parmblk->pb_x + parmblk->pb_w - 1 ;
	points[3] = parmblk->pb_y + parmblk->pb_h - 6 ;	
	/* left part */
	inner_points[0] = points[0] ;
	inner_points[1] = points[1] ;
	inner_points[2] = points[0] + 
	                  (parmblk->pb_w - 1) * volumes.data[parmblk->pb_parm] / MAX_VOLUME ;	
	inner_points[3] = points[3] ;
	vsf_color(handle, RED) ;
	vr_recfl(handle, inner_points) ;

	/* right part */
	inner_points[0] = points[2] ;
	inner_points[1] = points[1] ;
	if ( ACSblk->ncolors < GREEN + 1 )
	     vsf_color(handle, WHITE) ;
	else vsf_color(handle, GREEN ) ;
	vr_recfl(handle, inner_points) ;

	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	return(parmblk->pb_currstate) ;          
}


static void list_up(void)
{
	int i ;
	for (i = 0 ; i < MAX_VOLUMES ; i++)
		if (volumes_wi->work[entries[i]].ob_state & SELECTED)
	{
		volumes.data[i] ++ ; 
		volumes.data[i] = min(MAX_VOLUME, volumes.data[i]) ;
		Awi_obchange(volumes_wi, userdefs[i], -1) ;
		changed = TRUE ;
	}
}


static void list_down(void)
{
	int i ;
	for (i = 0 ; i < MAX_VOLUMES ; i++)
		if (volumes_wi->work[entries[i]].ob_state & SELECTED)
	{
		volumes.data[i] -- ; 
		volumes.data[i] = max(0, volumes.data[i]) ;
		Awi_obchange(volumes_wi, userdefs[i], -1) ;
		changed = TRUE ;
	}
}


static int all_volumes_selected = FALSE ;
static void all_volumes(void)
{
	int i ;
	if (all_volumes_selected) 
		for (i = 0 ; i < MAX_VOLUMES ; i++)
	{
		/* deselect all */
		volumes_wi->work[entries[i]].ob_state &= ~SELECTED ;
		Awi_obchange(volumes_wi, entries[i], -1) ;
		all_volumes_selected = FALSE ;
	}
	else for (i = 0 ; i < MAX_VOLUMES ; i++)
	{
		/* select all */
		volumes_wi->work[entries[i]].ob_state |= SELECTED ;
		Awi_obchange(volumes_wi, entries[i], -1) ;
		all_volumes_selected = TRUE ;
	}
}


static void test_volumes(void)
{
	UBYTE i ;
	do 
	{	
		transform_volumes() ;
	} 
	while ( !Bconstat(CON) ) ; /* while no key pressed */
	Bconin(CON) ;   /* throw away */

	/* cleanup MIDI */
	for (i = 0 ; i < 16 ; i++)
		all_notes_off(i) ;
}


static void volumes_button(void)
{
	changed = TRUE ;
	switch (ACSblk->ev_obnr)
	{
	case LINEAR:
		volumes.mode = VOL_LINEAR    ; break ;
	case QUADRATIC: 
		volumes.mode = VOL_QUADRATIC ; break ;
	case VOL_MIN:
		volumes.fixpoint = FIX_MIN ; break ;
	case VOL_MAX:
		volumes.fixpoint = FIX_MAX ; break ;
	}
}


/********************************************************************
*
*         program change mapper
*
********************************************************************/

static int PCS[MAX_PCS] = {  PC0, PC1, PC2, PC3, PC4, PC5, PC6, PC7, PC8, PC9,
                            PC10,PC11,PC12,PC13,PC14,PC15,PC16,PC17,PC18,PC19 } ;

static int PC_STRINGS[MAX_PCS] = { PC_STRING0 ,PC_STRING1 ,PC_STRING2 ,PC_STRING3 ,PC_STRING4 ,
                                   PC_STRING5 ,PC_STRING6 ,PC_STRING7 ,PC_STRING8 ,PC_STRING9 , 
                                   PC_STRING10,PC_STRING11,PC_STRING12,PC_STRING13,PC_STRING14, 
                                   PC_STRING15,PC_STRING16,PC_STRING17,PC_STRING18,PC_STRING19 } ;

static char pc_path[128] ;

static void pc_data_to_window(void)
{
	unsigned i ;
	for (i = 0 ; i < MAX_PCS ; i++)
	{
		/* make sure that strings in data are terminated early enough */
		pc_data[i].string[PC_MAXCHARS] = 0 ;
		
		Aob_printf (prog_chg_wi->work, PCS[i], "%hd", (short)(pc_data[i].pc)) ;
		Aob_puttext(prog_chg_wi->work, PC_STRINGS[i], pc_data[i].string) ;
		Awi_obchange(prog_chg_wi, PCS[i]       , -1) ;
		Awi_obchange(prog_chg_wi, PC_STRINGS[i], -1) ;
	}
}

static void pc_data_from_window(void)
{
	unsigned i, pc ;
	
	for (i = 0 ; i < MAX_PCS ; i++)
	{
		if (1 == Aob_scanf(prog_chg_wi->work, PCS[i], "%u", &pc))
		     pc_data[i].pc = (char)min(pc,127) ;
		else pc_data[i].pc = -1 ;
		Aob_gettext(prog_chg_wi->work, PC_STRINGS[i], pc_data[i].string) ;
	}
	pc_data_to_window() ; /* write back corrected data */
}

static void prog_chg_init(void) 
{
	int i ; long filesize ; char *p ;

	for (i = 0 ; i < MAX_PCS ; i++)
		pc_data[i].pc = -1 ;

	/* append program change file name to path */
	sprintf(pc_path, "%sMIDIHANC.PC", ACSblk->cfg_path) ;

	/* load the parameter file into RAM */
	p = (char *)load_file(pc_path, &filesize) ;
	if (p)
	{ 
		/* file successfully loaded */
		if ( filesize == sizeof(pc_data) ) 
			memcpy(pc_data, p, filesize) ;
		else my_alert_str(WRONG_FORMAT, pc_path) ; 
		unload_file(p) ;
	}

	/* write data to window objects */
	pc_data_to_window() ;
}

static void prog_chg_exit(void)
{
	int handle ;
	long rc ;

	/* try to open path */
	if ( (rc = /*Fopen*/Fcreate(pc_path, /*FO_WRITE*/0)) < 0 )
	{
		/* try to create MIDIHANC.PC */
		if ( (rc = Fcreate(pc_path, 0 /* ordinary file */)) < 0 ) { 
			my_alert_str(NOT_CREATED, pc_path) ; 
			return ;
		}
	}
	handle = (int)rc ;
		
	/* save program change mapping data */
	pc_data_from_window() ;
	if ( Fwrite(handle, sizeof(pc_data), pc_data) < 0 )
		my_alert_str(WRITE_ERROR, pc_path) ; 
	/* close file */
	Fclose(handle) ;
}

static void test(void)
{
	/* find current box edit and send its MIDI string */
	unsigned i ;

	for (i = 0 ; i < MAX_PCS ; i++)
		if ( ACSblk->ev_window->ob_edit == PCS[i] ||
		     ACSblk->ev_window->ob_edit == PC_STRINGS[i] )
	{
		Aob_gettext(prog_chg_wi->work, PC_STRINGS[i], buff) ;
		MIDI_test_and_send(buff) ;
		break ;
	}
}


/********************************************************************
*
*         tuner 
*
********************************************************************/

static int DISTANCES[MAX_PITCHES] =
{
	DISTANCE0, DISTANCE1, DISTANCE2, DISTANCE3, DISTANCE4, DISTANCE5, 
	DISTANCE6, DISTANCE7, DISTANCE8, DISTANCE9, DISTANCE10,DISTANCE11
} ;

static int table_texts[MAX_TABLES] = 
	{ BOXEDIT_TABLE0, BOXEDIT_TABLE1, BOXEDIT_TABLE2, BOXEDIT_TABLE3 } ;

static int tables[MAX_TABLES] = { TUNER_TABLE0, TUNER_TABLE1, TUNER_TABLE2, TUNER_TABLE3 } ;


static char * slider_live(void *tuner_work, long pos) ;

UBYTE get_test_channel(void)
{
	char *s ;
	Auo_cycle(tuner_wi->work + CYCLE_BUTTON, AUO_GETVAL, &s) ;
	return (UBYTE)atoi(s) ;
}

static void cycle_click()
  /* test channel was changed */
{
	switch_notes(FALSE) ; /* notes off on old channel */
	Aus_cycle() ;
}


static char * slider_live(void *wi, long pos)
{
	static char text[ SLIDER_MAXCHARS + 1 ] ;
	int cent = (int)(pos - PB_HALF_RANGE) ;
	int pitch       = cent_to_pb(cent) ;
	int scale_tune  = cent + MEAN_STUNE ;
	
	tune.pitches[tune.table][pitch_index] = cent ;

	scale_tune = min(MAX_STUNE, scale_tune) ;
	scale_tune = max(MIN_STUNE, scale_tune) ;
	
	/* range is 0x0000 .. 0x3fff */
	Aob_printf  (((Awindow*)wi)->work, PITCH_BEND_DISPLAY, "%X", pitch) ; 
	Awi_obchange(wi, PITCH_BEND_DISPLAY, -1) ;

	/* range is -64 .. +63 cent */
	Aob_printf  (((Awindow*)wi)->work, SCALE_TUNE_DISPLAY, "%i", scale_tune - MEAN_STUNE) ;
	Awi_obchange(wi, SCALE_TUNE_DISPLAY, -1) ;

	/* (fitting text is empty, if pitch_index has no fitting entry) */	
	Aob_puttext (((Awindow*)wi)->work, FIT, (char*)get_fitting_text(cent)) ;
	Awi_obchange(wi, FIT, -1) ;

	send_tuning() ;

	sprintf(text, "%i cent", cent) ;
	return text ;
}


static void update_pitch(void)
{
	/* make displays consistent with current table and pitch index */
	long sl_pos = tune.pitches[tune.table][pitch_index] + PB_HALF_RANGE ;
	Auo_slider(tuner_wi->work + SLIDER, AUO_POS, &sl_pos) ;     /* set position */
	Auo_slider(tuner_wi->work + SLIDER, AUO_SLLIVE, NULL) ;     /* refresh text and displays */
	Auo_slider(tuner_wi->work + SLIDER, AUO_FULLUPDATE, NULL) ; /* redisplay */
}


static int pitch_display[] = { 
	PITCH_BEND_DISPLAY,
	SCALE_TUNE_DISPLAY,
	FIT,
	SLIDER,
	0	/* termination */
} ;


static void enable_pitch_displays(void)
{
	int i = 0 ;
	while( pitch_display[i] )
	{
		Awi_obchange(tuner_wi, pitch_display[i], 
			tuner_wi->work[pitch_display[i]].ob_state & ~DISABLED) ;
		i++ ;
	}
	tuner_wi->work[NEXT_FIT].ob_state &= ~DISABLED ;
	tuner_wi->work[PREV_FIT].ob_state &= ~DISABLED ;
	Awi_obchange(tuner_wi, NEXT_FIT, -1) ;
	Awi_obchange(tuner_wi, PREV_FIT, -1) ;
}


static void disable_pitch_displays(void)
{
	int i = 0 ;
	while( pitch_display[i] )
	{
		Awi_obchange(tuner_wi, pitch_display[i], 
			tuner_wi->work[pitch_display[i]].ob_state | DISABLED) ;
		i++ ;
	}
	tuner_wi->work[NEXT_FIT].ob_state |= DISABLED ;
	tuner_wi->work[PREV_FIT].ob_state |= DISABLED ;
	Awi_obchange(tuner_wi, NEXT_FIT, -1) ;
	Awi_obchange(tuner_wi, PREV_FIT, -1) ;
}


static void select_distance_0(void)
{
	if (pitch_index)
	{
		tuner_wi->work[DISTANCES[pitch_index]].ob_state &= ~SELECTED ;
		tuner_wi->work[DISTANCES[          0]].ob_state |= SELECTED ;
		Awi_obchange(tuner_wi, DISTANCES[pitch_index], -1) ;
		Awi_obchange(tuner_wi, DISTANCES[          0], -1) ;
		switch_notes(FALSE) ; /* notes off */
		/* Set equal scale tune, because nasty to correct
		   with synthesizer. Pitch bend not so critical, can
		   be corrected with one touch of the pitch bend wheel. */
	}
	scale_tune_init() ;
	scale_tune_send_all() ;
}


static void distance(void)
{
	/* previous notes off */
	if (pitch_index) switch_notes(FALSE) ;

	/* which key is pressed ? */
	for (pitch_index = 0 ; pitch_index < MAX_PITCHES ; pitch_index++) 
		if (ACSblk->ev_obnr == DISTANCES[pitch_index]) break ;
	
	/* copy pitch to enabled pitch displays or disable pitch display */
	if (pitch_index) 
	{
		enable_pitch_displays() ;
		update_pitch() ;
		switch_notes(TRUE) ; /* notes on */
	}
	else 
	{
		disable_pitch_displays() ;
		update_pitch() ;
	}
}


static void hide_splitter_mixer(void)
{
	/* mixer/splitter invisible, 16 connections */
	controller_wi->work[MIXER   ].ob_flags |= HIDETREE ;
	controller_wi->work[SPLITTER].ob_flags |= HIDETREE ;
	/* Awi_obchange() to weak on ST Emu */
	Awi_obredraw(controller_wi, MIXER_BACKGROUND   ) ;
	Awi_obredraw(controller_wi, SPLITTER_BACKGROUND) ;
}


static void show_splitter_mixer(void)
{
	/* mixer/splitter visible, 1 connection */
	controller_wi->work[MIXER   ].ob_flags &= ~HIDETREE ;
	controller_wi->work[SPLITTER].ob_flags &= ~HIDETREE ;
	/* Awi_obchange() to weak on ST Emu */
	Awi_obredraw(controller_wi, MIXER_BACKGROUND   ) ;
	Awi_obredraw(controller_wi, SPLITTER_BACKGROUND) ;
}


static void tuner_to_controller(void)
{
	if ( tuner_wi->work[TUNE_SCALE].ob_state & SELECTED )
	{
	     hide_out_arrows() ;
	     hide_splitter_mixer() ;
	}
	else if ( !(controller_wi->work[MODE_THROUGH].ob_state & SELECTED) )
	{
		show_out_arrows() ;
		show_splitter_mixer() ;
	}
}

static void tune_mode(void)
	/* radio button was pressed */
{
	switch_notes(FALSE) ; /* notes off */

	switch(ACSblk->ev_obnr)
	{
	case TUNE_SCALE: 
		tune.mode = SCALE_TUNE; 
		/* cleanup pitch bend relicts */
		pitch_bend_all(MEAN_PITCH) ;
		break ;
		
	default: 
		tune.mode = PITCH_BND ; 
		/* cleanup scale tune relicts */
		scale_tune_set_equal_cent(0) ;
		scale_tune_send_all() ;
	}
	tuner_to_controller() ;
}


static void disable_tables(void)
{
	int i ;
	for ( i = 0 ; i < MAX_TABLES ; i++ )
	{
		tuner_wi->work[tables[i]].ob_state |= DISABLED ;
		Awi_obchange(tuner_wi, tables[i], -1) ;
	}
}


static void enable_tables(void)
{
	int i ;
	for ( i = 0 ; i < MAX_TABLES ; i++ )
	{
		tuner_wi->work[tables[i]].ob_state &= ~DISABLED ;
		Awi_obchange(tuner_wi, tables[i], -1) ;
	}
}


static void tuner_table(void)
{
	int i ;
	if (pitch_index) switch_notes(FALSE) ; /* notes off */

	/* get current table index */
 	for (i = 0 ; i < MAX_TABLES ; i++) 
 		if (ACSblk->ev_obnr == tables[i]) 
 	{
		update_table(i) ; 
 		break ;
 	}
 	update_pitch() ;

	if (pitch_index) switch_notes(TRUE) ; /* notes on */
}


static void prev_fit(void)
{
	/* update value and redisplay */
	goto_prev_fit() ;
	update_pitch() ;
}


static void next_fit(void)
{
	/* update value and redisplay */
	goto_next_fit() ;
	update_pitch() ;
}


static void make_txt_path(char *path)
{
	if ( ! strrchr(path, '.') ) strcat(path, ".txt") ;
}


static void export(void)
{
	char *whole_path ;
	char title[20] ;
	FILE *export_file ;
	unsigned i ;
	
	sprintf(title, "Export table %i to:", tune.table) ;
	fsl_set_masks("*.txt\0") ;
	whole_path = fsl_do(title) ;
	if ( !whole_path )
		return ;
	make_txt_path(whole_path) ;
	
	if ( export_file = fopen(whole_path, "w") )
	{
		for (i = 0 ; i < MAX_PITCHES ; i++)
			fprintf(export_file, "%i, ", tune.pitches[tune.table][i]) ;
		Aob_gettext(tuner_wi->work, table_texts[tune.table], buff ) ;
		fprintf(export_file, "%s\n", buff) ;
		fclose(export_file) ;
	}
}


#define _STRING_(var) #var /* 1234 => "1234" */

static void do_import_table(const char * whole_path, int ti)
	/* import from path to table with index ti */
{
	int  i, pt[MAX_PITCHES] ;               /* imported pitches */
	char name[TABLE_TEXT_MAXCHARS+1] ;      /* imported table name */

	FILE *import_file = fopen(whole_path, "r") ;
	if (import_file) while (1)
	{
		switch ( 
			fscanf(import_file, 
		    "%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i,%i, "
		    "%"_STRING_(TABLE_TEXT_MAXCHARS)"[^\n]",
		    pt,pt+1,pt+2,pt+3,pt+4,pt+5,pt+6,pt+7,pt+8,pt+9,pt+10,pt+11,
		    name ) )
		{
		case 12:
			/* format OK, but table name not specified */
			*name = 0 ;
		case 13:
			/* format OK ! */
			if (ti == tune.table && pitch_index) 
				switch_notes(FALSE) ; /* notes off */
				
			for (i = 0 ; i < MAX_PITCHES ; i++)
				tune.pitches[ti][i] = max(min(PB_HALF_RANGE,pt[i]),-PB_HALF_RANGE) ;
				
			Aob_puttext(tuner_wi->work, table_texts[ti], name) ;
			Auo_boxed (tuner_wi->work + table_texts[ti], AUO_FULLUPDATE, NULL) ;
			fclose(import_file) ; 
			
			if (ti == tune.table && pitch_index)
			{
				update_pitch() ;
				switch_notes(TRUE) ; /* notes on with new pitch */
			}
			return ;
		case EOF:
			fclose(import_file) ;
			{
				/* display error message */
				const char *fname = strrchr(whole_path, '\\') ;
				if (!fname) 
				     fname = whole_path ;
				else fname++ ;
				my_alert_str(NO_TABLE_FOUND, fname) ;
			}
			return ;
		}
		/* ignore rest till and including end of line char. */
		fscanf(import_file, "%*[^\n]%*c") ;	
	}
}


static void import(void)
{
	char *whole_path ;
	char title[20] ;

	/* open file selector */	
	sprintf(title, "Import table %i from:", tune.table) ;
	fsl_set_masks("*.txt\0") ;
	whole_path = fsl_do(title) ;
	if ( !whole_path )
		return ;

	make_txt_path (whole_path) ;
	do_import_table(whole_path, tune.table) ;
}


static void tuner_init(void)
{
	int i ;
	/* copy data into GEM objects */
	tuner_wi->work[TUNE_SCALE     ].ob_state &= ~SELECTED ;
	tuner_wi->work[TUNE_PITCH_BEND].ob_state &= ~SELECTED ;
	if ( tune.mode == SCALE_TUNE )
	     tuner_wi->work[TUNE_SCALE     ].ob_state |= SELECTED ;
	else tuner_wi->work[TUNE_PITCH_BEND].ob_state |= SELECTED ;

	for (i = 0; i < MAX_TABLES; i++)
	{
		if (i == tune.table)
		     tuner_wi->work[tables[i]].ob_state |= SELECTED ;
		else tuner_wi->work[tables[i]].ob_state &= ~SELECTED ;

		/* must be 0 cent, is used by distance 0 */
		tune.pitches[i][0] = 0 ;
	}

	/* correct slider value (ACS inits: "3") */
	update_pitch() ;
	
	/* update controller appearance */
	tuner_to_controller() ;
}


static void tuner_init0(void)
	/* needs to be called once at program start */
{
	/* slider */
	long big_step   = PB_HALF_RANGE / 10 ; /* 20 steps in total */
	long full_range = 2 * PB_HALF_RANGE + big_step ;
	INT16 text_len = SLIDER_MAXCHARS ;
	SLLIVE sllive ;
	sllive.call = slider_live ;
	sllive.obj  = (void *)tuner_wi ;
	Auo_slider(tuner_wi->work + SLIDER, AUO_SLCALL, &sllive) ;
	Auo_slider(tuner_wi->work + SLIDER, AUO_SLFULL, &full_range) ;
	Auo_slider(tuner_wi->work + SLIDER, AUO_SLSIZE, &big_step) ;
	Auo_slider(tuner_wi->work + SLIDER, AUO_SLLEN , &text_len) ;

	scale_tune_init() ;
	
	/* default search path for tables */
	sprintf(buff, "%stables\\", ACSblk->apppath) ;
	fsl_add_path(buff) ;
	
	/* make consistent with fix coded defaults */
	tuner_init() ;
}


/********************************************************************
*
*         strings
*
********************************************************************/

static void on_enter_pb()
{
	Aob_gettext(string_wi->work, BOXEDIT_ENTER_PB, buff) ;
	MIDI_test_and_send(buff) ;
}

static void on_exit_pb()
{
	Aob_gettext(string_wi->work, BOXEDIT_EXIT_PB, buff) ;
	MIDI_test_and_send(buff) ;
}

static void on_enter_stune()
{
	Aob_gettext(string_wi->work, BOXEDIT_ENTER_STUNE, buff) ;
	MIDI_test_and_send(buff) ;
}

static void on_exit_stune()
{
	Aob_gettext(string_wi->work, BOXEDIT_EXIT_STUNE, buff) ;
	MIDI_test_and_send(buff) ;
}

/********************************************************************
*
*         controller 
*
********************************************************************/

/*--- input arrows ---*/

static int IN_ARROWS[16] =
{
	IN_ARROW0, IN_ARROW1, IN_ARROW2, IN_ARROW3, IN_ARROW4, IN_ARROW5, IN_ARROW6, IN_ARROW7, 
	IN_ARROW8, IN_ARROW9, IN_ARROW10,IN_ARROW11,IN_ARROW12,IN_ARROW13,IN_ARROW14,IN_ARROW15
} ;

static int IN_CARRIERS[16] =
{
	IN0, IN1, IN2, IN3, IN4, IN5, IN6, IN7, 
	IN8, IN9, IN10,IN11,IN12,IN13,IN14,IN15
} ;

static void hide_in_arrows (void) 
{
	int i ;
	for (i = 0 ; i < 16 ; i++) 
		controller_wi->work[IN_CARRIERS[i]].ob_flags |= HIDETREE ; 
}

static void show_in_arrows (void) 
{
	int i ;
	for (i = 0 ; i < 16 ; i++) 
		controller_wi->work[IN_CARRIERS[i]].ob_flags &= ~HIDETREE ; 
}

static void in_click(void)
{
int i,j ;

	ACSblk->ev_object[ACSblk->ev_object[ACSblk->ev_obnr].ob_head].ob_flags ^= HIDETREE ;
	Awi_obchange(ACSblk->ev_window, ACSblk->ev_obnr, -1) ;
	for (i = 0 ; i < 16 ; i++) 
	{
		j = 0x0001 << i ;
		if (ACSblk->ev_object[ACSblk->ev_obnr].ob_head == IN_ARROWS[i]) 
			control.input_channels ^= j ;
	}
}

/*--- output arrows ---*/

static int OUT_ARROWS[16] =
{
	OUT_ARROW0, OUT_ARROW1, OUT_ARROW2, OUT_ARROW3, OUT_ARROW4, OUT_ARROW5, OUT_ARROW6, OUT_ARROW7, 
	OUT_ARROW8, OUT_ARROW9, OUT_ARROW10,OUT_ARROW11,OUT_ARROW12,OUT_ARROW13,OUT_ARROW14,OUT_ARROW15
} ;

static int OUT_CARRIERS[16] =
{
	OUT0, OUT1, OUT2, OUT3, OUT4, OUT5, OUT6, OUT7, 
	OUT8, OUT9, OUT10,OUT11,OUT12,OUT13,OUT14,OUT15
} ;

static void hide_out_arrows(void) 
{
	int i ;
	for (i = 0 ; i < 16 ; i++) 
		controller_wi->work[OUT_CARRIERS[i]].ob_flags |= HIDETREE ; 
}

static void show_out_arrows(void) 
{
	int i ;
	for (i = 0 ; i < 16 ; i++) 
		controller_wi->work[OUT_CARRIERS[i]].ob_flags &= ~HIDETREE ; 
}

static void out_click(void)
{
	int i,j ;

	ACSblk->ev_object[ACSblk->ev_object[ACSblk->ev_obnr].ob_head].ob_flags ^= HIDETREE ;
	Awi_obchange(ACSblk->ev_window, ACSblk->ev_obnr, -1) ;
	for (i = 0 ; i < 16 ; i++) 
	{
		j = 0x0001 << i ;
		if (ACSblk->ev_object[ACSblk->ev_obnr].ob_head == OUT_ARROWS[i]) 
			control.output_channels ^= j ;
	}
}

/*--- harmonizer radio buttons ---*/

static int last_index = 9 ; /* GM drum channel */

static int HARMONIZERS[16] =
{
	HARMONIZER0, HARMONIZER1, HARMONIZER2, HARMONIZER3, HARMONIZER4, HARMONIZER5, HARMONIZER6, HARMONIZER7, 
	HARMONIZER8, HARMONIZER9, HARMONIZER10,HARMONIZER11,HARMONIZER12,HARMONIZER13,HARMONIZER14,HARMONIZER15
} ;

static void harmonizer_click(void)
{
	int i ;
	for (i = 0 ; i < 16 ; i++) 
		if ( ACSblk->ev_obnr == HARMONIZERS[i] )
	{
		control.harmonizing_channel = 1 << i ;
		
		/* disable previous radio button, parents are different ! */
		ACSblk->ev_object[HARMONIZERS[last_index]].ob_state &= ~SELECTED ;
		Awi_obchange(ACSblk->ev_window, HARMONIZERS[last_index], -1) ;
		last_index = i ;

		return ;
	}
}


/*--- common ---*/

static int mixer_splitter_background(PARMBLK *parmblk)
{
	int points[4] ;
	int i, dy = parmblk->pb_h / 16 ;

	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	vswr_mode(handle, MD_REPLACE) ;

	/* draw outer and inner rectangles */
	points[0] = parmblk->pb_x ;	
	points[1] = parmblk->pb_y ;	
	points[2] = parmblk->pb_x + parmblk->pb_w - 1 ;
	points[3] = parmblk->pb_y + parmblk->pb_h - 1 ;	
	vsf_interior (handle, FIS_PATTERN) ;
	vsf_style    (handle, 4) ;
	vsf_color    (handle, LWHITE) ;
	vsf_perimeter(handle, FALSE) ;
	vr_recfl     (handle, points) ;

	vsl_color(handle, BLACK) ;
	vsl_type (handle, SOLID) ;
	if ( tune.mode == SCALE_TUNE || control.mode & THROUGH )
	{
		/* 16 connections */
		for (i = 0 ; i < 16 ; i++)
		{
			points[1] = points[3] = 
				parmblk->pb_y + dy * i + dy / 2 ;
			v_pline(handle, 2, points) ;			
		}	
	}
	else
	{
		/* a single connection */
		points[1] = points[3] = parmblk->pb_y + parmblk->pb_h / 2 ;
		v_pline(handle, 2, points) ;
	}

	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	return(parmblk->pb_currstate) ;          
}

static int cdecl mixer_background(PARMBLK *parmblk)
{
	return mixer_splitter_background(parmblk) ;
}

static int cdecl splitter_background(PARMBLK *parmblk)
{
	return mixer_splitter_background(parmblk) ;
}


static void controller_init(void)
{
	INT16 i,j ;
	/* copy data into GEM objects */
	for (i = 0 ; i < 16 ; i++) /* init radio buttons 0..15 */
	{
		j = 0x0001 << i ; /* channel mask */
		if ( j & control.harmonizing_channel ) 
		{
			controller_wi->work[HARMONIZERS[i]].ob_state |= SELECTED ;
			last_index = i ;
		}
		else controller_wi->work[HARMONIZERS[i]].ob_state &= ~SELECTED ;

		if (!( j & control.input_channels  )) 
			controller_wi->work[IN_ARROWS[i] ].ob_flags |= HIDETREE ;
		if (!( j & control.output_channels )) 
			controller_wi->work[OUT_ARROWS[i]].ob_flags |= HIDETREE ;
	}
	if (control.mode & HOLD) 
	     controller_wi->work[MODE_HOLD].ob_state |= SELECTED ;
	else controller_wi->work[MODE_HOLD].ob_state &= ~SELECTED ;
	if (control.mode & THROUGH) 
	     controller_wi->work[MODE_THROUGH].ob_state |= SELECTED ;
	else controller_wi->work[MODE_THROUGH].ob_state &= ~SELECTED ;
	if (control.mode & AUTOMATIC) 
	     controller_wi->work[MODE_AUTOMATIC].ob_state |= SELECTED ;
	else controller_wi->work[MODE_AUTOMATIC].ob_state &= ~SELECTED ;
	if (control.mode & AUTO_START) 
	     controller_wi->work[MODE_AUTO_START].ob_state |= SELECTED ;
	else controller_wi->work[MODE_AUTO_START].ob_state &= ~SELECTED ;
	through() ;	/* disable/enable consistently */

	Auo_cycle(controller_wi->work + SMOOTHING, AUO_CYCINDEX, &(control.smoothing)) ;
}
	

static void hold(void)
{
	update_hold(controller_wi->work[MODE_HOLD].ob_state & SELECTED) ; 
}


static void automatic(void)
{
	if (controller_wi->work[MODE_AUTOMATIC].ob_state & SELECTED) 
	{
		control.mode |= AUTOMATIC ;
		/* disabled checkbox looks ugly in ACS 2.3 => hide it */
		controller_wi->work[MODE_HOLD].ob_flags |= HIDETREE ;
		controller_wi->work[SMOOTHING].ob_state &= ~DISABLED ;
	}
	else 
	{
		control.mode &= ~AUTOMATIC ;
		controller_wi->work[MODE_HOLD].ob_flags &= ~HIDETREE ;
		controller_wi->work[SMOOTHING].ob_state |= DISABLED ;
	}
/*	Awi_obchange(controller_wi, MODE_HOLD, -1) ;
	Awi_obchange(controller_wi, SMOOTHING, -1) ;*/
	Awi_obchange(controller_wi, HARMONIZER,-1) ;
}

static void through(void)
{
	if (controller_wi->work[MODE_THROUGH].ob_state & SELECTED) 
	{
		control.mode |= THROUGH ;
/*		controller_wi->state |= AWS_LATEUPDATE ;*/
		controller_wi->work[MODE_AUTOMATIC].ob_flags |= HIDETREE ;
		controller_wi->work[MODE_HOLD     ].ob_flags |= HIDETREE ;
		controller_wi->work[KEY           ].ob_state |= DISABLED ;
		controller_wi->work[SMOOTHING     ].ob_state |= DISABLED ;
		controller_wi->work[H_ARROW       ].ob_flags |= HIDETREE ;
		Awi_obchange(controller_wi, HARMONIZER    , -1) ;
		Awi_obchange(controller_wi, H_CARRIER     , -1) ;
		/* repair also line corrupted by H_CARRIER: */
		Awi_obchange(controller_wi, H_LINE        , -1) ;
		/* repair now label corrupted by H_LINE: */
		Awi_obchange(controller_wi, MIDI_IN_LABEL , -1) ;

		hide_in_arrows() ;
		hide_out_arrows() ;
		hide_splitter_mixer() ;
	}
	else 
	{
		control.mode &= ~THROUGH ;
/*		controller_wi->state &= ~AWS_LATEUPDATE ;*/
		controller_wi->work[MODE_AUTOMATIC].ob_flags &= ~HIDETREE ;
		controller_wi->work[MODE_HOLD     ].ob_flags &= ~HIDETREE ;
		controller_wi->work[KEY           ].ob_state &= ~DISABLED ;
		controller_wi->work[SMOOTHING     ].ob_state &= ~DISABLED ;
		controller_wi->work[H_ARROW       ].ob_flags &= ~HIDETREE ;
		Awi_obchange(controller_wi, H_CARRIER     , -1) ;
		/* repair also line corrupted by H_CARRIER: */
		Awi_obchange(controller_wi, H_LINE        , -1) ;
		/* repair now label corrupted by H_LINE: */
		Awi_obchange(controller_wi, MIDI_IN_LABEL , -1) ;
		/* the others are redrawn by automatic() and tuner_to_controller() */

		if (control.mode & AUTOMATIC) 
		     controller_wi->work[MODE_AUTOMATIC].ob_state |= SELECTED ;
		else controller_wi->work[MODE_AUTOMATIC].ob_state &= ~SELECTED ;
		automatic() ;
		show_in_arrows() ;
		tuner_to_controller() ;
	}
}

static void auto_start(void)
{
	if (controller_wi->work[MODE_AUTO_START].ob_state & SELECTED) control.mode |= AUTO_START ;
	else control.mode &= ~AUTO_START ;
}

static void start(void)
{
	INT16 i, message ; 
	int last_table = tune.table ;

	harmonizing_note = INVALID ;
	pitch_offset = 0 ;
	error_text = NULL ;
	
	/* get smoothing time */
	Auo_cycle( controller_wi->work + SMOOTHING, AUO_CYCGETINDEX, &i ) ;
	update_smoothing(i) ; 

	/* get program change mapping data */
	pc_data_from_window() ;

	if (control.mode & AUTOMATIC)
		disable_tables(); /* visualize: table is fix coded, not from tuner */
	select_distance_0() ; /* switch off tuner */

    /* send MIDI string */
	if ( tune.mode == PITCH_BND )
	     on_enter_pb() ;
	else on_enter_stune() ;
		
	while ( message = event_handler(), message != KEY_PRESSED ) 
	  switch (message) 
	{
	case TABLE_CHANGED:	
		if (tuner_wi->wi_id != -1) 
		{
			/* window is not iconified */
			i = tables[last_table] ;
			Awi_obchange(tuner_wi, i, tuner_wi->work[i].ob_state & ~SELECTED) ; 
			i = tables[tune.table] ;
			Awi_obchange(tuner_wi, i, tuner_wi->work[i].ob_state | SELECTED) ; 
		}
		last_table = tune.table ;
		break ;
	case KEY_CHANGED:
	case TIME_CHANGED:	
	case INITIALIZED:
		switch (message)
		{
		case KEY_CHANGED:
			if (control.key == INVALID) 
			     i = 0 ;
			else i = min(control.key, 0xB) + 1 ;
	 		Auo_cycle( controller_wi->work + KEY, AUO_CYCINDEX, &i ) ;
			Awi_obchange(controller_wi, KEY, -1) ; 
			break ;
		case TIME_CHANGED:
			i = min(control.smoothing, 9) ;
			Auo_cycle( controller_wi->work + SMOOTHING, AUO_CYCINDEX, &i) ;
    		Awi_obchange(controller_wi, SMOOTHING, -1) ;
    		break ;
    	case INITIALIZED:
			/* get key */
			Auo_cycle( controller_wi->work + KEY, AUO_CYCGETINDEX, &i ) ;
			update_key(i - 1) ;
			/* update_key() changes h. note in hold mode, too */
			/* init monitor window */
			Aob_puttext (monitor_wi->work, ERROR_TEXT       , "") ;
			Awi_obchange(monitor_wi, ERROR_TEXT       , -1) ;
			monitor_wi->work[HARMONIZING_NOTE].ob_state &= ~DISABLED ;
			monitor_wi->work[PITCH_OFFSET    ].ob_state &= ~(SELECTED | DISABLED) ;
			break ;
	    }	
		Aob_puttext (monitor_wi->work, ERROR_TEXT, "") ;
		Awi_obchange(monitor_wi, ERROR_TEXT, -1) ;
	    /* no break, continue ! */
	case H_NOTE_CHANGED:
		if (monitor_wi->wi_id != -1) 
		{
			/* window is not iconified */
			if (harmonizing_note == INVALID) /* if invalid, display "-" */
				Aob_puttext(monitor_wi->work, HARMONIZING_NOTE, "-") ;
			else Aob_printf(monitor_wi->work, HARMONIZING_NOTE, "%X", harmonizing_note % 12) ;
			Awi_obchange(monitor_wi, HARMONIZING_NOTE, -1) ;
			
			Aob_printf(monitor_wi->work, PITCH_OFFSET, "%d", pitch_offset) ;
		    /* if at least one interval out of range, show inverted or light red */
			if (critical_offset) 
			{
				if ( ACSblk->ncolors < RED + 1 )
					monitor_wi->work[PITCH_OFFSET].ob_state |= SELECTED ;
				te_color(monitor_wi->work + PITCH_OFFSET, RED) ;
			}
			else
			{
				if ( ACSblk->ncolors < RED + 1 )
					monitor_wi->work[PITCH_OFFSET].ob_state &= ~SELECTED ;
				te_color(monitor_wi->work + PITCH_OFFSET, LRED) ;
			}
			Awi_obchange(monitor_wi, PITCH_OFFSET, -1) ;
		}
		break ;
	case ERROR_OCCURRED:	/* report errors also if window is iconified */
		if (error_text) 
			strcpy(monitor_wi->work[ERROR_TEXT].ob_spec.tedinfo->te_ptext, error_text) ;
		Awi_obchange(monitor_wi, ERROR_TEXT, -1) ;
		break ;
	}
	exit_event_handler() ; /* cleanup MIDI out */

	/* send MIDI string */
	if ( tune.mode == PITCH_BND )
	     on_exit_pb() ;
	else on_exit_stune() ;

	if (control.mode & AUTOMATIC)
		enable_tables();
	
	Awi_obchange(monitor_wi, PITCH_OFFSET    , monitor_wi->work[PITCH_OFFSET    ].ob_state | DISABLED) ;
	Awi_obchange(monitor_wi, HARMONIZING_NOTE, monitor_wi->work[HARMONIZING_NOTE].ob_state | DISABLED) ;
}

static void do_start(void)
{
	/* simulate click on "start" button:
	   select button, busy mouse. */
	controller_wi->work[START].ob_state |= SELECTED ;
	Awi_obchange(controller_wi, START, -1) ;
	Amo_busy() ; 
	start() ;
	Amo_unbusy() ; 
	controller_wi->work[START].ob_state &= ~SELECTED ;
	Awi_obchange(controller_wi, START, -1) ;
}


/********************************************************************
*
*         constructors/destructors
*
********************************************************************/

typedef struct
{
	CONTROL	ctr ;
	TUNE    tun ;
	TEXTES	txt ;	/* belongs to tuner window */
	STRINGS str ;
}
PARAMS_FILE ;

static void save_params(void)
{
	PARAMS_FILE pf ;
	int i, handle ;
	long rc ;

	sprintf(buff, "%sMIDIHANC.PAR", ACSblk->cfg_path) ;

	/* try to open path */
	if ( (rc = /*Fopen*/Fcreate(buff, /*FO_WRITE*/0)) < 0 ) 
	{
		/* try to create *.PAR */
		if ( (rc = Fcreate(buff, 0 /* ordinary file */)) < 0 ) {
			my_alert_str(NOT_CREATED, buff) ; 
			return ;
		}
	}
	handle = (int)rc ;
	
	/* prepare structure for saving parameters */
	/* tuner */
	for (i = 0 ; i < MAX_TABLES ; i++) 
		Aob_gettext(tuner_wi->work, table_texts[i], pf.txt[i] ) ;
	memcpy(&pf.tun, &tune, sizeof(pf.tun)) ;
	/* controller */
	Aob_scanf(controller_wi->work, SMOOTHING, "%u", &(control.smoothing)) ;
	memcpy(&pf.ctr, &control, sizeof(pf.ctr)) ;
	/* enter / exit strings */
	Aob_gettext(string_wi->work, BOXEDIT_ENTER_PB   , pf.str.on_enter_pb   ) ;
	Aob_gettext(string_wi->work, BOXEDIT_EXIT_PB    , pf.str.on_exit_pb    ) ;
	Aob_gettext(string_wi->work, BOXEDIT_ENTER_STUNE, pf.str.on_enter_stune) ;
	Aob_gettext(string_wi->work, BOXEDIT_EXIT_STUNE , pf.str.on_exit_stune ) ;
	
	/* save structure */
	if ( Fwrite(handle, sizeof pf, &pf) < 0 ) 
		my_alert_str(WRITE_ERROR, buff) ; 

	/* close file */
	Fclose(handle) ;
}


static void load_params(int controller, int tuner, int strings)
{
	int i ;
	long filesize ;
	PARAMS_FILE *pf ;

	sprintf(buff, "%sMIDIHANC.PAR", ACSblk->cfg_path) ;

	/* load the parameter file into RAM */
	pf = load_file(buff, &filesize) ;
	if (pf)
	{ 
		/* file successfully loaded */
		if ( filesize == sizeof *pf ) 
		{
			/* copy file data into object data */
			if (controller) 
			{
				memcpy(&control, &pf->ctr, sizeof(pf->ctr)) ;
				controller_init() ;
				if (controller_wi->wi_id != -1)
					Awi_obchange(controller_wi, 1, -1) ;
			}
			if (tuner)
			{
				memcpy(&tune , &pf->tun, sizeof(pf->tun)) ;
				tuner_init() ;
				for (i = 0 ; i < MAX_TABLES ; i++)
					Aob_puttext(tuner_wi->work, table_texts[i], pf->txt[i]) ;
				if (tuner_wi->wi_id != -1)
					Awi_obchange(tuner_wi, 1, -1) ;
			}
			if (strings)
			{
				Aob_puttext(string_wi->work, BOXEDIT_ENTER_PB   , pf->str.on_enter_pb   ) ;
				Aob_puttext(string_wi->work, BOXEDIT_EXIT_PB    , pf->str.on_exit_pb    ) ;
				Aob_puttext(string_wi->work, BOXEDIT_ENTER_STUNE, pf->str.on_enter_stune) ;
				Aob_puttext(string_wi->work, BOXEDIT_EXIT_STUNE , pf->str.on_exit_stune ) ;
				Awi_obchange(string_wi, BOXEDIT_ENTER_PB   , -1) ;
				Awi_obchange(string_wi, BOXEDIT_EXIT_PB    , -1) ;
				Awi_obchange(string_wi, BOXEDIT_ENTER_STUNE, -1) ;
				Awi_obchange(string_wi, BOXEDIT_EXIT_STUNE , -1) ;
			}
		}
		else
			/* file was not created by MIDI Enhancer */ 
			my_alert_str(WRONG_FORMAT, buff) ; 
		unload_file(pf) ;
	}
	else my_alert_str(FILE_NOT_FOUND, buff) ; 
}

static void destructor(void)
{
	/* cleanup MIDI out */
	select_distance_0() ;
	
	/* save parameters to various files */
	save_params() ;
	volumes_exit() ;
	prog_chg_exit() ;
	
	delete_window(&controller_wi) ;
	delete_window(&tuner_wi) ;
	delete_window(&monitor_wi) ;
	delete_window(&string_wi) ;
	delete_window(&prog_chg_wi) ;
	delete_window(&volumes_wi) ;
}


static int constructor(void)
{
	/* create the controller window */
	if ( !(controller_wi = Awi_create(&CONTROLLER_WINDOW)) ) 
		{ destructor() ; return FAIL ; }
	
	/* create the tuner window */
	if ( !(tuner_wi = Awi_create(&TUNER_WINDOW)) ) 
		{ destructor() ; return FAIL ; }

	/* create the monitor window */
	if ( !(monitor_wi = Awi_create(&MONITOR_WINDOW)) ) 
		{ destructor() ; return FAIL ; }

	/* create the dynamics window */
	if ( !(volumes_wi = Awi_create(&VOLUMES_WINDOW)) ) 
		{ destructor() ; return FAIL ; }

	/* create the strings window */
	if ( !(string_wi = Awi_create(&STRING_WINDOW)) ) 
		{ destructor() ; return FAIL ; }

	/* create the program change mapper window */
	if ( !(prog_chg_wi = Awi_create(&PROGRAM_CHANGE_WINDOW)) ) 
		{ destructor() ; return FAIL ; }

	/* load parameters */
	tuner_init0() ;	/* slider, etc. */
	load_params(TRUE,TRUE,TRUE) ; 
	
	/* init routines */
	volumes_init() ;
	prog_chg_init() ;
	
	/* top left */
	tuner_wi->wi_act.x = 32 ; 
	tuner_wi->wi_act.y = 32 ; 

	/* more right and more bottom */
	controller_wi->wi_act.x = 200 ;
	controller_wi->wi_act.y = 150 ;

	if (control.mode & AUTO_START) 
	{
		Awi_open(tuner_wi) ;
		Awi_open(controller_wi) ; 
		do_start() ;
	}

	return OK ;
}


/********************************************************************
*
*         window routines
*
********************************************************************/

static void top_tuner     (void) { Awi_show(tuner_wi     ) ; } 
static void top_controller(void) { Awi_show(controller_wi) ; } 
static void top_pc        (void) { Awi_show(prog_chg_wi  ) ; } 
static void top_volumes   (void) { Awi_show(volumes_wi   ) ; } 
static void top_monitor   (void) { Awi_show(monitor_wi   ) ; } 
static void top_strings   (void) { Awi_show(string_wi    ) ; } 

static void help(void) 
{ 
	sprintf(buff, "%s%s", ACSblk->apppath, "MIDIHANC.TXT") ;
	A_help (buff, &HELP_ICON) ;
}

/*** appearance of controls ***/

static void controls_config(void)
{
	sprintf(buff, "%s%s", ACSblk->apppath, "CONFIG.AM") ;
	Ash_module(buff) ;
}

static void controls_dither(void)
{
	sprintf(buff, "%s%s", ACSblk->apppath, "DITHER.AM") ;
	Ash_module(buff) ;
}


/*******************************************************************
*/
	static int icons_vertical = TRUE ;
	static void vertical  (void) { icons_vertical=TRUE ; Awd_ver(); }
	static void horizontal(void) { icons_vertical=FALSE; Awd_hor(); }
/*
*   Arrange icons (and remember the mode in a global variable).
* 
*******************************************************************/


static void undo(void)
{
	INT16 wi_id, dummy ;
	
	/* find top window */
	wind_get( Awi_root()->wi_id, WF_TOP, &wi_id, &dummy, &dummy, &dummy) ;

	if (wi_id == tuner_wi->wi_id)
	{
		if (1 == my_alert_str(RELOAD_SETTINGS, "tuner settings"))
			load_params(FALSE,TRUE,FALSE) ;
	}		
	else if (wi_id == controller_wi->wi_id)
	{
		if (1 == my_alert_str(RELOAD_SETTINGS, "controller settings"))
			load_params(TRUE,FALSE,FALSE) ;
	}
	else if (wi_id == volumes_wi->wi_id)
	{
		if (1 == my_alert_str(RELOAD_SETTINGS, "volumes settings"))
			volumes_init() ;
	}
	else if (wi_id == string_wi->wi_id)
	{
		if (1 == my_alert_str(RELOAD_SETTINGS, "enter/exit strings"))
			load_params(FALSE,FALSE,TRUE) ;
	}
	else if (wi_id== prog_chg_wi->wi_id)
	{
		if (1 == my_alert_str(RELOAD_SETTINGS, "program change mapping"))
			prog_chg_init() ;
	}
}

/*static INT16 init( Awindow* wi )
  Does not work, since latency is much too high!
  /* to support MIDI through in the background */
{
	/* called if AWS_LATEUPDATE is set */
	if (control.mode & THROUGH)
	{
		while (midi_data_available) 
			midi_out(midi_in) ;
		/* keep on calling this procedure */
		wi->state |= AWS_LATEUPDATE ;
	}	
	return OK ;
}*/

static INT16 keys(Awindow *wi, int kstate, int key)
{
	switch (key & 0xFF)
	{
	case 0x0A: /* ENTER pressed */
	case 0x0D: /* RETURN pressed */ 
		if (wi != controller_wi) 
		{
			do_start() ;
			return -1 ;
		}
	}
	/* forward event to ACS for further treatment (e.g. by the desktop) */
	return Awi_keys(wi, kstate, key) ; 
	/*return -2 ;*/
}


static INT16 load_dragged_table(INT16 check_only, int ti) 
	/* load dragged file to table with index ti */
{
	Awindow *wi = ACSblk->ev_window ;
	Awindow *ori = ACSblk->Aselect.window ;
	INT16 obnr ;
	OBJECT  *obj  ;
	AOBJECT *aobj ;

	if (ACSblk->Aselect.actlen < 1)
		return FALSE ;
		
	Adr_start() ;
	for (obnr = Adr_next() ; obnr != -1 ; obnr = Adr_next())
	{
		obj = (obnr & A_TOOLBAR ? &ori->toolbar[obnr & A_MASK] : &ori->work[obnr]) ;
		aobj = (!(obj[0].ob_flags & LASTOB) && obj[1].ob_flags & AEO ? (AOBJECT *)&obj[1] : NULL) ;
		
		if (aobj && aobj->type == AT_FILE)
		{
			char *file = aobj->userp1 ;
/*			char *dot = strrchr(file, '.') ;
			if (dot && 
				!strnicmp(dot + 1, scheme_file_extension, strlen(scheme_file_extension)))*/
			{
				if (!check_only)
				{
					if (ti < 0)
						/* should never be the case here */
						return FALSE ;
					do_import_table(file, ti) ;
					Adr_del(ori, obnr) ;
				}
				return TRUE ;
			}
		}
	}
	return FALSE ;
}


static void table_drag(void)
{
	int ti = 0 ; 
	
	switch (ACSblk->ev_obnr)
	{
	case BOXEDIT_TABLE0: ti = 0 ; break ;
	case BOXEDIT_TABLE1: ti = 1 ; break ;
	case BOXEDIT_TABLE2: ti = 2 ; break ;
	case BOXEDIT_TABLE3: ti = 3 ; break ;
	}
	
	load_dragged_table(FALSE, ti) ;
}


static INT16 service(Awindow *wi, int task, void *in_out)
	/* service procedure for all windows */
{
	switch (task)
	{
	case AS_TERM: 
		if (ACSblk->appexit)
		{
			if (wi == controller_wi)
				/* call destructor only once, not for all windows */
				destructor() ;
		}
		return TRUE ; 
	case AS_CHECKDRAG:
		/*form_alert( 1, "[1][AS_CHECKDRAG received.][OK]" );*/
		*((INT16 *)in_out) = load_dragged_table(TRUE/* check only */, -1) ;
		return TRUE ;
	/*case AS_DRAGGED:
		return load_dragged_table(FALSE) ; done be scheme_drag() */
	default: 
		return Awi_service(wi, task, in_out) ; /* treats iconify etc. */
	}
}


/********************************************************************
*
*         ACS routines
*
********************************************************************/


static void aboutme(void) { A_dialog(&ABOUT_ME) ; }


static void my_close(void)
	/* user desires to quit */
{ /*	if (my_alert_str(QUIT_ALL, "") == 1) */ Aev_quit() ; }


static void my_term(void) 
{ 
	/* clean up */ 
	fsl_cleanup() ;
}	


int my_init(void)
{
	handle = ACSblk->vdi_handle ;
	return constructor() ;
}


int my_init0(void)
{
	/* adjust dither mode */
	ACSblk->dither = 0x80/* white text backgr.*/ 
		| (IP_4PATT << 4) | BLACK ;
		
	if ( ACSblk->multitask && ACSblk->application )
	{
		/* replace desktop menu */
		PUR_DESK.menu = &MENU_MULTITASK ;
		ACSdescr.root = &PUR_DESK ; /* see MIDIHANC.AH */

		/* replace window titles */
		PUR_DESK.name = " Mad Harry's MIDI Enhancer " ;
		PUR_MODULE.name = "Windows" ;
	}
	else
	{
	    ACSdescr.root = &DESKTOP ;

		/* replace desktop background object */
		if ( ACSblk->application )
		{
			/* replace desktop menu */
			DESKTOP.menu  = &MENU_SINGLETASK ;

			_01_BACKGND_2.ob_width  = _01_BACKGND_16.ob_width  = ACSblk->desk.w ;
			_01_BACKGND_2.ob_height = _01_BACKGND_16.ob_height = ACSblk->desk.h ;
		}
		else
		{
			/* accessory */
			
			/* replace desktop menu */
			DESKTOP.menu  = &MENU_ACCESSORY ;

			_01_BACKGND_2.ob_width  = _01_BACKGND_16.ob_width  = ACSblk->desk.w/2 ;
			_01_BACKGND_2.ob_height = _01_BACKGND_16.ob_height = ACSblk->desk.h/2 ;
		}
		if ( ACSblk->ncolors < 16 ) 
			DESKTOP.service(NULL, AS_BACKOBJECT, &_01_BACKGND_2) ;
		else if ( ACSblk->nplanes <= 8 )
			/* avoid terrible red background object on Falcon in true color mode */
			DESKTOP.service(NULL, AS_BACKOBJECT, &_01_BACKGND_16) ;

		/* replace "trash" icon */
		/* DESKTOP.service(NULL, AS_ICONTRASH, &NO_ICON) ; */
		DESKTOP.service(NULL, AS_ICONTRASH, &TRASH_ICON) ;

		/* replace window title */
		DESKTOP.name = " Mad Harry's MIDI Enhancer " ;
	}

	/* always OK */
	return OK ;
}
