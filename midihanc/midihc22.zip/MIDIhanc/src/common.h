#if defined (__PALM__)
#  include "resource.h"
#else
/* must fit to size of ACS boxedits ! */
#  define SLIDER_MAXCHARS                 10 /* "-100 cent" */ 
#  define TABLE_TEXT_MAXCHARS             50 
#  define MIDI_STRING_MAXCHARS           255 
#endif


/********************************************************************
*
*         auxiliary functions / data
*
********************************************************************/

#define TEXTBUFF_STRLEN 1023
extern char buff[ TEXTBUFF_STRLEN + 1 ] ;
  /* common buffer for GUI updates, ... */

void pitch_bend_all(int value) ;
  /* sends pitch bend value on all 16 MIDI channels */

void cleanup_pitches(void) ;
  /* reset all scale tune values and pitch bend values to normal */
  /* (sends to MIDI out) */


/********************************************************************
*
*         strings
*
********************************************************************/

typedef struct {
	char on_enter_pb   [MIDI_STRING_MAXCHARS+1] ;
	char on_exit_pb    [MIDI_STRING_MAXCHARS+1] ;
	char on_enter_stune[MIDI_STRING_MAXCHARS+1] ;
	char on_exit_stune [MIDI_STRING_MAXCHARS+1] ;
} STRINGS ;
extern STRINGS strings ;
  /* sent by the controller, not the event handler */

void send_enter_string(void) ;
  /* sends to MIDI out, either on_enter_pb or on_enter_stune */
  /* string must be OK, otherwise nothing is send */
void send_exit_string(void) ;
  /* sends to MIDI out, either on_exit_pb or on_exit_stune */
  /* string must be OK, otherwise nothing is send */


/********************************************************************
*
*         velocities (volumes) modifier
*
********************************************************************/

void set_volumes_all(char value) ;
  /* sets all volumes to the same value */

void transform_volumes(void) ;
  /* forwards all MIDI events to the output 
     - as long as any are available on the input -
     note on volumes are transformed */

typedef char TEXTES[MAX_TABLES][TABLE_TEXT_MAXCHARS+1] ; 
  /* not needed by event handler, only for user interface */

/********************************************************************
*
*         program change mapper
*
********************************************************************/

void set_pcs_all(char value) ;

/********************************************************************
*
*         tuner 
*
********************************************************************/

extern int pitch_index ;    /* current interval to tune */
#define BASE_NOTE    0x3C   /* lower note of the interval to tune */

void goto_prev_fit(void) ;
  /* set tune.pitches[tune.table][pitch_index] to previous fit out
     of the fits[] table */

void goto_next_fit(void) ;
  /* set tune.pitches[tune.table][pitch_index] to next fit out
     of the fits[] table */

const char * get_fitting_text(int cent) ;
	/* returns fitting text if cent value fits to any predefined entry, else empty string */

extern UBYTE get_test_channel(void) ;
  /* must read test channel out of GUI and return it */
  /* must be provided by non-common GUI module ! */

void send_tuning(void) ;
  /* reads test channel from GUI and sends tuning info on it */

void switch_notes(int on) ;
  /* switches the test notes on or off (depending on on != 0) */
  /* reads test channel from GUI */

/*** presets ***/

#define MAX_PRESETS 7

typedef struct
{
	PITCH_TABLE pitches ;
	const char * name ;	
} 
PRESET ;

extern PRESET presets[MAX_PRESETS] ;
