/* EVENTHDL.H */

#include "portable.h"
#if defined (__PALM__)
#  include "resource.h"
#else
#  define MAX_TABLES   4
#  define MAX_PCS     20
#  define PC_MAXCHARS 79
#  include <string.h>  /* Palm OS has built-in libraries */
#endif
#include "midi.h" /* for Palm OS we use a link in the local dir. */
#if defined (__PUREC__)
#  define MIDI 3
#  define CON  2
#endif

/*----------------- event_handler() definitions ---------------------*/

/* all "extern" variables here are defined in eventhdl.c */

#define INVALID    0xFF /* internal representation of invalid note */
#define UNCHANGED  0xFE /* internal representation of unchanged note */

extern char *error_text ;	/* is set to an error message by the event_handler() */	

int event_handler(void) ;
#define ERROR_OCCURRED -1 /* update: error status */
#define H_NOTE_CHANGED 1  /* update: harmonizing note and pitch bend offset */
#define TABLE_CHANGED  2  /* update: current table */
#define KEY_CHANGED    3  /* update: current key */
#define TIME_CHANGED   4  /* update: smoothing time */
#define KEY_PRESSED    5  /* computer keyboard has been hit */
#define INITIALIZED    6  /* listening to MIDI input, initialized now is 1 */
#define MIDI_IDLE      7  /* no data in MIDI input buffers */

extern unsigned initialized ;

void exit_event_handler(void) ;
  /* Must be called after last call of event_handler() to clean up
     MIDI out. Resets initialized to 0. */
  
/* The update_...() functions must be called when the event handler is
   running (i.e. event_handler() is called within a loop) to tell it 
   corresponding changes (i.e. by the user interface). If the event handler
   is not running (before 1. call or after exit_event_handler() and before
   the next call), it is not necessary to call the update_...() functions,
   since then the event handler knows that it needs to perform correct 
   initialization of its internal data structures. 
   Some changes, like automatic mode, have no update_...() function. They
   require exit_event_handler() to force complete re-initialization
   (which should also work for all other updates, anyhow). */
  
void update_key(unsigned key) ;
  /* must be called to tell event handler, that key changed */
  /* valid key = 0..11, >= 12 means "no key" */

void update_smoothing(unsigned smoothing) ;
  /* must be called to tell event handler, that smoothing changed */
  /* valid smoothing = 0..9 */

void update_table(unsigned table) ;
  /* must be called to tell event handler, that tuning table changed */
  /* valid table = 0..(MAX_TABLES - 1) */
  
void update_hold(unsigned hold) ;
  /* must be called to tell event handler, that hold mode changed */
  /* valid hold = 0,1 corresponding to off,on  */

#define PB_HALF_RANGE 100	/* -100..+100 cent */

#define PB_SENS ((PB_HALF_RANGE << 5) / 25) /* << 7 / 100 */
  /* for pitch_bend_sensitivity() calls */

unsigned cent_to_pb(int cent) ;
	/* convert cent value to 14 bit                         */
	/* pitch bend under the assumption: pitch bend range is */
	/* -PB_HALF_RANGE..+PB_HALF_RANGE cent.                 */

int pb_offset_to_cent(int pb_offset) ;
	/* converts pitch offset in pitch bend units to pitch */
	/* offset in cent.                                    */

/*------- control ---------- */

#define THROUGH    0x0001	/* pure MIDI through processing */
#define AUTO_START 0x0002	/* activate MIDI processing on program start */
#define HOLD       0x0004	/* hold-mode */
#define AUTOMATIC  0x0008	/* automatic harmonizing */
#define IDLE_RET   0x0010	/* return MIDI_IDLE when no data available */

typedef struct
{
	unsigned int	harmonizing_channel ;
	unsigned int	input_channels ;
	unsigned int	output_channels ;
	unsigned int	mode ;
	unsigned char	smoothing ;
	unsigned char	key ;
} 
CONTROL ;
extern CONTROL control ;

/*------- tuning/pitches ---------- */

#define MAX_PITCHES 12

typedef INT16 PITCH_TABLE[MAX_PITCHES] ;
typedef PITCH_TABLE PITCHES[MAX_TABLES] ; 

typedef struct
{
	enum { 
		PITCH_BND = 0, /* default static init = 0 */
		SCALE_TUNE
	} mode ;	
	PITCHES 		pitches ;
	unsigned char	table ;	
} 
TUNE ;
extern TUNE tune ;

/* pitches 1..11 for the distances 1..11,
   element 0 contains mean pitch */

extern UBYTE harmonizing_note ;	
extern int pitch_offset ; 			/* current pitch offset */
extern unsigned critical_offset ; 
  /* not zero if at least one of the intervals in the current
     tuning table can not be tuned as desired (because the
     pitch bend or scale tune value is outside the allowed ranges,
     because of the high absolute value of the offset) */

/*------- volumes ---------- */

#define MAX_VOLUMES 128
#define MAX_VOLUME   16
#define HALF_VOLUME   8

typedef struct
{
	enum {VOL_LINEAR, VOL_QUADRATIC, VOL_QUADRATIC_PLUS_CONST,
	      VOL_ROLAND_JUNO_D} 
		mode ;
	enum {FIX_MIN, FIX_MAX/*, FIX_ALL*/}
		fixpoint ;
	char data[MAX_VOLUMES] ;
} VOLUMES ;


/* For Roland Juno D (2004/5). The Juno D sends at least a 
   note-on dynamic of 7. Therefore dynamic values are not
   transformed from 0..7 in the mode VOL_ROLAND_JUNO_D. */
#define BENDPOINT_1 7
extern unsigned BENDPOINT_2 ;

extern VOLUMES volumes ;

UBYTE transform_dynamic(UBYTE note, UBYTE dynamic) ;

/*------- program change mapping ---------- */

typedef struct
{
	char pc ;
	char string[PC_MAXCHARS+1] ;
} PC_DATA ;
extern PC_DATA pc_data[MAX_PCS] ;

