/* EVENTHDL.C */

#if defined (__PUREC__)
#  include <tos.h>
#else
/* no checking for keyboard input */
#  define Bconstat(x) 0
#  define Bconin(x)   0
#endif
#include "eventhdl.h"

#define MAX_HP_PITCHES  264 /*  upperlimit(128 MIDI notes,12) * 2  */
#define MID             132 /*  = MAX_HP_PITCHES/2 */
static INT16 hp_pitches[MAX_TABLES][MAX_HP_PITCHES] ; /* replicated PITCHES, to avoid division */

TUNE tune ;
static int mean_pitch ;
	/* A constant mainly, but different in pitch bend and scale
	   tune modes. Corresponds to 0 cent. */
static int min_pitch, max_pitch ;
  /* Minimum and maximum values of all pitches found in the current table,
     but different in pitch bend and scale tune modes.
     Always positive in pitch bend mode. */

static const PITCH_TABLE clean_anti_symmetric /* in cent, used in automatic mode */
	= {  0, 12,  4, 16,-14, -2,  0,  2, 14,-16, -4,-12 } ;

UBYTE harmonizing_note = INVALID ;
int pitch_offset ;
unsigned critical_offset ;

CONTROL control = 
{
	0x0001,				/* channel 0 */
	0xFFFF,  			/* all input channels on */
	0xFFFF,  			/* all output channels on */
	HOLD,				/* hold is default */
	5,					/* mean smoothing */
	-1					/* invalid key */
};
static int hold, automatic, scale_tune ;	/* for faster access */

PC_DATA pc_data[MAX_PCS] ;
VOLUMES volumes ;
unsigned BENDPOINT_2 = 100 ;

static void update_pitches(UBYTE new_h_note, int *stop) ;
static void init_ring(int time) ;
static void init_NL(void) ;
static void exit_NL(void) ;
static void sust_late_off(void) ;

/********************************************************************
*
*         auxiliary functions
*
********************************************************************/

unsigned cent_to_pb(int cent)
{
/*  if (cent <= 0) 
       return (unsigned)( ((long)cent + PB_HALF_RANGE) * MEAN_PITCH / PB_HALF_RANGE ) ;
  else*/ return (unsigned)( (long)cent * (MAX_PITCH - MEAN_PITCH) / PB_HALF_RANGE + MEAN_PITCH ) ;
}

int pb_offset_to_cent(int pb_offset)
{
	if (pb_offset <= 0)
	     return (int)((long)pb_offset * 100 / (MEAN_PITCH - MIN_PITCH)) ; 
	else return (int)((long)pb_offset * 100 / (MAX_PITCH - MEAN_PITCH)) ;
}

UBYTE transform_dynamic(UBYTE note, UBYTE dynamic) 
{
	long d = (long)dynamic ;
#if 0
	if (volumes.fixpoint == FIX_ALL)
	{
		// data = 8 => linear, else convex or concave 
		// but f(0) = 0 and f(127) = 127
		float exponent ;
		switch (volumes.data[note])
		{
		case  0: exponent =  0.20 ; break ; /* 1/5 */
		case  1: exponent =  0.22 ; break ; /* 2/9 */
		case  2: exponent =  0.25 ; break ; /* 1/4 */
		case  3: exponent =  0.29 ; break ; /* 2/7 */
		case  4: exponent =  0.33 ; break ; /* 1/3 */
		case  5: exponent =  0.40 ; break ; /* 2/5 */
		case  6: exponent =  0.50 ; break ; /* 1/2 */
		case  7: exponent =  0.67 ; break ; /* 2/3 */
		case  8: exponent =  1.00 ; break ; 
		case  9: exponent =  1.50 ; break ;
		case 10: exponent =  2.00 ; break ;
		case 11: exponent =  2.50 ; break ;
		case 12: exponent =  3.00 ; break ;
		case 13: exponent =  3.50 ; break ;
		case 14: exponent =  4.00 ; break ;
		case 15: exponent =  4.50 ; break ;
		case 16: exponent =  5.00 ; break ;
		}
		d = (long)(pow(127.0, 1 - exponent) *
		           pow(dynamic, exponent)) ; 
pow() does not exist on Palm OS !!!!
	}
	else
#endif	
	{
		if (volumes.mode == VOL_ROLAND_JUNO_D)
		{
			/* 3 sections with linear function of the dynamic x - if data < half:
			   1. [0,BENDPOINT_1]: f0(x) = x
			   2. [BENDPOINT_1,BENDPOINT_2]:
			        f1(BENDPOINT_1) = BENDPOINT_1
			        f1(BENDPOINT_2) depends on data, if data is HALF_VOLUME
			        then f(BENDPOINT_2) = BENDPOINT_2.
			   3. [BENDPOINT_2,127]:
			        f2(BENDPOINT_2) depends on data, if data is HALF_VOLUME
			        then f(BENDPOINT_2) = BENDPOINT_2.
			        f2(127) = 127 
			   The whole formulas are:
			   1. f0(x) = x
			   2. f1(x) = (m*(data-8)+BENDPOINT_2-BENDPOINT_1)/(BENDPOINT_2-BENDPOINT_1)*(x-BENDPOINT_1)+BENDPOINT_1
			   3. f2(x) = (127-m*(data-8)-BENDPOINT_2)/(127-BENDPOINT_2)*(x-127)+127
			              with m=(127-BENDPOINT_2)/8 or any smaller value
			   But if data > half, fi(x) are the functions mirrored at y=x !!!
			*/
			if (d > BENDPOINT_1)
			{
				long m = (BENDPOINT_2 - BENDPOINT_1) / 10 ; /* smaller value */
				if (d < BENDPOINT_2)
				{
					if (volumes.data[note] <= 8)
					{
						d = (m * (volumes.data[note] - 8) + BENDPOINT_2 - BENDPOINT_1) *
					    	(d - BENDPOINT_1) / (BENDPOINT_2 - BENDPOINT_1)
					    	+ BENDPOINT_1 ;
					}
					else 
					{
						d = (BENDPOINT_2 - BENDPOINT_1) * (d - BENDPOINT_1) / 
						    (m * (8 - volumes.data[note]) + BENDPOINT_2 - BENDPOINT_1)
						    + BENDPOINT_1 ;
					}
				}
				else
				{
					if (volumes.data[note] <= 8)
					{
						d = (127 - m * (volumes.data[note] - 8) - BENDPOINT_2) *
					    	(d - 127) / (127 - BENDPOINT_2)
					    	+ 127 ;
					}
					else 
					{
						d = (127 - BENDPOINT_2) * (d - 127) / 
						    (127 - m * (8 - volumes.data[note]) - BENDPOINT_2)
						    + 127 ;
					}
				}
			}
			/* else leave untransformed */
		}
		else if (volumes.mode == VOL_LINEAR)
		{
			if (volumes.fixpoint == FIX_MIN)
		    	 d = (d * volumes.data[note]) >> 3 ;
			else d = (((d - 127) * volumes.data[note]) >> 3) + 127 ;
		}
		else /* quadratic */
		{
			if (volumes.fixpoint == FIX_MIN)
		    	 d = (d * d * volumes.data[note]) >> 10 ; 
			else d = (((d * d - 16129) * volumes.data[note]) >> 10) + 127 ;
		}
	}
	if (d > 127) d = 127 ;
	if (d <   0) d =   0 ;
	return (UBYTE)d ;
}

/********************************************************************
*
*         key
*
********************************************************************/

void update_key(unsigned key)
{
	int stop ;
	control.key = (key >= 12) ? INVALID : key ;
	exit_NL() ;
	init_NL() ;
	if ((control.mode & HOLD) && key < 12)
	  update_pitches(key, &stop) ;
}

static void update_key_MIDI(unsigned key, int *stop)
  /* interprets a MIDI controller value 0..127 as key 0..11 or "no key" */
{
	key *= 13 ;
	key /= 128 ;
	if (key != control.key) 
	{
		*stop = KEY_CHANGED ;
		update_key(key) ;
	}
}

/********************************************************************
*
*         smoothing
*
********************************************************************/

void update_smoothing(unsigned smoothing)
{
	control.smoothing = smoothing ;
	init_ring(smoothing) ;
}

static void update_smoothing_MIDI(unsigned smoothing, int *stop)
  /* interprets a MIDI controller value 0..127 as table 0..(MAX_TABLES - 1) */
{
	smoothing *= 10 ; 
	smoothing /= 128 ;
	if (smoothing != control.smoothing)
	{
		*stop = TIME_CHANGED ;
		update_smoothing(smoothing) ;
	}
}


/********************************************************************
*
*         current table 
*
********************************************************************/

static void update_critical(void)
{
  if (scale_tune)
  {
    if ((pitch_offset + max_pitch > 63) || 
        (pitch_offset + min_pitch < -64)) 
         critical_offset = 1 ;
    else critical_offset = 0 ;
  }
  else 
  {
    if ((pitch_offset + max_pitch > MAX_PITCH) || 
        (pitch_offset + min_pitch < MIN_PITCH)) 
         critical_offset = 1 ;
    else critical_offset = 0 ;
  }
}		


static void update_min_max_pitches(const INT16 *pitches)
  /* determines absolute minimum and maximum values of all pitches
     in pitches (an array of MAX_PITCHES pitches) */
{
	int i ;
	
	min_pitch = 32000 ;
	max_pitch = -32000 ;
	for (i = 0 ; i < MAX_PITCHES ; i++)
	{
		max_pitch = max(pitches[i], max_pitch) ;
		min_pitch = min(pitches[i], min_pitch) ;
	}
	if ( tune.mode == PITCH_BND )
	{
		min_pitch = cent_to_pb(min_pitch) ;
		max_pitch = cent_to_pb(max_pitch) ;
	}
	update_critical() ;
}


void update_table(unsigned table)
{
  const INT16 *pitches = automatic ? clean_anti_symmetric : tune.pitches[table] ;
	tune.table = table ;
	update_min_max_pitches(pitches) ;
	update_pitches(UNCHANGED, NULL) ; /* forced update, also updates "critical" */
}

static void update_table_MIDI(unsigned table, int *stop)
  /* interprets a MIDI controller value 0..127 as table 0..(MAX_TABLES - 1) */
{ 
	if (automatic) /* table fix coded */
		return ;
		
	table *= MAX_TABLES ;
	table /= 128 ;
	if (table != tune.table) 
	{
		*stop = TABLE_CHANGED ;
		update_table(table) ;
	}
}

/********************************************************************
*
*         hold
*
********************************************************************/

void update_hold(unsigned _hold)
{
  hold = _hold ;
  if (hold) 
      control.mode |= HOLD ;
  else
      control.mode &= ~HOLD ;
  
}

/********************************************************************
*
*         note lists
*
********************************************************************/

#define MAX_NOTES       0x10  /* must be number MIDI channels in pb mode */
#define MAX_NOTES_MASK  0x0F  /* MAX_NOTES - 1, for fast modulo division */

/* The note list is mainly needed for pitch bend mode. 
   However in scale tune mode the note list is needed, too,
   because of the sustain and pattern fields which are evaluated in 
   automatic mode. 
   Also note_shift might get relevant in the future. */

typedef struct 
{ 
	int pitch ;          /* mapped, i.e. inside (0,16383) */
	unsigned age ;       /* 0 = off, 1.. counted in note on events since insertion */
	unsigned pattern ;   /* of note, one of bit 0..11, for automatic mode */
	unsigned enabled ;   /* pb mode: this out channel enabled ? */
	UBYTE sustain ;      /* 0 = none, 1 = to send, 2 = sent */
	UBYTE sustain_off ;  /* 0 = none, 1 = to send */
	UBYTE note ;         /* MIDI note number */
	UBYTE orig_channel ; /* st mode: where the note on arrived */
/*	int note_shift ;*/     /* for notes with high absolute value of pitch */
} 
element ; 

static element NL[MAX_NOTES] ;	/* note list */
static int out_notes ; /* max. output notes depending on enabled output 
                          channels (pb mode only) */
static int number_notes ;

static unsigned scale_tuned_channels ; 
	/* bit 0..15: performance parts (= MIDI channels) for which  */
	/* scale tune has been sent already. Scale tune is sent only */
	/* when a channel is used, i.e. when the first note on       */
	/* message arrives on that channel.                          */


/*------------ automatic mode only --------------*/

static const unsigned char beauty[MAX_PITCHES] 
	= { 11,  1,  4,  5,  8,  9,  0, 10,  7,  6,  3,  2 } ;

#define two_power_twelve	0x1000
UBYTE pattern_to_note[two_power_twelve] ;
  /* maps chords to harmonizing notes */
  /* selects h.note in a way that beauty of intervals is max. */

static void init_pattern_to_note(void)
  /* this functions takes time ! */
{
	unsigned char max_beauty, prev_max_beauty, tot_beauty, i,j ;
	int pattern, rot_pattern ;
	static filled ;
	
	if (filled)
		return ;
	
	for (pattern = 0 ; pattern < two_power_twelve ; pattern++)
	{
		prev_max_beauty = max_beauty = 0 ;
		for (i = 0 ; i < 12 ; i++)
		{
			tot_beauty = 0 ;
			rot_pattern = ((pattern >> i) | (pattern << (12 - i))) & 0xFFF ; /* rotate right */
			for (j = 0 ; j < 12 ; j++)
				if ( rot_pattern & (1<<j) ) tot_beauty += beauty[j] ;
			if (tot_beauty >= max_beauty) 
			{
				prev_max_beauty = max_beauty ;
				max_beauty = tot_beauty ;
				if (max_beauty > prev_max_beauty) 
				     pattern_to_note[pattern] = i ;
				else pattern_to_note[pattern] = INVALID ; 
			}
		}
	}
	filled = 1 ;
}

/*--- ring storage for the latest events ---*/

#define MAX_RING_SIZE	50
static int RING_SIZE ;
static unsigned ring[MAX_RING_SIZE] ;

static void init_ring(int smoothing) 
{
	int i ; 
	static const int ring_sizes[10] = { 1, 2, 4, 6, 10, 14, 20, 26, 34, 42 } ;
	if (smoothing > 9) 
		smoothing = 9 ;
	RING_SIZE = ring_sizes[smoothing] ; /* ~ smoothing^2 */
	for (i = 0 ; i < MAX_RING_SIZE ; i++) ring[i] = 0 ; /* empty */
}

static void update_ring(unsigned int note_pattern)
{
	static int write_pointer = 0 ;

	write_pointer++ ;
	if (write_pointer >= RING_SIZE) write_pointer = 0 ;
	ring[write_pointer] = note_pattern ;
}

static unsigned int get_ring_pattern(void)
{
	unsigned int pattern = 0, i ;
	for (i = 0 ; i < RING_SIZE ; i++) pattern |= ring[i] ;
	return pattern ;
}

/*--------------- for all modes common ----------------*/

/*static int note_shift(long pb)
{ */
  /* Note shift mode not desired, see hand-written documentation,
     the stair function can be found there, too. */
 /* return 0 ;
}*/

/*static int mapped_pb(long pb)
{ */
  /* Note shift mode not desired, see hand-written documentation,
     the sawtooth function can be found there, too. */
 /* return (int) pb ;
}*/


static void pitch_bend_NL(int index, int new_pb)
{
	if (NL[index].pitch != new_pb) 
	{
		NL[index].pitch = new_pb ;
		pitch_bend(index, new_pb) ;
	}
}

static void new_pitch_bend(int index, long new_pb)
{
/*	int mapped ;*/
	if (NL[index].age) 
	{
/*		mapped = mapped_pb(new_pb) ; */
/*		if ( NL[index].note_shift == note_shift(new_pb) )*/
			pitch_bend_NL(index, /*mapped*/new_pb) ;
	}
}

void scale_tune_send_NL(void)
{
	/* send scale tune at once at least for 
	   those notes that fit into the note list */
	int i ;
	scale_tuned_channels = 0 ;
	for (i = 0 ; i < MAX_NOTES ; i++)
		if ( (NL[i].age) && 
		   !((NL[i].orig_channel << i) & scale_tuned_channels) )
	{
		scale_tune_send(NL[i].orig_channel) ;
		scale_tuned_channels |= (NL[i].orig_channel << i) ;
	}
}


static void update_pitches(UBYTE new_h_note, int *stop)
{
	int pitch ;
	UBYTE i, last_h_note = harmonizing_note ;

	if (new_h_note == harmonizing_note)
		return ; /* nothing to change */

	if (new_h_note != UNCHANGED)
	{
		harmonizing_note = new_h_note ;
		if (stop) *stop = H_NOTE_CHANGED ;
	}
	if (harmonizing_note == INVALID)
	{
		pitch = mean_pitch + pitch_offset ;
		if (scale_tune)
		{
			scale_tune_set_equal_cent(pitch) ;
			scale_tune_send_NL() ;
		}
		else if (!automatic) 
			for (i = 0 ; i < MAX_NOTES ; i++)
				new_pitch_bend(i, pitch) ;
	}
	else
	{
		if (new_h_note != UNCHANGED)
		{
			/* harmonizing note changed: update pitch offset */
			if (control.key == INVALID) 
			{
				if (last_h_note != INVALID)
					/* key is the previous harmonizing note */
					pitch_offset += 
					  hp_pitches[tune.table][MID + harmonizing_note - last_h_note] - mean_pitch ;
			}
			else 
				/* key is fixed */
				pitch_offset = hp_pitches[tune.table][MID + harmonizing_note - control.key] - mean_pitch ;
			/* critical offset indicator depends on offset */
 			update_critical() ;
		}
		if (scale_tune)
		{
			scale_tune_set_cent( &(hp_pitches[tune.table][MID - harmonizing_note]) ) ;
			scale_tune_send_NL() ;
		}
		else if (!automatic) 
			for (i = 0 ; i < MAX_NOTES ; i++)
				if (NL[i].age) 
		{
			pitch = hp_pitches[tune.table][MID + NL[i].note - harmonizing_note] + pitch_offset ;
			new_pitch_bend(i, pitch) ;
		}
	}
}


static void update_harmonizing_on(UBYTE note, int *stop) 
{
	if (automatic) 
		return ; /* no manual input */

	update_pitches(note, stop) ;
}


static void update_harmonizing_off(UBYTE note,	int *stop) 
{
	if (automatic) 
		return ; /* no manual input */
		
	if ( (!hold) && (note == harmonizing_note) ) 
		update_pitches(INVALID, stop) ;
}


static void note_off_NL(UBYTE index, UBYTE dynamic)
{
	note_off( index, 
	          NL[index].note /*+ NL[index].note_shift*/, 
	          dynamic ) ;
	NL[index].age = 0 ;
/*	NL[index].note_shift = 0xFF ;*/
} 


static void exit_NL(void)
{
	UBYTE i ;
	
	if (scale_tune)
	{
		scale_tune_init() ;	/* equal temperament */
		scale_tune_send_all() ;
	}
	for (i = 0; i < 16 ; i++)
	{
		note_off_NL(i, /*dynamic*/ 0) ;
		pitch_bend_NL(i, MEAN_PITCH) ;
		sust_late_off() ; /* has its own static channel counter */
	}
}


static void init_NL(void)
{
	UBYTE i ;
	out_notes = 0 ;
	pitch_offset = 0 ;
	harmonizing_note = INVALID ;
	scale_tuned_channels = 0 ;
	number_notes = 0 ;

	automatic =      (control.mode & AUTOMATIC) ;
	scale_tune =     (tune.mode == SCALE_TUNE) ;

	if (scale_tune) 
	{
		scale_tune_init() ; /* must be called once before first scale_tune_send() */
		mean_pitch = 0 ;    /* 0 cent */
	}
	else 
	{
		mean_pitch = MEAN_PITCH ;
		
		/* adjust pitch bend sensitivity on all output channels */ 
		if ( !(control.mode & THROUGH) )
		{
			unsigned i ;
			for (i = 0 ; i < 16 ; i++)
				if (control.output_channels & (1<<i))
					pitch_bend_sensitivity(i, PB_SENS) ;
		}
	}

	update_hold      (control.mode & HOLD) ;
	update_smoothing (control.smoothing) ;
	update_table     (tune.table) ; /* updates also critical indicator,
	                                   scale_tune must be up-to-date! */
	
	/* init note list elements */
	for (i = 0 ; i < MAX_NOTES ; i++ ) 
	{
		NL[i].age = NL[i].sustain = NL[i].sustain_off = NL[i].pattern = 0 ;
/*		NL[i].pitch = mean_pitch ;*/
/*		NL[i].note_shift = 0xFF ;*/
		
		NL[i].enabled = 1 ;
		if ( !(control.mode & THROUGH) )
		{
		  if ( scale_tune || (control.output_channels & (1<<i)) )
		  {
			  out_notes++ ;
			  if ( !scale_tune )
				  pitch_bend_NL(i, hp_pitches[tune.table][i]) ; /* anti-glide */
			}
			else NL[i].enabled = 0 ;
		}
	}

	while (midi_data_available) 
		midi_in ; /* clear buffer */
#ifdef __PALM__
	send_error = recv_error = errNone ;
	// We detect errors in the event_handler() function later.
#endif
}


static void update_note_on(UBYTE orig_ch, UBYTE note, UBYTE dynamic, int *stop) 
{
	UBYTE channel = 0xFF, i, mod_note = note % 12 ;
	unsigned oldest_age, pb, out_dyn, pattern = 0 ;
	int current_diff, smallest_diff = MAX_PITCH ;

	/* calculate pitch */
	if (automatic) 
	{
	  /* Find out contribution of sustained notes to pattern.
	     Sustained notes must be harmonically important. */
	  for ( i = 0 ; i < MAX_NOTES ; i++ )
	    if ( NL[i].sustain == 2 )
	      pattern |= NL[i].pattern ;
	      
		update_ring(1 << mod_note) ;
		update_pitches(
			pattern_to_note[get_ring_pattern() | pattern], 
			stop ) ;
	}

	/* pitch for new note */
	if (scale_tune)
	{
		if ( !((1<<orig_ch) & scale_tuned_channels) )
		{
			scale_tuned_channels |= (1<<orig_ch) ;
			scale_tune_send(orig_ch) ;
		}
	}
	else
	{ 
		if (harmonizing_note == INVALID) 
		     pb = mean_pitch + pitch_offset ;
		else pb = hp_pitches[tune.table][MID + note - harmonizing_note] + pitch_offset ;
	}

	if (number_notes < out_notes) 
	{
		number_notes++ ;

		/* search free place */
		for ( i = 0 ; i < MAX_NOTES ; i++ ) 
		{
			if ( NL[i].enabled )
			{
				if ( NL[i].age ) 
				  NL[i].age++ ;
				else 
				{
				  current_diff = NL[i].pitch - pb ;
				  if (current_diff < 0) 
				  	current_diff = (-current_diff) ;
				  if ( 
				    /* first free place found ? */
				    (scale_tune && channel == 0xFF) ||                
				    /* free place with best pitch fit found ?
				       we look for this to avoid undesired glide effects
				       generated by some stupid synths when making fast
				       pitch bend hops */
				    (!scale_tune && current_diff < smallest_diff) 
				  )
				  {
				    smallest_diff = current_diff ;
				    channel = i ;
				  }
				} 
			}
		}
	}
	else 
	{
		/* delete oldest entry to make place for new event */
		oldest_age = 0 ;
		for ( i = 0 ; i < MAX_NOTES ; i++ ) 
			if (NL[i].age > oldest_age) 
		{
			oldest_age = NL[i].age ;
			channel = i ;
		}
		if (!scale_tune)
			/* switch off oldest note */
			note_off_NL(channel, /*dynamic*/ 0) ;
	}
	
	/* insert new event */
	NL[channel].note         = note ;
	NL[channel].orig_channel = orig_ch ;
	NL[channel].age          = 1 ;
	NL[channel].pattern      = 1 << mod_note ;

	/* put out note event */
	out_dyn = transform_dynamic(note, dynamic) ;
	if (scale_tune)	
	     note_on(orig_ch, note, (UBYTE)out_dyn) ;
	else 
	{
		pitch_bend_NL(channel, /*mapped_pb(*/pb/*)*/) ;
		/*NL[channel].note_shift = note_shift(pb) ;*/
		note_on(channel, note /*+ NL[channel].note_shift*/, (UBYTE)out_dyn) ;
	}

	/* send sustain on if pending */
	if (NL[channel].sustain == 1) 
	{
		/* send sustain now 
		   (never pending in scale tune mode) */
		NL[channel].sustain = 2 ; /* sustain sent */
		sustain_on(channel) ;
	}
}


static UBYTE update_note_off(UBYTE orig_ch, UBYTE note, UBYTE dynamic)
{
	UBYTE i ; 
	UBYTE rc = 0xFF ; /* note on lost or MAX_NOTES previously exceeded */

	if (scale_tune)
	{
		note_off(orig_ch, note, dynamic) ;
		rc = orig_ch ; /* always good */
	}	
	for ( i = 0 ; i < MAX_NOTES ; i++ ) 
	{
		if ( NL[i].age && NL[i].note == note ) 
		{
			/* mark "free" */
			number_notes-- ;

			/* put out note event */
			if (scale_tune)
				NL[i].age = 0 ;
			else
			{
				note_off_NL(i, dynamic) ;
				rc = i ;
			}
			break ;
		}
	}
	return rc ; 
}


static void sustain_on_NL(UBYTE orig_ch)
{
	int i ;

	if (scale_tune)
		sustain_on(orig_ch) ;
			
	for (i = 0; i < MAX_NOTES; i++)
	{
		if (scale_tune && NL[i].orig_channel == orig_ch)
			NL[i].sustain = 2 ; /* sustain sent */
		else
		{
			if (NL[i].age)
			{
				sustain_on(i) ;	/* send at once */
				NL[i].sustain = 2 ; /* sustain sent */
			}
			else NL[i].sustain = 1 ; /* send later, only if necessary */
		}
	}
}


static void sustain_off_NL(UBYTE orig_ch)
{
	int i ;

	if (scale_tune)
		sustain_off(orig_ch) ;
			
	for (i = 0; i < MAX_NOTES; i++)
	{
		if (scale_tune && NL[i].orig_channel == orig_ch)
		{
			NL[i].sustain_off = 0 ;  /* already sent here */
			NL[i].sustain = 0 ;
		}
		else
		{
			if (NL[i].sustain == 2) 
				NL[i].sustain_off = 1 ;
			NL[i].sustain = 0 ; 
		}
	}
}


static void sust_late_off(void)
{
	static int i ;

	i++ ; i &= MAX_NOTES_MASK ;
	if (NL[i].sustain_off)
	{
		/* switch sustain off */
		sustain_off(i) ;
		NL[i].sustain_off = 0 ;
	}
}

/********************************************************************
*
*         event handler
*
********************************************************************/

char *error_text ;

static char *note_off_error  = "note overflow" ; /* normal in PB mode */
static char *pc_string_error = "invalid PC string" ; /* user error */

static char mapped[PC_MAXCHARS+1] ; /* buffer for mapped program change */

#define wait_for_midi_data while (!midi_data_available) 

#define if_valid_in_channel    if (maskable_channel & control.input_channels)
#define if_harmonizing_channel if (maskable_channel & control.harmonizing_channel)

#define for_each_out_channel \
	for (channel = 0; channel < 16; channel++) \
		if ( control.output_channels & (1<<channel) )

#define if_scale_tune_forward \
	if (scale_tune) { \
		midi_out(Rx_buffer_1) ;\
	}

unsigned initialized ;

static void init_event_handler(void)
{
	UINT16 i,j ;

	/* copy pitches to high performance tables */
	for (i = 0 ; i < MAX_TABLES ; i++) 
	{
		for (j = 0 ; j < MAX_PITCHES ; j++) 
		{
			if (control.mode & AUTOMATIC) 
			     hp_pitches[i][j] = clean_anti_symmetric[j] ;
			else hp_pitches[i][j] = tune.pitches[i][j] ;
				if ( tune.mode == PITCH_BND )
				hp_pitches[i][j] = cent_to_pb( hp_pitches[i][j] ) ; 
			/* else scale tune: use the cent values */
		}
		/* the rest is a periodic copy of the first 12 elements */
		for ( ; j < MAX_HP_PITCHES ; j++) 
			hp_pitches[i][j] = hp_pitches[i][j - MAX_PITCHES] ;
	}	
	
	init_NL() ;
	init_pattern_to_note() ; /* takes time */
	
	initialized = 1 ;
}

void exit_event_handler(void)
{
	int channel ;
	exit_NL() ;
	for_each_out_channel 
		all_notes_off(channel) ;

	initialized = 0 ;
}

int event_handler()
{
	static unsigned maskable_channel ;
	static UBYTE Rx_buffer_1, Rx_buffer_2,
	       status,        /* status as read from MIDI in */
	       channel,       /* for the for_each_out_channel macro */
	       orig_channel,  /* where the event arrived            */
	       controller_values[128] ;
	int stop = 0 ;
	UINT16 i,j,len ;

	if (!initialized)
	{
		init_event_handler() ;
		return INITIALIZED ;
	}
	
	if (control.mode & THROUGH) 
	{
		do 
		{
			while (midi_data_available) 
				midi_out(midi_in) ;
			if ( Bconstat(CON) ) 
			{
				Bconin(CON) ;   /* throw away */
				return KEY_PRESSED ;			/****** return *******/
			}
		} while ( !(control.mode & IDLE_RET) ) ; 
		return MIDI_IDLE ;				/****** return ******/
	}
	
	do 
	{
		while (midi_data_available) 
		{
			Rx_buffer_1 = midi_in ; /* 1 byte in */
			if (Rx_buffer_1 & STATUS)
			{
				/* status byte received */
				status = Rx_buffer_1 ;
				orig_channel = status & LSN ;
				maskable_channel = 1 << orig_channel ;
				
				if (scale_tune)	
				{
					switch (status & MSN)
					{
					case NOTE_ON:
						/* note on needs scale tune message to be
						   inserted before */
					case NOTE_OFF:
						/* note on with dynamic 0 is note off. 
						   For consistency therefore we delay also note off. */
					case CONTROL_CHANGE:
					case PROGRAM_CHANGE:
						/* might be also harmonizing channel ! */
						break ; /* send later */
							
					default:
						if_valid_in_channel
							midi_out(status) ;	/* forward at once */
					}
				}
			}
			else
			{
				/* data byte received */
				switch (status & MSN)
				{
				case NOTE_ON:
					wait_for_midi_data ;
					Rx_buffer_2 = midi_in ;
					if_harmonizing_channel
						if (/*dynamic*/ Rx_buffer_2 == 0)
						     update_harmonizing_off(Rx_buffer_1, &stop) ;
						else update_harmonizing_on (Rx_buffer_1, &stop) ;
					if_valid_in_channel
					{
						/* note on with dynamic 0 means note off */
						if (/*dynamic*/ Rx_buffer_2 == 0) 
						{
							if (update_note_off(orig_channel, Rx_buffer_1, Rx_buffer_2) == 0xFF)
							{
								error_text = note_off_error ;
								stop = ERROR_OCCURRED ;
							}
						}
						else update_note_on(orig_channel, Rx_buffer_1, Rx_buffer_2, &stop) ;
					}
					break ;
					
				case NOTE_OFF:
					wait_for_midi_data ; 
					Rx_buffer_2 = midi_in ;
					if_harmonizing_channel
						update_harmonizing_off(Rx_buffer_1, &stop) ;
					if_valid_in_channel
						if (update_note_off(orig_channel, Rx_buffer_1, Rx_buffer_2) == 0xFF)
						{
							error_text = note_off_error ;
							stop = ERROR_OCCURRED ;
						}
					break ;
					
				case CHANNEL_PRESS:
					if_valid_in_channel
					{
						if_scale_tune_forward
						else for_each_out_channel
							channel_press(channel, Rx_buffer_1) ;  
					}
					break ;
					
				case POLY_KEY_PRESS:
					if_valid_in_channel
					{
						if_scale_tune_forward
						else 
						{
							wait_for_midi_data ; 
							Rx_buffer_2 = midi_in ;	
							for_each_out_channel
								poly_key_press(channel, Rx_buffer_1, Rx_buffer_2) ;  
						}
					}
					break ;
					
				case PROGRAM_CHANGE:
					if_harmonizing_channel
					{
						/* map program change to MIDI string 
						   entered by user */
						j = 0 ;
						for (i = 0 ; i < MAX_PCS ; i++)
							if ( Rx_buffer_1 == pc_data[i].pc )
						{
							strcpy(mapped, pc_data[i].string) ;
							if ( ascii_to_midi(mapped, &len) )
							{
								error_text = pc_string_error ;
								stop = ERROR_OCCURRED ;
								break ;
							}
							/* good => send it */
							if (len)
								Midiws(len - 1, mapped) ;
							j++ ; 
						}
						if (j) break ;  
					}

					if_valid_in_channel
					{
						if (scale_tune)
							program_change(orig_channel, Rx_buffer_1) ;
						else for_each_out_channel
						{ 
							program_change(channel, Rx_buffer_1) ;
							pitch_bend_sensitivity(channel, PB_SENS) ;
						}
					}
					break ;
					
				case CONTROL_CHANGE:
					wait_for_midi_data ; 
					Rx_buffer_2 = midi_in ;	/* the controller value */
					if_harmonizing_channel
					{
						/* harmonizer channel controllers for internal use */
						switch (Rx_buffer_1) /* the controller number */
						{
						case 0x10: update_table_MIDI    (Rx_buffer_2, &stop) ; break ;
						case 0x11: update_key_MIDI      (Rx_buffer_2, &stop) ; break ;
						case 0x12: update_smoothing_MIDI(Rx_buffer_2, &stop) ; break ;
						default: ;
						} 
						if ( Rx_buffer_1 >= 0x10 && Rx_buffer_1 <= 0x12 )
							break ;  /* these have different meanings on harm. channel */
					}
					if_valid_in_channel
					{
						if (!scale_tune)
#if 0
							if ( Rx_buffer_1 > 79 ||
							    (Rx_buffer_1 < 64 && Rx_buffer_1 != 0 && Rx_buffer_1 != 32) 
							)
						{
							/* no foot switch, no bank select MSB/LSB: 
							   reduce information on MIDI output */
#else
							if ( Rx_buffer_1 != BANK_SELECT_MSB && Rx_buffer_1 != BANK_SELECT_LSB) 
						{
							/* no bank select MSB/LSB: reduce information on MIDI output */
							/* foot switches per MIDI standard have either 0 or 127 as value
							   => can be reduced, too, with this algorithm */
#endif
							Rx_buffer_2 = (Rx_buffer_2 + 4)>>3 ;
							Rx_buffer_2 <<= 3 ;
							if (Rx_buffer_2 > 127) Rx_buffer_2 = 127 ;
						}
						if (Rx_buffer_2 != controller_values[ Rx_buffer_1 ])
						{
							controller_values[ Rx_buffer_1 ] = Rx_buffer_2 ;
							if (Rx_buffer_1 == SUSTAIN)
							{
								if (Rx_buffer_2) 
								     sustain_on_NL (orig_channel) ;
								else sustain_off_NL(orig_channel) ;	
							}
							else if (scale_tune)
								control_change(orig_channel, Rx_buffer_1, Rx_buffer_2) ;
							else for_each_out_channel 
								control_change(channel, Rx_buffer_1, Rx_buffer_2) ;
						}
					}
					break ;
					
				case PITCH_BEND:
				default: 
					if_valid_in_channel
					{
						if_scale_tune_forward
						/* throw away in pitch bend mode */ 
					}
				}
			}
		} /* as long as MIDI data available */

		sust_late_off() ;	/* treat sustain off with low priority */
		
		if ( Bconstat(CON) ) 
		{
			Bconin(CON) ;   /* throw away */
			stop = KEY_PRESSED ;
		}
		else if ( control.mode & IDLE_RET )
		{
			if (!stop) stop = MIDI_IDLE ;
		}
	} while (!stop) ; 
	
	return stop ;	/* return reason */
}
