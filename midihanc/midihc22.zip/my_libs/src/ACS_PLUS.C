/**************************************************************
*
*                ACS_PLUS.C
*
**************************************************************/

#include <stdio.h> 
#include <string.h>
#include <stdlib.h> /* because of ltoa(), ... */
#include <tos.h>    /* because of Fforce(), ... */
#include <acs.h>
#include <acsplus.h>
#include <acs_plus.h>
#include "acs_plus.h"
#include "acs_plus.ah" 

#define	wind_set( a, b, c, d, e, f ) \
			mt_wind_set( a, b, c, d, e, f, 0L )


INT16 my_alert_str(const char *alert, const char *para)
	/* compresses para to < 30 chars, if necessary */
{
	if (para)
	{
		size_t len = strlen(para) ;
		if (len >= 30)
		{
			char compressed[30] ;
			/* 10 first chars + ... + 15 last chars */
			strncpy(compressed, para, 10) ;
			strcpy (compressed+10, "...") ;
			strcpy (compressed+13, para + len-15) ; 
			return alert_str(alert, compressed) ;
		}
		return alert_str(alert, para) ;
	}
	return alert_str(alert, "") ;
}


static Awindow *help_wi = NULL ;

void A_help(const char *path, CICONBLK *icon)
{
/*	int char_height = 8 ; /* font size in help window */*/
	OBJECT *eduserdef = NULL ;
	char help_path[128] ;
	CICONBLK* orig_icon = EDITOR.iconblk ;

	if (help_wi)
	{
		/* only 1 instance */
		Awi_show(help_wi) ;
		return ;
	}

	if (icon)
		EDITOR.iconblk = icon ;
	help_wi = EDITOR.create(NULL) ;
	if (icon)
		EDITOR.iconblk = orig_icon ;
	if (!help_wi) return ;
	
	/* window shall stay until program end (= has an icon) */
	/* but no ghost icon */
	help_wi->kind &= ~AW_GHOSTICON ;
	
	/* to prevent icon drawing use this in own help_closed() procedure
	   (Grischka Eckart's ACS programming article in ST Computer):
	   wi->state |= AWS_TERM ;
	   Awi_closed(wi) ;
	   wi->state &= ~AWS_TERM ;
	*/

	/* construct help file path */
	if (path)
		strcpy(help_path, path) ;
	else
	{
		strcpy(help_path, ACSblk->appname) ;
		strcpy(strrchr(help_path, '.'), ".txt") ;
	}

	/* load help text file into ACS editor userdef */
/*	help_wi->service(help_wi, AS_EDGETENTRY  , &eduserdef) ;
	((AUSERBLK *)(eduserdef->ob_spec.userblk))->
		ub_serv(eduserdef, AUO_EDHEIGHT, &char_height) ;*/
	help_wi->service(help_wi, AS_EDLOADFILE, help_path) ;
	help_wi->open(help_wi) ;
}


void Awi_setinfo(Awindow *wi, const char *text)
{
	/* this code was copied from ACS on-line help */
	char *old_info = wi->info;
  
	if (NULL == (wi->info = Ast_create (text)))
		wi->info = old_info;
	else
	{
		Ast_delete (old_info);
		if (wi->wi_id >= 0)
			/* window is visible = AES window exists */
/*			wind_set (wi->wi_id, WF_INFO, (INT16)wi->info, (INT32)(wi->info) >> 16 ,0,0);*/
			wind_set (wi->wi_id, WF_INFO, (INT32)(wi->info) >> 16, (INT16)wi->info, 0,0);
	}
}


void A_slider_init(OBJECT *slider, long range, INT16 text_width, long pos, SLLIVE *sllive) 
{
	/* my standard init values for unsigned decimal horizontal sliders */
	long big_step ;
	
	/* ACS 2.33 divides by zero later when range is set to zero here
	   => disable slider when range is zero */
	if (range <= 0)
	{
		range = 1 ;
		slider->ob_state |= DISABLED ;
	}
	else 
	{
		slider->ob_state &= ~DISABLED ;
	}
	big_step = (range * 2 + 5) / 10 ; /* = range/5 with correct rounding */
	big_step = max(1, big_step) ;
	range += big_step ;

	Auo_slider(slider, AUO_SLFULL, &range) ;
	Auo_slider(slider, AUO_SLSIZE, &big_step) ;
	Auo_slider(slider, AUO_SLLEN , &text_width) ;
	Auo_slider(slider, AUO_POS   , &pos) ;
	if (sllive)
		Auo_slider(slider, AUO_SLCALL, sllive) ;
}
		
char * A_slider_dead(void *unused1, long unused2)
{ return "?" ; }

char * A_int_live(void *value, long pos)
{
	static char slider_text[10] ;
	
	if (!value) return "?" ;
	
	*((int *)value) = (int)pos ;
	ltoa(pos, slider_text, 10) ;
	return slider_text ;
}

char * A_plus_1_int_live(void *value, long pos)
{
	pos++ ;
	return A_int_live(value, pos) ;
}


/**************************************************************
*
*                memory management
*
**************************************************************/

/*** global variable, used to point to symptom data for debug_mem ***/ 

char *memory_symptom ;


/*** global variable for recording memory management operations ***/

#define MAX_OPERATIONS 64

struct OPERATION
{
	enum {Memory, String, Object, Window} type ;
	long ptr ;
	long size ;
} ;

static struct OPERATION operation[MAX_OPERATIONS] ;
static char i = 0 ;

/*** own memory management ***/

#define BLOCK_SIZE 0x10000L  /* size to be allocated in 1 one block */
#define MIN_BYTES  4         /* minimum length of last section */

struct BH /* block header for blocks of allocated memory */
{ /* sizeof(BH) must be a multiple of 4 */
	long      size ;   /* total size of block */
	long      free ;   /* net free size */
	struct BH *next ;  /* pointer to next list element */
	long      cs ;     /* checksum for this header */
} 
*bh_first = NULL ; /* pointer to first list element */ ;

struct SH /* section header for memory sections inside blocks */
{ /* sizeof(SH) must be a multiple of 4 */
	long size ;   /* net size of following section */
	int  FREE ;   /* TRUE = next section is free */
	int  cs ;     /* checksum for this header */
} ;



long block_cs(struct BH *bh)
{ return ~( bh->size + bh->free + (long)(bh->next) ) ; }

int section_cs(struct SH *sh)
{ return ~( (int)sh->size + sh->FREE ) ; }


void *new_block(long blocksize, long size) 
{
struct BH *bh ;
struct SH *sh, *sh_next ;

	/*** allocate memory ***/
	bh = (struct BH *)Ax_malloc(blocksize) ;
	if (bh == NULL) 
	{ 
		my_alert_str(ACSblk->description->mess[AD_OUT_OF_MEM], NULL) ;
		return NULL ; 
	}
	/*** init headers ***/
	bh->next = bh_first ; bh_first = bh ; /* chain in */
	bh->size = blocksize ;
	sh = (struct SH *)(bh + 1) ;
	sh->FREE = FALSE ;
	
	/*** init 1 header for free section ***/
	sh->size = blocksize - sizeof(*bh) - sizeof(*sh) ;
	bh->free = 0 ;
	if (size + sizeof(*bh) + (sizeof(*sh)<<1) + MIN_BYTES <= blocksize)
	{
		/*** init 1 more header for free section ***/
		sh->size = size ;
		sh_next = (struct SH *)((long)(sh + 1) + sh->size) ;
		sh_next->FREE = TRUE ;
		sh_next->size = blocksize - size - sizeof(*bh) - (sizeof(*sh)<<1) ;
		sh_next->cs = section_cs(sh_next) ;
		bh->free = sh_next->size ;
	}
	sh->cs = section_cs(sh) ;
	bh->cs = block_cs(bh) ;
	
	/*** return pointer to user section ***/
	return (void *)(sh + 1) ;
}


void *Allocate(long size)
{ 
struct SH *sh, *sh_new ;
struct BH *bh ;
char address[30] ;

	/*** round up size to a multiple of 4 ***/
	size = (size + 3) & 0xfffffffcL ;

	/*** if requested size is big enough, user gets an extra block ***/
	if (size > BLOCK_SIZE / 2) return new_block(size + sizeof(*bh) + sizeof(*sh), size) ;

	/*** else: search for a free section inside allocated blocks ***/
	bh = bh_first ;
	while (bh != NULL) 
	{
		if (bh->cs != block_cs(bh)) 
		{ 
			my_alert_str(BLOCK_DESTROYED, ltoa((long)bh, address, 16)) ; 
			return NULL ; 
		}
		if (bh->free >= size)
		{
			/*** search this block for a free section ***/
			sh = (struct SH *)(bh + 1) ;
			while ( (long)sh < (long)bh + bh->size )  
			{
				if (sh->cs != section_cs(sh))
				{
					my_alert_str(SECTION_DESTROYED, ltoa((long)sh, address, 16)) ;
					return NULL ;
				}
				if (sh->FREE) 
				{
					if (sh->size >= size)
					{
						/*** allocate section (partly) ***/
						if (sh->size >= size + sizeof(*sh) + MIN_BYTES )
						{
							/*** create new section header ***/
							sh_new = (struct SH *)((long)(sh + 1) + size) ;
							sh_new->FREE = TRUE ;
							sh_new->size = sh->size - size - sizeof(*sh_new) ;
							sh_new->cs = section_cs(sh_new) ;
	
							/*** update block header ***/
							bh->free -= sizeof(*sh_new) ;
		
							/*** update section header ***/
							sh->size = size ;
						}
						sh->FREE = FALSE ;
						sh->cs = section_cs(sh) ;
						bh->free -= sh->size ;
						bh->cs = block_cs(bh) ;
						return (void *)(sh + 1) ;
					}
				} /* if section is free */
				sh = (struct SH *)( (long)(sh + 1) + sh->size ) ;
			}
		} /* if enough free memory in this block */
		bh = bh->next ;
	} 
	/*** nothing suitable found up to now -> allocate new block ***/
	return new_block(BLOCK_SIZE, size) ;
}


void Free(void *ptr)
{
struct BH *bh_prev, *bh ;
struct SH *sh, *sh_next, *sh_prev ;
char address[30] ;

	bh_prev = NULL ;
	bh = bh_first ;
	while (bh != NULL) 
	{
		if (bh->cs != block_cs(bh)) 
		{ 
			my_alert_str(BLOCK_DESTROYED, ltoa((long)bh, address, 16)) ; 
			return ; 
		}
		if ( ((long)ptr >= (long)bh + sizeof(*bh) + sizeof(*sh))
		    && ((long)ptr < (long)bh + bh->size) )
		{
			/*** memory to be freed lies in this block ***/
			sh = (struct SH *)(bh + 1) ; sh_prev = sh ;
			while ( (long)sh < (long)bh + bh->size ) 
			{
				if (sh->cs != section_cs(sh))
				{
					my_alert_str(SECTION_DESTROYED, ltoa((long)sh, address, 16)) ;
					return ;
				}
				if ((void *)(sh + 1) == ptr)
				{
					/*** free section ***/
					sh->FREE = TRUE ;
					bh->free += sh->size ;
					sh_next = (struct SH *)((long)(sh + 1) + sh->size) ;
					if ((long)sh_next + sizeof(*sh_next) + MIN_BYTES <= (long)bh + bh->size )
					{
						if (sh_next->cs != section_cs(sh_next))
						{
							my_alert_str(SECTION_DESTROYED, ltoa((long)sh, address, 16)) ;
							return ;
						}
						if (sh_next->FREE)
						{
							/*** put together both free sections ***/
							sh->size += (sizeof(*sh_next) + sh_next->size) ;

							/*** update block header ***/
							bh->free += sizeof(*sh_next) ;
						}
					}
					sh->cs = section_cs(sh) ;
					if ((sh_prev->FREE) && (sh_prev != sh))
					{
						/*** put together both free sections ***/
						sh_prev->size += (sizeof(*sh) + sh->size) ;
						sh_prev->cs = section_cs(sh_prev) ;
		
						/*** update block header ***/
						bh->free += sizeof(*sh) ;
					}
					bh->cs = block_cs(bh) ;
					if (bh->free + sizeof(*bh) + sizeof(*sh) == bh->size)
					{
						/*** block is empty, it can be freed ***/
						if (bh_prev == NULL) bh_first = bh->next ;
						else
						{
							bh_prev->next = bh->next ;
							bh_prev->cs = block_cs(bh_prev) ;
						}
						Ax_free(bh) ;
					}
				return ;
				}
				sh_prev = sh ;
				sh = (struct SH *)( (long)(sh + 1) + sh->size ) ;
			} 
		} /* if inside this block */
		bh_prev = bh ;
		bh = bh->next ;
	} 
	my_alert_str(NOT_ALLOCATED, NULL) ;
}


void debug_mem (void* defective)
{
char all_symptoms[30] = "" ;

	ltoa( (long)defective, all_symptoms, 0x10) ;
	strncat(all_symptoms, " ", 1) ;
	strncat(all_symptoms, memory_symptom, 20) ;
	my_alert_str(MEMORY_ERROR, all_symptoms) ; 
}


void *My_shrink(void *memory, long size)
{
	void *new_memory ;

	/*** free memory if new size shall be 0 ***/
	if (!size) 
	{
		My_free(memory) ;
		return NULL ;
	}
	/*** allocate new memory ***/
	new_memory = My_malloc(size) ;
	if (!new_memory) return memory ; /* not "shrinked" */    

	/*** copy old to new ***/
	memcpy(new_memory, memory, size) ;

	/*** free old memory ***/
	My_free(memory) ;

	/*** return pointer to new memory ***/
	return new_memory ; 
}


void *My_malloc(long size)
{
	void *ptr = Allocate(size) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Memory ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = size ;
		i++ ;
	}
	return ptr ;
}


void *My_calloc( size_t nitems, size_t size) 
{
	long bytes = nitems * size ;
	void *ptr = My_malloc(bytes) ;
	if (ptr) memset(ptr, 0, bytes) ;
	return ptr ;
}


void My_free(void *ptr)
{
	Free(ptr) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Memory ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = 0 ;
		i++ ;
	}
}

/******
char *Myst_create(const char *parent)
{
	char *ptr = Ast_create(parent) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = String ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = strlen(parent) ;
		i++ ;
	}
	return ptr ;
}

void Myst_delete(char *ptr)
{
	Ast_delete(ptr) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = String ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = 0 ;
		i++ ;
	}
}


OBJECT *Myob_create(const OBJECT *parent)
{
	OBJECT *ptr = Aob_create(parent) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Object ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = sizeof(*ptr) ;
		i++ ;
	}
	return ptr ;
}

void Myob_delete(OBJECT *ptr)
{
	Aob_delete(ptr) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Object ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = 0 ;
		i++ ;
	}
}


Awindow *Mywi_create(const Awindow *parent)
{
	Awindow *ptr = Awi_create(parent) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Window ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = sizeof(*ptr) ;
		i++ ;
	}
	return ptr ;
}

void Mywi_delete(Awindow *ptr)
{
	Awi_delete(ptr) ;
	if (i < MAX_OPERATIONS)
	{
		operation[i].type = Window ;
		operation[i].ptr  = (long)ptr ;
		operation[i].size = 0 ;
		i++ ;
	}
}
*****/

void delete_window(Awindow **wi)
{
	if (*wi != NULL)
	{
		Awi_delete(*wi) ;
		wi = NULL ;
	}
}

void print_operations(void)
{
	Fforce(1, (int)Fdup(3)) ;
	for (i = 0 ; i < MAX_OPERATIONS ; i++)
	{
		switch (operation[i].type)
		{
			case Memory: printf("Memory %lx", (long)operation[i].ptr) ; break ;
			case String: printf("String %lx", (long)operation[i].ptr) ; break ;
			case Object: printf("Object %lx", (long)operation[i].ptr) ; break ;
			case Window: printf("Window %lx", (long)operation[i].ptr) ; break ;
		}
		printf(" Size %lx \n", operation[i].size) ;
	}
	Fforce(1, (int)Fdup(1)) ;
}


/**************************************************************
*
*                timer management
*
**************************************************************/

static Awindow *waiting_wi = NULL ;
static INT16 task ;
static long rest_time ;

void stop_timer(void)
{ waiting_wi = NULL ; }

static void inform_waiting_window(void)
{
	Awindow *buffer_wi = waiting_wi ;
	stop_timer() ;
	Awi_sendall(task, buffer_wi) ; /* might manipulate waiting_wi, therefore buffer_wi */
}

void set_timer(Awindow *wi, INT16 _task)
{
	if (waiting_wi && wi != waiting_wi)
		/* force expiry for other waiting window */
		inform_waiting_window() ;
		
	rest_time = 3000 ; /* ms */
	waiting_wi = wi ; /* now timer is running */
	task = _task ;
}

static void timer(void)
{
	if (!waiting_wi)
		return ;

	/* a job is running */
	rest_time -= ACSblk->ev_mtcount ;
	if (rest_time <= 0)
		/* timer expired */
		inform_waiting_window() ;
}

void init_time(void)
{ ACSblk->ACStimer = timer ; /* replace with own timer procedure */ }



