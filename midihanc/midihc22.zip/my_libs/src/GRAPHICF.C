/**************************************************************
*
*                GRAPHICF.C (floating point part)
*
* Use of this module requires linking of floating point lib.
*
**************************************************************/

#include <stdlib.h>
#if defined (__PUREC__)
#	include <acs.h>
#else
//#	include <ui_dsp.hpp>	  // because of RGB macros
#   include <my_vdi.h>
#endif
#include <graphicf.h>
#include <graphic.h>

#define ELL_STRETCH   4/3   /* manipulation of ellipses in y-direction */
#define CIRC_SQUEEZE 13/20  /* manipulation of circle radi */
#define TRI_STRETCH   4/3   /* manipulation of triangles in y-direction */
#define SQRT_3       10/7   /* for ends with equilateral triangles */

/******** auxiliary procedures *********/

static void ellip 
(
	X_HANDLE xhandle, 
	int x0, int x1, int y, int ry, 
	int type, int style, int color 
) 
{
    VDI_HANDLE handle = (VDI_HANDLE)xhandle ;
	int dx = abs(x1-x0) ;
	int rx = (int)((float)dx / 2 + 0.5) ;
	int x_mean = (int)((float)(x0+x1) / 2 + 0.5) ;
	
	if (rx == 0) rx++ ;
	if (ry == 0) ry++ ;
	
	rgb_fstyle_fcolor(xhandle, style, color) ;
	if (type & HEAD_CUT)
		v_ellpie(handle, x0, y, dx, ry, 2700, 900) ;
	else if (type & TAIL_CUT)
		v_ellpie(handle, x1, y, dx, ry, 900, 2700) ;
	else 
		v_ellipse(handle, x_mean, y, rx, ry) ;

	if ((type & BORDER_FLAGS) == BORDERS_3D)
	{
		/* dark border */
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		if (type & HEAD_CUT) 
			v_ellarc(handle, x0, y, dx, ry, 2700, 200);
		else if (type & TAIL_CUT)
			v_ellarc(handle, x1, y, dx, ry, 2000, 2700);
		else
			v_ellarc(handle, x_mean, y, rx, ry, 2000, 200);

		/* light border */ 
		rgb_3d_ltype_lcolor(xhandle, style, color) ;
		if (type & HEAD_CUT) 
			v_ellarc(handle, x0, y, dx, ry, 200, 900) ;
		else if (type & TAIL_CUT)
			v_ellarc(handle, x1, y, dx, ry, 900, 2000) ;
		else
			v_ellarc(handle, x_mean, y, rx, ry, 200, 2000);
	}
	else if ( !(type & BORDERS_NONE) )
	{
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		if (type & HEAD_CUT) 
			v_ellarc(handle, x0, y, dx, ry, 2700, 900) ;
		else if (type & TAIL_CUT)
			v_ellarc(handle, x1, y, dx, ry, 900, 2700) ;
		else
			v_ellarc(handle, x_mean, y, rx, ry, 0, 3600);
	}
}

				
static void rect(X_HANDLE xhandle, int *points, int type, int style, int color)
{
	int p[10] ;
    VDI_HANDLE handle = (VDI_HANDLE)xhandle ;
	
	p[0] = p[6] = p[8] = points[0] ;
	p[1] = p[3] = p[9] = points[3] ;
	p[2] = p[4] = points[2] ;
	p[5] = p[7] = points[1] ;
	rgb_fstyle_fcolor(xhandle, style, color) ;
/*	v_bar(handle, points) ; size and direct color error in original Atari VDI ?? */
/*	v_fillarea(handle, 5, p) ; but this one is slow */
	vr_recfl(handle, points) ;	/* without borders => draw self */

	if ((type & BORDER_FLAGS) == BORDERS_3D)
	{
		/* dark border */
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		v_pline(handle, 3, p) ;

		/* light border */ 
		rgb_3d_ltype_lcolor(xhandle, style, color) ;
		v_pline(handle, 3, p+4) ;
	}
	else if ( !(type & BORDERS_NONE) )
	{
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		v_pline(handle, 5, p) ;
	}
}


static void tri 
(
	X_HANDLE xhandle, 
	int x0, int x1, int y, int dy,
	int type, int style, int color 
) 
{
	int p[10] ;
    VDI_HANDLE handle = (VDI_HANDLE)xhandle ;
	
	rgb_fstyle_fcolor(xhandle, style, color) ;
	
	p[0] = p[2] = x0 ;
	p[4] = x1 ;
	if (type & HEAD_CUT) 
	{
		p[1] = y - (dy >> 1) ;
		p[3] = y + (dy >> 1) ;
		p[5] = y ;
		p[6] = p[0] ;
		p[7] = p[1] ;
		v_fillarea(handle, 3, p) ;
	}
	else if (type & TAIL_CUT)
	{
		p[1] = y - dy ;
		p[3] = y + dy ;
		p[5] = y - (dy >> 1) ;
		p[6] = p[4] ;
		p[7] = y + (dy >> 1) ;
		p[8] = p[0] ;
		p[9] = p[1] ;
		v_fillarea(handle, 4, p) ;
	}
	else
	{
		p[1] = y - dy ;
		p[3] = y + dy ;
		p[5] = y ;
		p[6] = p[0] ;
		p[7] = p[1] ;
		v_fillarea(handle, 3, p) ;
	}

	if ((type & BORDER_FLAGS) == BORDERS_3D)
	{
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		if (x1 > x0)
			/* dark border only at the bottom */
			v_pline(handle, 2, p+2) ;
		else
			/* dark border on the right */
			v_pline(handle, 2, p) ;

		rgb_3d_ltype_lcolor(xhandle, style, color) ;
		if (x1 > x0)
			/* light border only on the left side */ 
			v_pline(handle, 2, p) ;
		else
		{
			/* light border only on top */
			if (type & TAIL_CUT)
				v_pline(handle, 2, p+6) ;
			else
				v_pline(handle, 2, p+4) ;
		}
	}
	else if ( !(type & BORDERS_NONE) )
	{
		vsl_type(handle, SOLID) ;
		rgb_lcolor(xhandle, color) ;
		if (type & TAIL_CUT)
			v_pline(handle, 5, p) ;
		else
			v_pline(handle, 4, p) ;
	}
}				


void draw_note 
(
	X_HANDLE xhandle, 	/* VDI workstation handle, extended */
	int *points,	/* points[0]:     x-value of 1. corner
   					   points[1]:     y-value of 1. corner
	   				   points[2]:     x-value of 2. corner
		   			   points[3]:     y-value of 2. corner */
	int type,		
	int style, 		/* fill style body */
	int color,		/* fill	color body */
	int end_style,	/* fill style ends */
	int end_color	/* fill	color ends */
)
{
	const VDI_HANDLE handle = (VDI_HANDLE)xhandle ;
	const int y_mean = (int)( (float)(points[3] + points[1]) / 2 + 0.5 ) ;
	const int dy     = (points[3] - points[1]) >> 1 ;
	/* avoid TAIL_CUT and HEAD_CUT evaluation when drawing the ends: */
	const int end_type = type & BORDER_FLAGS ;	
	
	vswr_mode(handle, MD_REPLACE) ;
	vsf_perimeter(handle, 0) ; /* draw perimeter self */
	
	/* draw triangle ends in the background */
	if (type & HEAD_TRI && !(type & HEAD_CUT))
	{
		tri(xhandle, points[0], points[0] + (dy<<1), y_mean, dy<<1, 
			end_type, end_style, end_color) ; 
	}
	if (type & TAIL_TRI && !(type & TAIL_CUT))
	{
		tri(xhandle, points[2], points[2] - (dy<<1), y_mean, dy<<1, 
			end_type, end_style, end_color) ; 
	}
	/* draw note body */
	if (type & BODY_ELLIP) 
	{
		ellip(xhandle, points[0], points[2], y_mean, dy * ELL_STRETCH, 
			type, style, color) ;
	}
	else if (type & BODY_RECT)
	{
		rect(xhandle, points, type, style, color) ;
	}
	else if (type & BODY_TRI)
	{
		tri(xhandle, points[0], points[2], y_mean, dy * TRI_STRETCH, 
			type, style, color) ;
	}
	/* draw line or dot ends in the foreground */
	if ( !(type & HEAD_CUT) )
	{ 
		int r = dy * CIRC_SQUEEZE ;
		if (type & HEAD_DOT)
		{
			ellip(xhandle, points[0]-r, points[0]+r, y_mean, r, 
				end_type, end_style, end_color) ; 
		}
		else if (type & HEAD_LINE)
		{	
			int p[4] ;
			p[0] = p[2] = points[0] ;
			p[1] = points[1] - dy ;
			p[3] = points[3] + dy ;
			vsl_type(handle, SOLID) ; 
			rgb_lcolor(xhandle, end_color) ;
			v_pline(handle, 2, p) ; 
		}
	}
	if ( !(type & TAIL_CUT) )
	{
		int r = dy * CIRC_SQUEEZE ;
		if (type & TAIL_DOT)
		{
			ellip(xhandle, points[2]-r, points[2]+r, y_mean, r, 
				end_type, end_style, end_color) ; 
		}
		else if (type & TAIL_LINE)
		{
			int p[4] ;
			p[0] = p[2] = points[2] ;
			p[1] = points[1] - dy ;
			p[3] = points[3] + dy ;
			vsl_type(handle, SOLID) ; 
			rgb_lcolor(xhandle, end_color) ;
			v_pline(handle, 2, p) ; 
		}
	}
}


void draw_background
(
	X_HANDLE xhandle, 	/* VDI workstation handle, extended */
	int *points,	/* points[0]:     x-value of 1. corner
   					   points[1]:     y-value of 1. corner
	   				   points[2]:     x-value of 2. corner
		   			   points[3]:     y-value of 2. corner */
	int style, 		/* fill style */
	int color		/* fill	color */
)
{
	draw_note(xhandle, points, BORDERS_NONE | BODY_RECT, 
		style, color, style, color) ;
}

	
static void trans_pline(
	VDI_HANDLE handle, 	/* normal VDI workstation handle */
   int n, int *points) 
{
	vswr_mode(handle, MD_TRANS) ;
	v_pline(handle, n, points) ;
}


void draw_lines 
(
	X_HANDLE xhandle, 	/* VDI workstation handle, extended */
	int  number,			/* number of lines to be drawn */
	char first_marked, 		/* first line with special marking */
	char d_marked, 			/* special marking each d_marked lines */
	MARK_MODE mode, 		/* where to place rectangle marks */
	int styles[11], 		/* styles to be used after a special line, or NULL */
	int colors[11], 		/* colors to be used after a special line, or NULL */
	char first_number,      /* number (text) for first special line */
	int number_dots,		/* of special line, no dots if -1 */
	int dx_text, 			/* text (number) offset from x_start on */
	int dy_text,			/* text (number) offset from y_start on */
	int x_start, 			/* of first line */
	int y_start,			/* of first line */
	int x_end, 				/* of first line */
	int y_end,				/* of first_line */
	float dx, 				/* distance of succeeding lines */
	float dy,				/* distance of succeeding lines */
	int line_width			/* in pixels */
) 
{
	VDI_HANDLE handle = (VDI_HANDLE)xhandle ;
	int i, number_offset, k ; 
	int points[4], dx_m = (int)(dx * d_marked / 12 + 0.5) , 
	               dy_m = (int)(dy * d_marked / 12 + 0.5) ; 
	int dx_int = (int)(dx + 0.5), dy_int ;
	int x_width, y_width ;
	int color = -1, style = -1 ;	/* init: do not call draw_background() */
	char dummy[34] = "" ; /* _itoa() on Windows produces up to 33 char. */
	
	if (dy >= 0) dy_int = (int)(dy + 0.5) ;
	else         dy_int = (int)(dy - 0.5) ; /* stupid processors! */

	number_offset = 11 ;
	if (colors)
	{
		color = colors[(first_number + number_offset) % 11] ;
		rgb_lcolor(xhandle, color) ;
	}
	number_offset = -1 ;
	
	vsl_width(handle, line_width) ;
	for (i = 0 ; i < number ; i ++ )
	{
		points[0] = (int)(dx * i + 0.5) + x_start ; 
		if (dy > 0) points[1] = (int)(dy * i + 0.5) + y_start ;
		else        points[1] = (int)(dy * i - 0.5) + y_start ;
		points[2] = points[0] + x_end - x_start ; 
		points[3] = points[1] + y_end - y_start ;

		if (i % d_marked != first_marked) 
			trans_pline(handle, 2, points) ;
		else 
		{
			/* switch to next color and style */
			number_offset ++ ;
			if (colors && styles)
			{
				color = colors[(first_number + number_offset) % 11] ;
				style = styles[(first_number + number_offset) % 11] ;
				rgb_lcolor(xhandle, color) ;
				rgb_tcolor(xhandle, color) ;
			}
			if (first_marked == -1) 
				trans_pline(handle, 2, points) ;
			else
			{
				/* mark with number */
				if ( dx_text != INVALID_DX && dy_text != INVALID_DY )
				{
					vswr_mode(handle, MD_TRANS) ;
					v_gtext( handle, points[0] + dx_text, points[1] + dy_text, 
					         itoa(first_number + number_offset, dummy, 11) ) ;
				}        
				if (style == IP_HOLLOW) vsl_width(handle, line_width * 2) ;
				if (number_dots <= 0)
				{
					if (mode == behind)
					{
						/* mark non-dotted, rectangle behind line */
						points[0] += dx_m ; points[1] += dy_m ; points[2] -= dx_m ; points[3] -= dy_m ; 
						if (style > IP_HOLLOW) 
							draw_background(xhandle, points, style, color) ;
						points[0] -= dx_m ; points[1] -= dy_m ; points[2] += dx_m ; points[3] += dy_m ; 
					}
					else 
					{
						/* mark non-dotted, rectangle between lines */
						points[0] += dx_int ; 
						points[1] += dy_int ;
						if (i != (number - 1) && style > IP_HOLLOW) 
							draw_background(xhandle, points, style, color) ;
						points[0] -= dx_int ; 
						points[1] -= dy_int ;
					}
					trans_pline(handle, 2, points) ;					
				}
				else 
				{
					x_width = ((x_end - x_start) / number_dots) >> 1 ;
					y_width = ((y_end - y_start) / number_dots) >> 1 ;
					for (k = 0 ; k < number_dots ; k++)
					{
						/* draw dot */
						points[0] = (int)(dx * i + x_start 
						            + (float)(x_end - x_start) * k / number_dots + dx_m + 0.5) ; 
						points[1] = (int)(dy * i + y_start 
						            + (float)(y_end - y_start) * k / number_dots + dy_m + 0.5) ;
						points[2] = points[0] + x_width - (dx_m << 1) ;
						points[3] = points[1] + y_width - (dy_m << 1) ;
						if (style > IP_HOLLOW)
							draw_background(xhandle, points, style, color) ;
					
						points[0] -= dx_m ; points[1] -= dy_m ; points[2] += dx_m ; points[3] += dy_m ; 
						trans_pline(handle, 2, points) ;					
					}
				}
				/* reset line width */
				vsl_width(handle, line_width) ;
			}
		}
	}
}


#ifndef __PUREC__
__int32 RGB_15to24(unsigned __int16 in) 
{
	int red   = five_to_eight_bits( in & RGB_RED ) ;
	int green = five_to_eight_bits((in & RGB_GREEN)>> 5) ; 
	int blue  = five_to_eight_bits((in & RGB_BLUE) >>10) ; 
	return RGB(red,green,blue) ;
}

__int16 RGB_24to15(unsigned __int32 in)
{
	int red   = eight_to_five_bits( GetRValue(in) ) ;
	int green = eight_to_five_bits( GetGValue(in) ) ;
	int blue  = eight_to_five_bits( GetBValue(in) ) ;
	return (blue << 10) | (green << 5) | red ;
}
#endif

