#include	<acs.h>
#ifndef __ACS_MODULE__
#	include    <acsplus.h>
#	include <stdio.h> /* because of form_alert() for debugging */
#endif
#include    <graphic.h>
#include    "colorsel.h"
#include	"colsel.h"
#include	"colsel.ah"

#define DIVIDER 9		/* (DIVIDER - 1) should be a divider of 1000 */
#define SQRT_3 17/10	/* sqrt(3) is around 1.7 */

/* for the darker fields (and the sample field) */
#define FRACTION 1/8 /*2/15*/	/* 1/7 would be correct, but then we get too dark colors */

INT32 xhandle ; /* with direct color flag */
INT16 handle ;  /* normal VDI handle without flags */

typedef struct
{
	INT16 x_end1, y_end1 ;
	INT16 x_end2, y_end2 ;
	INT16 color[DIVIDER][DIVIDER] ; /* index in palette mode, 15 bit RGB else */
}
COLOR_PLANE ;

typedef struct
{
	INT16 x0, y0 ;      /* cube's center in pixels from top left corner */
	INT16 a ;
	COLOR_PLANE red ;   /* at the bottom */
	COLOR_PLANE green ; /* right top     */
	COLOR_PLANE blue ;  /* left top      */
}
COLOR_CUBE ;

static COLOR_CUBE color_cube ;

static INT16 my_index_to_rgb(INT16 index)
{
	if (direct_color)
		return index ;
	return index_to_rgb(index) ;
}

static INT16 my_rgb_to_index(INT16 rgb)
{
	if (direct_color)
		return rgb ;
	return rgb_to_index(rgb) ;
}

static void init_color_cube(int ob_width, int ob_height)
{
	int i,j, steps = DIVIDER - 1 ;
	INT16 rgb, white = RGB_RED + RGB_GREEN + RGB_BLUE ;
	
	color_cube.x0 = ob_width  / 2 ;
	color_cube.y0 = ob_height / 2 ;
	color_cube.a  = ob_height / 2 - 2 ; /* 2 pixels frame size */

	color_cube.red.x_end1 = color_cube.blue.x_end2 = -(color_cube.a * SQRT_3 / 2) ;
	color_cube.red.y_end1 = color_cube.red.y_end2 = 
	color_cube.green.y_end1 = color_cube.blue.y_end2 = color_cube.a / 2 ;
	color_cube.red.x_end2 = color_cube.green.x_end1 = -color_cube.red.x_end1 ;
	color_cube.green.x_end2 = color_cube.blue.x_end1 = 0 ;
	color_cube.green.y_end2 = color_cube.blue.y_end1 = -(color_cube.a) ;

	for (i = 0 ; i < DIVIDER ; i++)
	{
		for (j = 0 ; j < DIVIDER ; j++)
		{
			int col_max ;
			col_max = 0x1F ; /* 5 least significat bits set */
			rgb = white 
				- ((col_max * i / steps) << 5) /* green */
				- ((col_max * j / steps) << 10 ) ; /* blue */
			color_cube.red.color[i][j] = my_rgb_to_index(rgb) ;

			rgb = white 
				- ((col_max * i / steps) << 10) /* blue */
				- (col_max * j / steps) ; /* red */
			color_cube.green.color[i][j] = my_rgb_to_index(rgb) ;
				
			rgb = white 
				- (col_max * i / steps) /* red */
				- ((col_max * j / steps) << 5) ; /* green */
			color_cube.blue.color[i][j] = my_rgb_to_index(rgb) ;
		}
	}
}

static int fields[] =
{
	FIELD_0, FIELD_1, FIELD_2, FIELD_3, 
	FIELD_4, FIELD_5, FIELD_6, FIELD_7, 
	FIELD_8, FIELD_9, FIELD_10,FIELD_11,
	FIELD_12,FIELD_13,FIELD_14,FIELD_15
} ;

static int buttons[] =
{
	COLOR_0, COLOR_1, COLOR_2, COLOR_3, 
	COLOR_4, COLOR_5, COLOR_6, COLOR_7, 
	COLOR_8, COLOR_9, COLOR_10,COLOR_11,
	COLOR_12,COLOR_13,COLOR_14,COLOR_15
} ;


static void rgb_recfl(INT32 xhandle, INT16 color, INT16 points[4]) 
{
	int handle = (int)xhandle ;
	rgb_fcolor   (xhandle, color) ;
	vsf_interior (handle, FIS_SOLID) ;
	vsf_perimeter(handle, FALSE) ;
	vswr_mode    (handle, MD_REPLACE) ;
	vr_recfl     (handle, points) ;	
}


static void update_field_colors(Awindow *wi, INT16 rgb)
{
	int i ;
	int red   = get_RED  (rgb) ;
	int green = get_GREEN(rgb) ;
	int blue  = get_BLUE (rgb) ;

	int delta_red   = red   * FRACTION ;
	int delta_green = green * FRACTION ;
	int delta_blue  = blue  * FRACTION ;
	int	color ;

	for (i = 7 ; i > 0 ; i--)
	{
		color = my_rgb_to_index( make_RGB(red, green, blue) ) ;
		wi->work[fields[7 - i]].ob_spec.userblk->ub_parm = (long)color ;
		Awi_obchange(wi, fields[7 - i], -1) ;
		red   -= delta_red   ;
		green -= delta_green ;
		blue  -= delta_blue  ;
	}
	/* rightmost field is always black */
	color = my_rgb_to_index(0 /* black */) ;
	wi->work[fields[7]].ob_spec.userblk->ub_parm = (long)color ;
	Awi_obchange(wi, fields[7], -1) ;
}



static Awindow *create (void *para)
{
	Awindow	*wi ;
	int i ;
	static initialized ;

	xhandle = ACSblk->vdi_handle ;
	if (direct_color)
		xhandle = mark_handle_rgb(xhandle) ;
	handle = (int)xhandle ;
	
	if (ACSblk->ncolors <= 16)
	{
		/* do not show buttons for non-existing colors */
		for (i = ACSblk->ncolors ; i < 16 ; i++)
		{
			COLSEL_WINDOW.work[fields [i]].ob_flags |= HIDETREE ;
			COLSEL_WINDOW.work[buttons[i]].ob_flags |= HIDETREE ;
		}
		/* do not show color cube and reduce window size */
		COLSEL_WINDOW.work[SAMPLE].ob_flags |= HIDETREE ;
		i = COLSEL_WINDOW.work[SAMPLE].ob_height ;	
		COLSEL_WINDOW.work[0].ob_height -= i ;
		COLSEL_WINDOW.work[CUBE].ob_flags |= HIDETREE ;	
		i = COLSEL_WINDOW.work[CUBE].ob_height ;	
		COLSEL_WINDOW.work[0].ob_height -= i ;
			
		if (ACSblk->ncolors <= 8)
		{
			/* 1 row of color buttons less */
			i = COLSEL_WINDOW.work[COLOR_0].ob_height ;	
			COLSEL_WINDOW.work[0].ob_height -= i ;
			
			/* reduce also width */
			i = COLSEL_WINDOW.work[COLOR_0].ob_width ;
			switch (ACSblk->ncolors)
			{
			case 2: 
				/* the buttons wider, the window narrower */
				COLSEL_WINDOW.work[FIELD_0].ob_width *= 2 ;
				COLSEL_WINDOW.work[FIELD_1].ob_width *= 2 ;
				COLSEL_WINDOW.work[COLOR_0].ob_width *= 2 ;
				COLSEL_WINDOW.work[COLOR_1].ob_width *= 2 ;
				COLSEL_WINDOW.work[COLOR_1].ob_x += i ;
				COLSEL_WINDOW.work[0].ob_width /= 2 ;
				break ;
			case 4:
				/* the window narrower */
				COLSEL_WINDOW.work[0].ob_width /= 2 ;
				break ;
			case 8:
				break ;
			}
		}
	}
	else
	{
		/* 256 or more colors => show color cube */
		for (i = 8 ; i < 16 ; i++)
		{
			COLSEL_WINDOW.work[fields [i]].ob_flags |= HIDETREE ;
			COLSEL_WINDOW.work[buttons[i]].ob_flags |= HIDETREE ;
		}
		/* correct size and positions */
		i = COLSEL_WINDOW.work[COLOR_0].ob_height ;
		COLSEL_WINDOW.work[CUBE  ].ob_y -= i ;
		COLSEL_WINDOW.work[SAMPLE].ob_y -= i ;
	}
	wi = Awi_create (&COLSEL_WINDOW) ;

	if (wi)
	{
		if (ACSblk->ncolors > 16)
		{
			/* fit cube's GEM object height to width in pixels */
			i = wi->work[CUBE].ob_height ; /* height before resize */
			wi->work[CUBE].ob_height = wi->work[0].ob_width * 2 * SQRT_3 / 3 ;
			
			/* fit work object height to new cube height */
			wi->work[0].ob_height = wi->work[CUBE].ob_height 
				+ wi->work[COLOR_0].ob_height
				+ wi->work[SAMPLE].ob_height ;
			
			/* fit window height to new work object height */
			wi->wi_act.h += (wi->work[0].ob_height - i) ;

			if (!initialized)
			{
				init_rgb_table(handle) ;

				/* needs width and height in pixels, not in cells */
				init_color_cube(
					wi->work[CUBE].ob_width,
					wi->work[CUBE].ob_height) ;
				initialized = TRUE ;
			}

			/* init 8 color buttons with grey scale */
			update_field_colors(wi, 0x7FFF) ;
		}
		
		/* call init procedure */
		wi->state |= AWS_LATEUPDATE;
		
		wi->open(wi) ;
	}

	return wi;
}


static long vector_product(long x1, long y1, long x2, long y2)
{
	return (x1 * x2 + y1 * y2) ;
}

/*static long vector_square(long x, long y)
{
	return (x * x + y * y) ;
}*/


static INT16 get_color_from_plane(
	const COLOR_PLANE *plane, 
	long x, 
	long y
)
{
	long i,j ;
	
	/* We have to solve the equation:
	
	   (x,y) = (i/(DIVIDER-1)) * (x_end1,y_end1) + (j/(DIVIDER-1)) * (x_end2,y_end) 
	   
	   We do this by multiplying with vectors normal to the plane's 
	   base vectors (y_end1,-x_end1) and (y_end2,-x_end2) and get:
	   
	   (DIVIDER-1) * (x,y) * (y_end2,-x_end2) = i * (x_end1,y_end1) * (y_end2,-x_end2)
	   
	   and
	   
	   (DIVIDER-1) * (x,y) * (y_end1,-x_end1) = j * (x_end2,y_end2) * (y_end1,-x_end1)
	   
	   */
	int divi = DIVIDER ;   
	i = vector_product(x * divi, y * divi, plane->y_end2, -plane->x_end2) 
		/ vector_product(plane->x_end1, plane->y_end1, plane->y_end2, -plane->x_end2) ; 
	j = vector_product(x * divi, y * divi, plane->y_end1, -plane->x_end1) 
		/ vector_product(plane->x_end2, plane->y_end2, plane->y_end1, -plane->x_end1) ; 
		
	if (i >= 0 && i < DIVIDER && j >= 0 && j < DIVIDER)
		return plane->color[(int)i][(int)j] ;	/* (x,y) is inside plane */

	return -1 ; /* (x,y) not inside plane */
}


static INT16 get_color_from_pos(Awindow *wi) 
{
	Axywh offset ;
	long x,y ;
	INT16 color ;

	Aob_offset(&offset, wi->work, CUBE) ;

	/* x,y from the CUBE GEM object origin */
	x = (ACSblk->ev_mmox - offset.x - wi->wi_work.x) ;
	y = (ACSblk->ev_mmoy - offset.y - wi->wi_work.y) ;
	
	/* x,y from the cube's center */
	x -= color_cube.x0 ;
	y -= color_cube.y0 ;
	
	color = get_color_from_plane(&(color_cube.red), x,y) ;
	if (color < 0)
		color = get_color_from_plane(&(color_cube.green), x,y) ;
	if (color < 0)
		color = get_color_from_plane(&(color_cube.blue), x,y) ;
	return color ;
}


static INT16 sample_color = -1 ;

static INT16 init(Awindow *wi)
{
	static INT16 prev_x = -1, prev_y = -1, prev_color = -1 ;

	INT16 wid, t;

	/* no SAMPLE up to 16 colors */
	if (ACSblk->ncolors <= 16)
		return OK ;
		
	wind_get (0, WF_TOP, &wid, &t, &t, &t);
	wi->state |= AWS_LATEUPDATE;
	if (wi->wi_id > 0 && wid == wi->wi_id)
		if (prev_x != ACSblk->ev_mmox || prev_y != ACSblk->ev_mmoy)
	{
		prev_x = ACSblk->ev_mmox ;
		prev_y = ACSblk->ev_mmoy ;
		sample_color = get_color_from_pos(wi) ;
		if (prev_color != sample_color)
		{
			prev_color = sample_color ;
			if (sample_color >= 0)
				sample_color = my_index_to_rgb(sample_color) ;
			Awi_obchange(wi, SAMPLE, -1) ;
		}
	}
	return OK ;
}


static COLOR_MESSAGE cm ;

static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	switch (task)
	{	
		case AS_TERM: 
			Awi_delete(wi) ; 
#ifdef __ACS_MODULE__
			ACSmoduleterm();
#endif
			break ; 
		case AS_INFO:
			alert_str(ABOUT_ME, "") ;
			break ;
/*		case COLOR_DRAGGED:
		case COLOR_CLICKED:
			/* test code */
			wi->work[TEST].ob_spec.userblk->ub_parm = (long)(cm.index) ;
			Awi_obredraw(wi, TEST) ;
			break ;*/
		case COLOR_AVAILABLE:
			/* answer: yes, I am alive ! */
			*((INT16 *)in_out) = TRUE ;
			break ;
		default: return Awi_service(wi, task, in_out) ;
	}
	return TRUE ;	/* task has been treated */
}


static void send_color_message(int msg_nr, INT16 rgb)
{
	Awindow *wi = ACSblk->ev_window ;
	INT16 color, i ;
	
	if (rgb >= 0)
	{
		cm.rgb = rgb ;
		cm.index = my_rgb_to_index(rgb) ;
	}
	else
	{
		switch (ACSblk->ev_obnr)
		{
		case COLOR_0 : i =  0 ; break ;
		case COLOR_1 : i =  1 ; break ;
		case COLOR_2 : i =  2 ; break ;
		case COLOR_3 : i =  3 ; break ;
		case COLOR_4 : i =  4 ; break ;
		case COLOR_5 : i =  5 ; break ;
		case COLOR_6 : i =  6 ; break ;
		case COLOR_7 : i =  7 ; break ;
		case COLOR_8 : i =  8 ; break ;
		case COLOR_9 : i =  9 ; break ;
		case COLOR_10: i = 10 ; break ;
		case COLOR_11: i = 11 ; break ;
		case COLOR_12: i = 12 ; break ;
		case COLOR_13: i = 13 ; break ;
		case COLOR_14: i = 14 ; break ;
		case COLOR_15: i = 15 ; break ;
		}
		color = (INT16)wi->work[fields[i]].ob_spec.userblk->ub_parm ;
		if (direct_color)
		{
			cm.rgb   = color ;
			cm.index = -1 ;
		}
		else
		{
			cm.index = color ;
			cm.rgb   = my_index_to_rgb(color) ;
		}
	}
	int16_to_rgb_array(cm.rgb, &(cm.red)) ;
	if ( ACSblk->Aselect.actlen > 0 )
	{
		wi = ACSblk->Aselect.window ;
		wi->service(wi, msg_nr, &cm) ; 
	}
#ifndef __ACS_MODULE__
	{
		char msg[80] ;
		sprintf(msg, "[0][msg_nr=%d|cm.rgb=%x|cm.index=%d|r=%d g=%d b=%d][ OK ]",
			msg_nr, cm.rgb, cm.index, cm.red, cm.green, cm.blue) ;
		form_alert(0, msg) ;
	}
#endif
}


static void color(void)
{
	/* clicked on color button */
	send_color_message(COLOR_CLICKED, -1) ;
}


static void color_drag(void)
{
	/* dragged on color button */
	send_color_message(COLOR_DRAGGED, -1) ;
}


static void cube(void)
{
	/* clicked on color cube */
	Awindow *wi = ACSblk->ev_window ;
	INT16 color ;

	/*{
		#include <stdio.h>
		char msg[50] ;
		sprintf(msg, "[0][%i colors |%i planes ][ OK ]",
			ACSblk->ncolors, ACSblk->nplanes) ;
		form_alert(0, msg) ;
	}*/

	color = get_color_from_pos(ACSblk->ev_window) ;
	if (color >= 0)
	{
		color = my_index_to_rgb(color) ;
		update_field_colors(wi, color) ;
		send_color_message(COLOR_CUBE_CLICKED, color) ;
	}
}


static void draw_plane(INT32 xhandle, COLOR_PLANE *plane, int x0, int y0)
{
	int points[8], i,j ;
	int handle = (int)xhandle ;

	for (i = 0 ; i < DIVIDER ; i++)
	{
		for (j = 0 ; j < DIVIDER ; j++)
		{
			points[0] = x0 
				+ (int)((long)plane->x_end1 * i / DIVIDER)
				+ (int)((long)plane->x_end2 * j / DIVIDER) ;
			points[1] = y0
				+ (int)((long)plane->y_end1 * i / DIVIDER)
				+ (int)((long)plane->y_end2 * j / DIVIDER) ;
			points[2] = x0 
				+ (int)((long)plane->x_end1 * (i+1) / DIVIDER)
				+ (int)((long)plane->x_end2 * j     / DIVIDER) ;
			points[3] = y0
				+ (int)((long)plane->y_end1 * (i+1) / DIVIDER)
				+ (int)((long)plane->y_end2 * j     / DIVIDER) ;
			points[4] = x0
				+ (int)((long)plane->x_end1 * (i+1) / DIVIDER)
				+ (int)((long)plane->x_end2 * (j+1) / DIVIDER) ;
			points[5] = y0
				+ (int)((long)plane->y_end1 * (i+1) / DIVIDER)
				+ (int)((long)plane->y_end2 * (j+1) / DIVIDER) ;
			points[6] = x0
				+ (int)((long)plane->x_end1 * i     / DIVIDER)
				+ (int)((long)plane->x_end2 * (j+1) / DIVIDER) ;
			points[7] = y0
				+ (int)((long)plane->y_end1 * i     / DIVIDER)
				+ (int)((long)plane->y_end2 * (j+1) / DIVIDER) ;

			rgb_fcolor   (xhandle, plane->color[i][j]) ; 
			vsf_perimeter(handle, FALSE) ;
			vsf_interior (handle, FIS_SOLID) ;
			vswr_mode    (handle, MD_REPLACE) ;
			v_fillarea   (handle, 4, points) ;
		}
	}
}
	
#define SAMPLE_BORDER 2

static int cdecl color_cube_draw(PARMBLK *parmblk) 
{
	int x0 = parmblk->pb_x + color_cube.x0 ;
	int y0 = parmblk->pb_y + color_cube.y0 ;

	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	draw_plane(xhandle, &(color_cube.red  ), x0, y0) ;
	draw_plane(xhandle, &(color_cube.green), x0, y0) ;
	draw_plane(xhandle, &(color_cube.blue ), x0, y0) ;

	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}


static int cdecl color_draw(PARMBLK *parmblk) 
{
	static const int frame = 2 ; /* frame size in pixels */

	int points[4] ;
	int color = (int)(parmblk->pb_parm) ;

	if (color < 0)
		return color_cube_draw(parmblk) ;
		
	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	/* draw color field */
	points[0] = parmblk->pb_x + frame ;
	points[1] = parmblk->pb_y + frame ;
	points[2] = parmblk->pb_x + parmblk->pb_w - frame - 1 ;
	points[3] = parmblk->pb_y + parmblk->pb_h - frame - 1 ;

	rgb_recfl(xhandle, color, points) ;

	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}

static int cdecl sample_draw(PARMBLK *parmblk)
{
	int i, points[4] ;
	int red   = get_RED  (sample_color) ;
	int green = get_GREEN(sample_color) ;
	int blue  = get_BLUE (sample_color) ;

	int delta_red   = red   * FRACTION ;
	int delta_green = green * FRACTION ;
	int delta_blue  = blue  * FRACTION ;
	int	color ;

	vs_clip_from_parmblk(handle, parmblk) ;

	points[1] = parmblk->pb_y + SAMPLE_BORDER ;
	points[3] = parmblk->pb_y + parmblk->pb_h - 1 - SAMPLE_BORDER ;
	for (i = 7 ; i > 0 ; i--)
	{
		color = my_rgb_to_index( make_RGB(red, green, blue) ) ;
		points[0] = parmblk->pb_x + parmblk->pb_w * (7-i) / 8 ;
		points[2] = parmblk->pb_x + parmblk->pb_w * (8-i) / 8 ;
/*		if (i == 7)
			points[0] += SAMPLE_BORDER ;*/
		rgb_recfl(xhandle, color, points) ;
		red   -= delta_red   ;
		green -= delta_green ;
		blue  -= delta_blue  ;
	}
	/* rightmost field is always black */
	color = my_rgb_to_index(0 /* black */) ;
	points[0] = points[2] ;
	points[2] = parmblk->pb_x + parmblk->pb_w - 1 /*- SAMPLE_BORDER*/ ;
	rgb_recfl(xhandle, color, points) ;

	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}


INT16 ACSinit (void)
{
	if (NULL == (COLSEL_WINDOW.create(NULL)))
#ifdef __ACS_MODULE__
		ACSmoduleterm();
#else
		return FAIL ;
#endif
	return OK ;
}