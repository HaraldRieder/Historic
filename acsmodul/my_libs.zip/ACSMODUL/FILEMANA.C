/* #define DEBUG 1 */

/*#include	<atarierr.h>*/
#include	<tos.h>
#include	<string.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<acs.h>
#ifndef __ACS_MODULE__
#include	<acsplus.h>
#endif
#include	"kobold_2.h"

#define	WIDTH		(72)
#define	HEIGHT	(40)

#define LINE_LEN	(128)
#define PATH_LEN	(512)
#define BUFFER		(16384)
#define FILE_LEN	(13)

#include	"filemana.h"

/*****************************************/
/* Variablen *****************************/
static OBJECT		back, files, dirs;
static AOBJECT	back0, files0, dirs0;
static OBJECT		*ob;

#include	"filemana.ah"

INT16 ACSinit (void)
{	back = D_ICONS;	/* back.ob_width = WIDTH; back.ob_height = HEIGHT; */
	back0 = _00aD_ICONS;
	dirs = _02_D_ICONS;	/* dirs.ob_width = WIDTH; dirs.ob_height = HEIGHT; */
	dirs0 = _02aD_ICONS;
	files = _04_D_ICONS;	/* files.ob_width = WIDTH; files.ob_height = HEIGHT; */
	files0 = _04aD_ICONS;

	F_DIR.create (NULL);

	return OK;
}
