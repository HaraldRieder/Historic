#include	<acs.h>
#include	"config.h"
#include	"config.ah"

INT16 ACSinit (void)
{	
	Awindow *wi = F_CFG.create(NULL) ; 
	if (!wi)
		ACSmoduleterm();
		
	/* repair toolbar size for system font with small cell height */
	wi->toolbar[0].ob_height = 64 ;
	wi->toolbar[MSG].ob_height = wi->toolbar[0].ob_height * 3 / 4 ;
		
	wi->open(wi) ;
	return OK;
}