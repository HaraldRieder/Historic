#include	<acs.h>

#include	"dither.h"
#include	"dither.ah"

INT16 ACSinit (void)
{	
	Awindow *wi = F_CFG.create(NULL) ; 
	if (!wi)
		ACSmoduleterm();
	wi->open(wi) ;
	return OK;
}


static void setflag (OBJECT *obj, INT16 flag)
{
	if (flag)	obj->ob_state |= SELECTED;
	else		obj->ob_state &= ~SELECTED;
}

static Awindow *make (void *unused)
{
	Awindow	*wi;

	if (NULL == (wi = Awi_create (&F_CFG)))
		return NULL;
	setflag (wi->work + WHITE_BACKGROUND, ACSblk->dither & 0x080);
	setflag (wi->work + BIG_TEXT        , ACSblk->dither & 0x100);
	setflag (wi->work + LEFT_TOP        , ACSblk->dither & 0x200);
	setflag (wi->work + RIGHT_BOTTOM    , ACSblk->dither & 0x400);
	return wi;
}

static void update(void)
	/* inform other windows that they should redraw */
{
	INT16	buff[8];
	buff[0] = WM_REDRAW;
	buff[1] = gl_apid;
	buff[4] = desk.x;
	buff[5] = desk.y;
	buff[6] = desk.w;
	buff[7] = desk.h;
	appl_write (gl_apid, 16, buff);
	form_dial (FMD_FINISH, desk.x, desk.y, desk.w, desk.h,
	                       desk.x, desk.y, desk.w, desk.h);
}

static void click_color(void)
{
	AOBJECT	*aob = (AOBJECT *)ev_object + ev_obnr + 1;
	INT16 val = (INT16)(aob->userp1);
	ACSblk->dither = (ACSblk->dither & 0xFFF0) | val ;
	update() ;
}

static void click_style(void)
{
	AOBJECT	*aob = (AOBJECT *)ev_object + ev_obnr + 1;
	INT16 val = (INT16)(aob->userp1);
	ACSblk->dither = (ACSblk->dither & 0xFF8F) | (val << 4) ;
	update() ;
}

static void click(void)
{
	INT16 flag = 0 ;
	
	switch (ev_obnr)
	{
	case WHITE_BACKGROUND: flag = 0x080 ; break ;
	case BIG_TEXT:         flag = 0x100 ; break ;
	case LEFT_TOP:         flag = 0x200 ; break ;
	case RIGHT_BOTTOM:     flag = 0x400 ; break ;
	}
	if (ev_object[ev_obnr].ob_state & SELECTED)
		ACSblk->dither |= flag ;
	else 
		ACSblk->dither &= ~flag ;
	Aev_release();
	update() ;
}
