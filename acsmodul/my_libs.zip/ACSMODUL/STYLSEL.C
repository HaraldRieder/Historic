#include	<acs.h>
#ifndef __ACS_MODULE__
#	include    <acs.h>
#endif
#include    <graphic.h>
#include    "stylesel.h"
#include	"stylsel.h"
#include	"stylsel.ah"


static Awindow *create (void *para)
{
	Awindow	*wi = Awi_create (&STYLSEL_WINDOW) ;
	if (wi)
		wi->open(wi) ;
	return wi;
}


static STYLE_MESSAGE sm ;

static INT16 service(Awindow *wi, INT16 task, void *in_out)
{
	switch (task)
	{	
		case AS_TERM: 
			Awi_delete(wi) ; 
#ifdef __ACS_MODULE__
			ACSmoduleterm();
#endif
			break ; 
		case AS_INFO:
			alert_str(ABOUT_ME, "") ;
			break ;
/*		case STYLE_DRAGGED:
		case STYLE_CLICKED:
			/* test code */
			wi->work[TEST].ob_spec.userblk->ub_parm = (long)(sm.style) ;
			Awi_obredraw(wi, TEST) ;
			break ;*/
		case STYLE_AVAILABLE:
			/* answer: yes, I am alive ! */
			*((int *)in_out) = TRUE ;
			break ;
		default: return Awi_service(wi, task, in_out) ;
	}
	return TRUE ;	/* task has been treated */
}


static void send_style_message(int msg_nr)
{
	switch (ACSblk->ev_obnr)
	{
	case STYLE_0: sm.style = 0 ; sm.interior = FIS_HOLLOW  ; break ;
	case STYLE_1: sm.style = 1 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_2: sm.style = 2 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_3: sm.style = 3 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_4: sm.style = 4 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_5: sm.style = 5 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_6: sm.style = 6 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_7: sm.style = 7 ; sm.interior = FIS_PATTERN ; break ;
	case STYLE_8: sm.style = 8 ; sm.interior = FIS_PATTERN ; break ;
	}
	if ( ACSblk->Aselect.actlen > 0 )
	{
		Awindow *wi ;
		wi = ACSblk->Aselect.window ;
		wi->service(wi, msg_nr, &sm) ; 
	}
}


static void style(void)
{
	/* clicked on style button */
	send_style_message(STYLE_CLICKED) ;
}


static void style_drag(void)
{
	/* dragged on style button */
	send_style_message(STYLE_DRAGGED) ;
}


static int cdecl style_draw(PARMBLK *parmblk) 
{
	static const int frame = 2 ; /* frame size in pixels */

	int points[4] ;
	int style = (int)(parmblk->pb_parm) ;
	int handle = ACSblk->vdi_handle ;	
	
	/* set clipping rectangle */
	vs_clip_from_parmblk(handle, parmblk) ;

	/* draw style field */
	points[0] = parmblk->pb_x + frame ;
	points[1] = parmblk->pb_y + frame ;
	points[2] = parmblk->pb_x + parmblk->pb_w - frame - 1 ;
	points[3] = parmblk->pb_y + parmblk->pb_h - frame - 1 ;

	if (style)
	{
		vsf_style    (handle, style) ;
		vsf_interior (handle, FIS_PATTERN) ;
	}
	else
	{
		vsf_interior (handle, FIS_HOLLOW) ;
	}
	vsf_color    (handle, BLACK) ;
	vsf_perimeter(handle, TRUE) ;
	vr_recfl(handle, points) ;	
	
	/* clipping = off */
	vs_clip(handle, FALSE, NULL) ;
	
	return(parmblk->pb_currstate) ;          
}

INT16 ACSinit (void)
{
	if (NULL == (STYLSEL_WINDOW.create(NULL)))
#ifdef __ACS_MODULE__
		ACSmoduleterm();
#else
		return FAIL ;
#endif
	return OK ;
}