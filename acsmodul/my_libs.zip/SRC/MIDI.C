#if defined (__PUREC__)
#	include <tos.h>
#endif
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "servimem.h"
#include "midi.h"

#define MIDI 3

#ifndef min
	#define min(A,B) (((A) < (B)) ? (A) : (B))
#endif
#ifndef max
	#define max(A,B) (((A) > (B)) ? (A) : (B))
#endif

#if defined (__PUREC__)

void note_on(UBYTE channel, UBYTE note, UBYTE dynamic) 
{
	midi_out(NOTE_ON | channel) ;
	midi_out(note) ; 
	midi_out(dynamic) ;	
}

void note_off(UBYTE channel, UBYTE note, UBYTE dynamic) 
{
	midi_out(NOTE_OFF | channel) ; 
	midi_out(note) ;
	midi_out(dynamic) ;	
}

void pitch_bend(UBYTE channel, unsigned int value)
{
	midi_out(PITCH_BEND | channel) ;
	midi_out(value & 0x007F) ;
	midi_out((value >> 7) & 0x007F) ;
}

void pitch_bend_2(UBYTE channel, UBYTE _first, UBYTE _second)
{
	midi_out(PITCH_BEND | channel) ;
	midi_out(_first ) ;
	midi_out(_second) ;
}

void control_change(UBYTE channel, UBYTE controller, UBYTE value)
{
	midi_out(CONTROL_CHANGE | channel) ;
	midi_out(controller) ;
	midi_out(value) ;
}

void sustain_on(UBYTE channel)
{
	control_change(channel, SUSTAIN, 0x7F) ;
}

void sustain_off(UBYTE channel)
{
	control_change(channel, SUSTAIN, 0x00) ;
}

void all_notes_off(UBYTE channel)
{
	control_change(channel, ALL_NOTES_OFF, 0x00) ;
}

void program_change(UBYTE channel, UBYTE value)
{
	midi_out(PROGRAM_CHANGE | channel) ;
	midi_out(value) ;
}

void channel_press(UBYTE channel, UBYTE value)
{
	midi_out(CHANNEL_PRESS | channel) ;
	midi_out(value) ;
}

void poly_key_press(UBYTE channel, UBYTE note, UBYTE value)
{
	midi_out(POLY_KEY_PRESS | channel) ;
	midi_out(note) ; 
	midi_out(value) ;
}

char *ascii_to_midi(char *string, int *midi_len)
{
	static char err_text[40] ;
	char *src, *dest, buff ;
	size_t len ;
	
	/* compress string, ignore all non-hex characters */
	for (src = dest = string ; 
	     *src && *src != '#' && *src != ';' ; 
	     src++)
		if ( isxdigit(*src) )
			*dest++ = *src ;
		else if ( strpbrk(src, " \t,") != src )
		{
			/* not hex and none of the allowed serparators */
			sprintf(err_text, "Invalid char. '%c' at pos. %u.",
				*src, (unsigned)(src-string)) ;
			return err_text ;
		}
	*dest = 0 ;
			
	if (! *string)	
		return NULL ; /* is empty = already converted */
		
	/* test on even number of nibbles */
	len = strlen(string) ;
	if ( len & 0x1 )
	{
		strcpy(err_text, "Number of nibbles is odd.") ;
		return err_text ;
	}
	*midi_len = len >> 1 ;	/* one byte per 2 hexdigits */
		
	/* convert from ascii to hex */
	for (src = dest = string ; *src ; src += 2, dest++)
	{
		buff = src[2] ;
		src[2] = 0 ;
		*dest = (unsigned char)strtol(src, NULL, 16) ;
		src[2] = buff ;
	}
	return NULL ; /* good */
}

static UBYTE pb_sens_message[13] = 
{
	0x00,       /* the status */
	0x64,0x00,	/* RPN parameter number LSB = 0 */
	0x65,0x00,  /* RPN parameter number MSB = 0 */
	            /* parameter number 0 is pitch bend sensitivity */
	0x06,0x00,	/* parameter value MSB */
	0x26,0x00,	/* parameter value LSB */
	0x64,0x7F,	/* reset RPN parameter number to "invalid" */
	0x65,0x7F
} ;
 		
void pitch_bend_sensitivity(UBYTE channel, unsigned value)
{
	/* uses running status Bn (control change on channel n) */
	/* RPN = real time parameter number                     */
	pb_sens_message[0] = 0xB0 | (channel & 0xF) ; /* the status */
	pb_sens_message[6] = (value>>7) & 0x7F ;      /* parameter value MSB */
	pb_sens_message[8] =  value     & 0x7F ;      /* parameter value LSB */
	Midiws(12, pb_sens_message) ;
}

UBYTE Roland_checksum(UBYTE *begin, UBYTE *end)
{
	UBYTE total = 0 ;
	UBYTE mask  = 0x7F ;
	while ( begin <= end )
	{
		total += *begin ;
		begin++ ;
	}	
	return (0x80 - (total & mask)) & mask ;
}

/******************************/
/**** scale tune functions ****/
/******************************/

typedef unsigned char STUNE[12] ;

#define STUNE_LENGTH 22     /* length of sysex scale tune string */
static UBYTE stune[STUNE_LENGTH] ;
static UBYTE *stune_addr = stune + 5 ; /* where address stands */
static UBYTE *stune_data = stune + 8 ; /* where tuning data starts */

/* non-existing MIDI channel 16 is used for addressing patch data */
#define STUNE_PATCH_CHANNEL 16

void scale_tune_send(UBYTE channel)
{
	if      ( channel < 9 ) stune[6] = 0x11 + channel ;
	else if ( channel > 9 ) stune[6] = 0x10 + channel ;
	else   /* channel 9 */  stune[6] = 0x10 ;
		
	/* GS data set 1 messages have 3 byte address */
	stune[STUNE_LENGTH - 2] = Roland_checksum(stune_addr, stune_data + 11) ;
	Midiws(STUNE_LENGTH - 1, stune) ;
}

void scale_tune_send_all(void)
{
	UBYTE channel ;
	for (channel = 0 ; channel <= STUNE_PATCH_CHANNEL ; channel++)
		scale_tune_send(channel) ;	
}

void scale_tune_init(void) 
{	
	stune[0] = SYS_EX ;
	stune[1] = ROLAND ;
	stune[2] = BROADCAST_DEV ;
	stune[3] = GS_MODEL_ID ;
	stune[4] = DATA_SET_1 ;
	stune[5] = 0x40 ;       /* address MSB is always equal */
	stune[7] = 0x40 ;       /* address LSB is always equal  */
	memset(stune_data, MEAN_STUNE, sizeof(STUNE)) ;
	stune[STUNE_LENGTH - 1] = SYS_EX_END ;
}

void scale_tune_set_cent(int cent[12])
{
	/* up to now: 1 data string for all channels together */
	unsigned i ;
	
	for (i = 0 ; i < 12 ; i++)
		stune_data[i] = min( max(cent[i],-64), 63 ) + MEAN_STUNE ;
}

void scale_tune_set_equal_cent(int cent)
{
	scale_tune_set_equal(min( max(cent,-64), 63 ) + MEAN_STUNE) ;
}

void scale_tune_set(UBYTE stune[12]) { memcpy(stune_data,stune,12); }

void scale_tune_set_equal(UBYTE stune) { memset(stune_data,stune,12); }


#endif /* PURE C */

/*****************************/
/**** MIDI file functions ****/
/*****************************/

MIDI_FILE_HEADER read_midi_file_header(const unsigned char *RAM_file)
{
	UINT16 division = 0 ; 
	MIDI_FILE_HEADER header ;

	/* evaluate header chunk */
	if ( memcmp("MThd", RAM_file, 4) )
	{
		/* no correct MIDI file format */
		header.midi_file_type = -1 ; 
		return header ;
	}

	/* continue evaluating header chunk: */
	header.midi_file_type = read_int16(RAM_file + 4 + 4) ;
	header.number_tracks  = read_int16(RAM_file + 4 + 4 + 2) ; 
	division              = read_int16(RAM_file + 4 + 4 + 2 + 2) ;
	if (division & 0x1000)
	{
		/* SMPTE format */
		header.smpte           = (-division) >> 8 ;
		header.ticks_per_frame = division & 0xff ;
		header.ticks_per_beat  = 0 ;
	}
	else 
	{
		/* non-SMPTE format */
		header.smpte           = 0 ;
		header.ticks_per_frame = 0 ;
		header.ticks_per_beat  = division ;
	}
	return header ;
}
